import type { Config } from "tailwindcss";

// Same CSS-variable-token structure as the OMS admin app (apps/frontend),
// deliberately with fresh values in globals.css — the admin app's orange is
// literally Amazon's brand color, not Amanbattery's. Swapping real brand
// colors/logo later only touches globals.css, nothing here.
const config: Config = {
  darkMode: ["class"],
  content: [
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    // lib/page-layout-types.ts's COLUMN_PRESET_CLASSES/visibilityClassName
    // hold Tailwind utility class strings (col-span-*, block/hidden, etc.)
    // that are only ever referenced indirectly (imported constants), never
    // typed out literally in a scanned .tsx file — without "./lib" here,
    // Tailwind's JIT scanner never sees those class names as source text
    // and silently omits them from the compiled CSS. That's exactly what
    // shipped in d87911b: the Page Builder's grid/column/visibility classes
    // had no CSS at all, so every section's columns collapsed to an
    // unspanned 1-of-12 grid track (hence the near-single-word-per-line
    // wrapping and content pinned to the left with the rest of the row
    // blank).
    "./lib/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    container: {
      center: true,
      padding: "1rem",
      screens: { "2xl": "1280px" },
    },
    extend: {
      fontFamily: {
        sans: ["var(--font-sans)", "system-ui", "sans-serif"],
      },
      colors: {
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        card: { DEFAULT: "hsl(var(--card))", foreground: "hsl(var(--card-foreground))" },
        popover: { DEFAULT: "hsl(var(--popover))", foreground: "hsl(var(--popover-foreground))" },
        primary: { DEFAULT: "hsl(var(--primary))", foreground: "hsl(var(--primary-foreground))" },
        secondary: { DEFAULT: "hsl(var(--secondary))", foreground: "hsl(var(--secondary-foreground))" },
        muted: { DEFAULT: "hsl(var(--muted))", foreground: "hsl(var(--muted-foreground))" },
        accent: { DEFAULT: "hsl(var(--accent))", foreground: "hsl(var(--accent-foreground))" },
        destructive: { DEFAULT: "hsl(var(--destructive))", foreground: "hsl(var(--destructive-foreground))" },
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
};
export default config;
