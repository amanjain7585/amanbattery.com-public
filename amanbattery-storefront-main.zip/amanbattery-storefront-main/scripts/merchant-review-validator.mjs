#!/usr/bin/env node
// scripts/merchant-review-validator.mjs
//
// Lightweight Google Merchant Center pre-review checklist for the live
// storefront + shared OMS backend. Reuses the same public endpoints the
// storefront itself calls (lib/api/*) rather than a parallel system —
// this is a read-only checklist runner, not a new data source.
//
// Usage:
//   SITE_URL=https://amanbattery.com API_URL=https://<backend>/api node scripts/merchant-review-validator.mjs
// Defaults to NEXT_PUBLIC_SITE_URL / NEXT_PUBLIC_API_URL (same env vars the
// app itself uses) when the above aren't set, falling back to localhost.
//
// This script requires outbound network access to the live site and API —
// it will not run inside a network-restricted sandbox. Run it from CI, a
// developer machine, or the deploy environment itself.

const SITE_URL = (process.env.SITE_URL || process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3002").replace(/\/$/, "");
const API_URL = (process.env.API_URL || process.env.NEXT_PUBLIC_API_URL || "http://localhost:3001/api").replace(/\/$/, "");

const PLACEHOLDER_PATTERNS = [
  /lorem ipsum/i,
  /\bTODO\b/,
  /\bFIXME\b/,
  /\[Insert/i,
  /\[Delete if/i,
  /\[list items\]/i,
  /\[•\]/,
  /\bLabel 1\b/i,
  /\bLabel 2\b/i,
  /\bLabel 3\b/i,
  /\bColumn 1\b/i,
  /\bColumn 2\b/i,
  /\bCol 3\b/i,
  /\bCol 4\b/i,
  /\bdummy\b/i,
  /\bsample text\b/i,
  /coming soon/i,
  /href="#"/,
];

const results = [];
function report(level, name, detail) {
  results.push({ level, name, detail });
}

async function fetchJson(path) {
  const res = await fetch(`${API_URL}${path}`);
  if (!res.ok) throw new Error(`${path} -> HTTP ${res.status}`);
  return res.json();
}

const MAX_REDIRECT_HOPS = 3;

// Manually follows redirects (fetch's `redirect: "manual"`, not fetch's own
// auto-follow) so a legitimate redirect — e.g. an old category id URL
// permanently redirecting to its slug URL — can be reported as working
// with its full chain, rather than either being silently hidden (auto
// -follow, no visibility into what happened) or misreported as broken
// (checking only the first hop's non-200 status, the previous behavior).
// Follows up to MAX_REDIRECT_HOPS hops, detects loops (a URL revisited
// within the chain), and treats a redirect with no further destination
// after the hop budget as unresolved — never as silently "fine".
async function resolveUrl(url) {
  const chain = [];
  const visited = new Set();
  let current = url;

  for (let hop = 0; hop <= MAX_REDIRECT_HOPS; hop++) {
    if (visited.has(current)) {
      return { outcome: "LOOP", chain };
    }
    visited.add(current);

    let res;
    try {
      res = await fetch(current, { redirect: "manual" });
    } catch {
      chain.push({ url: current, status: 0 });
      return { outcome: "UNREACHABLE", chain };
    }

    const status = res.status;
    if (status >= 300 && status < 400) {
      const location = res.headers.get("location");
      chain.push({ url: current, status });
      if (!location) return { outcome: "BROKEN_REDIRECT", chain };
      if (hop === MAX_REDIRECT_HOPS) return { outcome: "TOO_MANY_REDIRECTS", chain };
      current = new URL(location, current).toString();
      continue;
    }

    chain.push({ url: current, status });
    return { outcome: status === 200 ? "OK" : "ERROR_STATUS", chain };
  }
  return { outcome: "TOO_MANY_REDIRECTS", chain };
}

function chainSummary(chain) {
  return chain.map((h) => `${h.url} (${h.status || "unreachable"})`).join(" -> ");
}

// Turns a resolveUrl() result into a {level, detail} pair, consistent
// across every check that verifies a URL isn't broken. 404/5xx, redirect
// loops, a redirect with no Location header, and an unresolved chain after
// MAX_REDIRECT_HOPS all remain BLOCKER — only a chain that terminates in a
// real 200 is ever non-blocking, and a chain longer than one hop is called
// out explicitly as PASS WITH REDIRECT rather than a plain PASS.
function classifyUrlCheck(result) {
  const { outcome, chain } = result;
  if (outcome === "OK") {
    return chain.length === 1
      ? { level: "PASS", detail: `${chain[0].url} -> 200` }
      : { level: "PASS WITH REDIRECT", detail: `${chainSummary(chain)} -> 200 (final)` };
  }
  if (outcome === "LOOP") return { level: "BLOCKER", detail: `Redirect loop detected: ${chainSummary(chain)}` };
  if (outcome === "TOO_MANY_REDIRECTS")
    return { level: "BLOCKER", detail: `Unresolved after ${MAX_REDIRECT_HOPS} redirect hops: ${chainSummary(chain)}` };
  if (outcome === "BROKEN_REDIRECT")
    return { level: "BLOCKER", detail: `Redirect response with no Location header: ${chainSummary(chain)}` };
  if (outcome === "UNREACHABLE") return { level: "BLOCKER", detail: `Unreachable: ${chainSummary(chain)}` };
  // ERROR_STATUS — a terminal non-200 (404, 5xx, ...), possibly after redirects
  const last = chain[chain.length - 1];
  return { level: "BLOCKER", detail: `${chainSummary(chain)} -> ${last.status} (final)` };
}

async function fetchText(url) {
  const res = await fetch(url);
  return { status: res.status, body: res.ok ? await res.text() : "" };
}

function scanPlaceholders(name, text) {
  for (const pattern of PLACEHOLDER_PATTERNS) {
    if (pattern.test(text)) {
      report("BLOCKER", `Content: ${name}`, `Matches known placeholder pattern: ${pattern}`);
      return;
    }
  }
  report("PASS", `Content: ${name}`, "No known placeholder tokens found");
}

async function checkBusinessIdentity() {
  let config;
  try {
    config = await fetchJson("/public/website-config");
  } catch (err) {
    report("BLOCKER", "Business: config reachable", String(err));
    return null;
  }
  const contact = config.contact ?? {};
  const checks = [
    ["businessName", "Business name configured"],
    ["phone", "Support phone configured"],
    ["email", "Support email configured"],
    ["address", "Address configured"],
  ];
  for (const [field, label] of checks) {
    if (contact[field]) report("PASS", `Business: ${label}`, `"${contact[field]}"`.slice(0, 80));
    else report("BLOCKER", `Business: ${label}`, "Not set in OMS Admin > Website > Contact — required before review");
  }
  return config;
}

async function checkPages() {
  const REQUIRED = [
    ["about", "About"],
    ["contact", "Contact"],
    ["shipping-policy", "Shipping & Delivery"],
    ["returns-refunds", "Return/Refund"],
    ["privacy-policy", "Privacy Policy"],
    ["terms", "Terms & Conditions"],
  ];
  for (const [slug, label] of REQUIRED) {
    const url = `${SITE_URL}/${slug}`;
    const { level, detail } = classifyUrlCheck(await resolveUrl(url));
    report(level, `Page reachable: ${label}`, detail);
  }

  // Cancellation and Warranty have no dedicated pre-built route — they only
  // exist if published as a generic CMS Page (app/[slug]/page.tsx). Can't
  // assume a slug, so this is a manual check rather than a hard pass/fail.
  report("MANUAL CHECK", "Page: Cancellation Policy", "No dedicated route — verify a CMS Page is published and linked if the business has a cancellation policy distinct from Returns & Refunds");
  report("MANUAL CHECK", "Page: Warranty Policy", "No dedicated route — verify a CMS Page is published and linked if warranty terms apply to any product sold");
  report("MANUAL CHECK", "Page: FAQ", "Only rendered if a homepage FAQ section is enabled — verify it has real content, not just enabled with zero items");
}

async function checkNavigation(config) {
  if (!config) {
    report("MANUAL CHECK", "Navigation", "Skipped — website-config unreachable");
    return;
  }
  const links = [
    ...(config.footer?.nav ?? []),
    ...(config.footer?.columns ?? []).flatMap((c) => c.links ?? []),
    ...(config.header?.nav ?? []),
  ];
  if (links.length === 0) {
    report("WARNING", "Navigation: configured links", "No header/footer nav items configured — footer falls back to hardcoded Quick Links only");
    return;
  }
  for (const link of links) {
    if (/^https?:\/\//i.test(link.url) && !link.url.startsWith(SITE_URL)) {
      report("MANUAL CHECK", `Nav link: ${link.label}`, `External URL ${link.url} — not checked by this script`);
      continue;
    }
    const url = link.url.startsWith("http") ? link.url : `${SITE_URL}${link.url.startsWith("/") ? "" : "/"}${link.url}`;
    const { level, detail } = classifyUrlCheck(await resolveUrl(url));
    report(level, `Nav link: ${link.label}`, level === "BLOCKER" ? `${detail} (broken configured internal link)` : detail);
  }
}

async function checkContentPlaceholders() {
  const routes = ["/", "/about", "/contact", "/shop", "/privacy-policy", "/terms", "/shipping-policy", "/returns-refunds"];
  for (const route of routes) {
    const { status, body } = await fetchText(`${SITE_URL}${route}`);
    if (status !== 200) {
      report("MANUAL CHECK", `Placeholder scan: ${route}`, `Skipped — page returned ${status}`);
      continue;
    }
    scanPlaceholders(route, body);
  }
}

async function checkCommerce() {
  for (const [path, label] of [
    ["/shop", "/shop reachable"],
    ["/cart", "/cart reachable"],
    // Checkout redirects unauthenticated visitors client-side (not a server
    // redirect), so a plain 200 is the expected OK result even though a
    // browser would then bounce to /account/login — this only confirms the
    // route itself exists and responds.
    ["/checkout", "/checkout route exists"],
  ]) {
    const { level, detail } = classifyUrlCheck(await resolveUrl(`${SITE_URL}${path}`));
    report(level, `Commerce: ${label}`, detail);
  }

  try {
    const products = await fetchJson("/public/products?limit=50");
    const validPriced = (products.data ?? []).filter((p) => p.price != null && p.images?.length > 0);
    if (validPriced.length > 0) {
      report("PASS", "Commerce: at least one valid fixed-price product", `${validPriced.length} of ${products.data?.length ?? 0} sampled products have a price and image`);
    } else {
      report("BLOCKER", "Commerce: at least one valid fixed-price product", "No product in the first 50 has both a price and an image — feed and storefront would be effectively empty");
    }
  } catch (err) {
    report("BLOCKER", "Commerce: product catalog reachable", String(err));
  }

  try {
    const methods = await fetchJson("/public/checkout/payment-methods");
    if (methods.codAvailable || methods.prepaidAvailable) {
      report("PASS", "Commerce: payment configuration available", JSON.stringify(methods));
    } else {
      report("BLOCKER", "Commerce: payment configuration available", "Neither COD nor prepaid is available — checkout cannot complete");
    }
  } catch (err) {
    report("BLOCKER", "Commerce: payment configuration available", String(err));
  }
}

async function checkTechnical() {
  report(SITE_URL.startsWith("https://") ? "PASS" : "BLOCKER", "Technical: HTTPS", SITE_URL);

  const { status: robotsStatus, body: robotsBody } = await fetchText(`${SITE_URL}/robots.txt`);
  if (robotsStatus !== 200) {
    report("BLOCKER", "Technical: robots.txt", `-> ${robotsStatus}`);
  } else if (/Disallow:\s*\/\s*$/m.test(robotsBody)) {
    report("BLOCKER", "Technical: robots.txt", "Blocks the entire site (Disallow: /)");
  } else {
    report("PASS", "Technical: robots.txt", "Present and does not block the whole site");
  }

  const { status: sitemapStatus, body: sitemapBody } = await fetchText(`${SITE_URL}/sitemap.xml`);
  if (sitemapStatus === 200 && /<url>/i.test(sitemapBody)) {
    report("PASS", "Technical: sitemap.xml", "Present and contains URL entries");
  } else {
    report("BLOCKER", "Technical: sitemap.xml", `-> ${sitemapStatus}, has <url> entries: ${/<url>/i.test(sitemapBody)}`);
  }

  const { status: homeStatus, body: homeBody } = await fetchText(SITE_URL);
  if (homeStatus === 200 && !/name="robots"[^>]*noindex/i.test(homeBody)) {
    report("PASS", "Technical: homepage indexable", "200, no accidental noindex meta tag");
  } else {
    report("BLOCKER", "Technical: homepage indexable", `status=${homeStatus}, noindex present=${/name="robots"[^>]*noindex/i.test(homeBody)}`);
  }
}

function printReport() {
  const order = { BLOCKER: 0, WARNING: 1, "MANUAL CHECK": 2, "PASS WITH REDIRECT": 3, PASS: 4 };
  results.sort((a, b) => order[a.level] - order[b.level]);

  console.log(`\nGoogle Merchant Center pre-review check — ${SITE_URL}\n${"=".repeat(60)}`);
  for (const r of results) {
    console.log(`[${r.level.padEnd(19)}] ${r.name} — ${r.detail}`);
  }

  const blockers = results.filter((r) => r.level === "BLOCKER");
  const warnings = results.filter((r) => r.level === "WARNING");
  const passWithRedirect = results.filter((r) => r.level === "PASS WITH REDIRECT");
  console.log(`\n${"=".repeat(60)}`);
  console.log(
    `PASS: ${results.filter((r) => r.level === "PASS").length}  PASS WITH REDIRECT: ${passWithRedirect.length}  WARNING: ${warnings.length}  BLOCKER: ${blockers.length}  MANUAL CHECK: ${results.filter((r) => r.level === "MANUAL CHECK").length}`,
  );

  if (blockers.length > 0) {
    console.log(`\nSAFE TO REQUEST GOOGLE REVIEW: NO`);
    console.log(`Blocking issues:`);
    for (const b of blockers) console.log(`  - ${b.name}: ${b.detail}`);
    process.exitCode = 1;
  } else {
    console.log(`\nSAFE TO REQUEST GOOGLE REVIEW: YES (no BLOCKERs — review any WARNING/MANUAL CHECK items above first)`);
  }
}

async function main() {
  const config = await checkBusinessIdentity();
  await checkPages();
  await checkNavigation(config);
  await checkContentPlaceholders();
  await checkCommerce();
  await checkTechnical();
  printReport();
}

main().catch((err) => {
  console.error("Validator crashed:", err);
  process.exitCode = 1;
});
