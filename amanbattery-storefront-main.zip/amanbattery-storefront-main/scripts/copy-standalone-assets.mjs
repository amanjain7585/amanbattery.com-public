// next.config.mjs sets output: "standalone", which traces only the deps
// actually imported at runtime instead of shipping full node_modules — but
// it doesn't copy public/ or .next/static into the standalone bundle on its
// own, so we do that here after every build.
import { cpSync, existsSync } from "node:fs";
import { join } from "node:path";

const root = process.cwd();
const standalone = join(root, ".next", "standalone");

if (!existsSync(standalone)) {
  console.error("copy-standalone-assets: .next/standalone not found — did `next build` run with output: 'standalone'?");
  process.exit(1);
}

if (existsSync(join(root, "public"))) {
  cpSync(join(root, "public"), join(standalone, "public"), { recursive: true });
}

cpSync(join(root, ".next", "static"), join(standalone, ".next", "static"), { recursive: true });

console.log("copy-standalone-assets: copied public/ and .next/static into .next/standalone");
