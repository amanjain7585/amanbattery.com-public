// Loads Google Identity Services' hosted script — same script-loader shape
// as lib/razorpay.ts. Sign-in is the ID-token flow (no client secret, no
// server round-trip needed beyond the backend verifying the token's
// signature), so this only ever needs the public Client ID.

import { getGoogleClientId } from "./api/auth";

const SCRIPT_URL = "https://accounts.google.com/gsi/client";

let loadPromise: Promise<void> | null = null;

function loadGoogleScript(): Promise<void> {
  if (loadPromise) return loadPromise;
  loadPromise = new Promise((resolve, reject) => {
    if (document.querySelector(`script[src="${SCRIPT_URL}"]`)) {
      resolve();
      return;
    }
    const script = document.createElement("script");
    script.src = SCRIPT_URL;
    script.onload = () => resolve();
    script.onerror = () => reject(new Error("Failed to load Google Sign-In"));
    document.body.appendChild(script);
  });
  return loadPromise;
}

interface GoogleCredentialResponse {
  credential: string; // the ID token
}

interface GoogleIdentityServices {
  accounts: {
    id: {
      initialize: (config: { client_id: string; callback: (response: GoogleCredentialResponse) => void }) => void;
      renderButton: (container: HTMLElement, options: { theme: string; size: string; width: number }) => void;
    };
  };
}

// Renders Google's own Sign-In button into `container` — resolves with the
// ID token once the customer completes sign-in, rejects if the script fails
// to load. Nothing resolves if the customer never interacts (no "cancel"
// state to reject on, unlike the Razorpay widget).
export async function renderGoogleSignInButton(
  container: HTMLElement,
  onSuccess: (idToken: string) => void,
): Promise<void> {
  // DB-backed on the OMS side (Settings > Google Sign-In), not a build-time
  // env var — so it works the moment an admin configures it, no redeploy.
  const { googleClientId: clientId } = await getGoogleClientId().catch(() => ({ googleClientId: null }));
  if (!clientId) return; // Google Sign-In not configured — caller should hide the button

  await loadGoogleScript();

  const google = (window as unknown as { google: GoogleIdentityServices }).google;
  google.accounts.id.initialize({
    client_id: clientId,
    callback: (response: GoogleCredentialResponse) => onSuccess(response.credential),
  });
  google.accounts.id.renderButton(container, { theme: "outline", size: "large", width: 300 });
}
