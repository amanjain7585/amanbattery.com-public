// Central place for the absolute site URL metadata/sitemap/JSON-LD build
// against. Falls back to the Railway domain so this works even before
// NEXT_PUBLIC_SITE_URL is set in an environment.
export const SITE_URL = (process.env.NEXT_PUBLIC_SITE_URL ?? "https://storefront-production-0c97.up.railway.app").replace(
  /\/$/,
  "",
);

export const SITE_NAME = "Amanbattery.com";
