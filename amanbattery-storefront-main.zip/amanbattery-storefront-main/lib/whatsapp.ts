// WhatsApp is a primary support/order channel across the storefront. The
// number is admin-configurable (Website > Contact & Business > WhatsApp,
// stored on WebsiteConfig.contact.whatsapp) — call sites that already have
// that config in scope should pass it as `number` so every WhatsApp link on
// the site stays in sync with the admin setting, not just the footer. This
// env var is only the fallback for call sites that can't reach config
// (or haven't been updated yet), and the default if the admin field is unset.
const ENV_WHATSAPP_NUMBER = process.env.NEXT_PUBLIC_WHATSAPP_NUMBER ?? "+919039065924";

export function whatsappLink(message?: string, number?: string): string {
  const digits = (number || ENV_WHATSAPP_NUMBER).replace(/[^\d]/g, "");
  const qs = message ? `?text=${encodeURIComponent(message)}` : "";
  return `https://wa.me/${digits}${qs}`;
}

export function whatsappDisplayNumber(number?: string): string {
  return number || ENV_WHATSAPP_NUMBER;
}
