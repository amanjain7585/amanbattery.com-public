// Loads Razorpay's official hosted Checkout.js (the one external script this
// storefront loads) — required for PCI-compliant card entry; no card data
// ever touches our servers, which is exactly why the widget has to be
// theirs, not a custom form.

const SCRIPT_URL = "https://checkout.razorpay.com/v1/checkout.js";

let loadPromise: Promise<void> | null = null;

function loadRazorpayScript(): Promise<void> {
  if (loadPromise) return loadPromise;
  loadPromise = new Promise((resolve, reject) => {
    if (document.querySelector(`script[src="${SCRIPT_URL}"]`)) {
      resolve();
      return;
    }
    const script = document.createElement("script");
    script.src = SCRIPT_URL;
    script.onload = () => resolve();
    script.onerror = () => reject(new Error("Failed to load Razorpay checkout"));
    document.body.appendChild(script);
  });
  return loadPromise;
}

export interface RazorpaySuccessResponse {
  razorpay_order_id: string;
  razorpay_payment_id: string;
  razorpay_signature: string;
}

interface OpenCheckoutParams {
  keyId: string;
  razorpayOrderId: string;
  amount: number; // paise
  name: string;
  description?: string;
  prefillName?: string;
  prefillContact?: string;
}

// Resolves with the success payload, rejects if the widget is dismissed
// without completing payment.
export async function openRazorpayCheckout(params: OpenCheckoutParams): Promise<RazorpaySuccessResponse> {
  await loadRazorpayScript();

  return new Promise((resolve, reject) => {
    const RazorpayCtor = (window as unknown as { Razorpay: new (options: Record<string, unknown>) => { open: () => void } }).Razorpay;
    const instance = new RazorpayCtor({
      key: params.keyId,
      order_id: params.razorpayOrderId,
      amount: params.amount,
      currency: "INR",
      name: params.name,
      description: params.description,
      prefill: { name: params.prefillName, contact: params.prefillContact },
      handler: (response: RazorpaySuccessResponse) => resolve(response),
      modal: {
        ondismiss: () => reject(new Error("Payment cancelled")),
      },
    });
    instance.open();
  });
}
