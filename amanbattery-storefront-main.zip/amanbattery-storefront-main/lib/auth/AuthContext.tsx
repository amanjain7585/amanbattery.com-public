"use client";

import { createContext, useContext, useEffect, useState, useCallback } from "react";
import * as authApi from "@/lib/api/auth";
import type { CustomerProfile } from "@/lib/api/types";

interface AuthContextValue {
  token: string | null;
  customer: CustomerProfile | null;
  hydrated: boolean;
  isLoggedIn: boolean;
  setToken: (token: string) => Promise<void>;
  logout: () => void;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);
const STORAGE_KEY = "amanbattery-auth-token";

// Same trust model as CartContext (localStorage, client-only) — the two
// storefront/OMS repos are separate origins, so a shared httpOnly cookie
// would need cross-site credentialed requests; this avoids that complexity
// for v1. Token is a Customer JWT (see backend CustomerJwtStrategy) — scoped
// entirely separately from any staff/admin auth, never sent to admin routes.
export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [token, setTokenState] = useState<string | null>(null);
  const [customer, setCustomer] = useState<CustomerProfile | null>(null);
  const [hydrated, setHydrated] = useState(false);

  const refreshProfile = useCallback(async (activeToken?: string) => {
    const t = activeToken ?? token;
    if (!t) {
      setCustomer(null);
      return;
    }
    try {
      const profile = await authApi.getProfile(t);
      setCustomer(profile);
    } catch {
      // token invalid/expired — clear it rather than leave a stale login state
      setTokenState(null);
      setCustomer(null);
      try {
        localStorage.removeItem(STORAGE_KEY);
      } catch {
        // storage unavailable — nothing more to clean up
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [token]);

  useEffect(() => {
    let stored: string | null = null;
    try {
      stored = localStorage.getItem(STORAGE_KEY);
    } catch {
      // storage unavailable — proceed logged out
    }
    if (stored) {
      setTokenState(stored);
      refreshProfile(stored).finally(() => setHydrated(true));
    } else {
      setHydrated(true);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function setToken(newToken: string) {
    setTokenState(newToken);
    try {
      localStorage.setItem(STORAGE_KEY, newToken);
    } catch {
      // storage unavailable — still works for this session
    }
    await refreshProfile(newToken);
  }

  function logout() {
    setTokenState(null);
    setCustomer(null);
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch {
      // storage unavailable — nothing more to clean up
    }
  }

  return (
    <AuthContext.Provider
      value={{ token, customer, hydrated, isLoggedIn: !!token && !!customer, setToken, logout, refreshProfile: () => refreshProfile() }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within an AuthProvider");
  return ctx;
}
