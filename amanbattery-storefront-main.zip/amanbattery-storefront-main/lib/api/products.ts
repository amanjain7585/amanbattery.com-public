import { apiGet, toQueryString } from "./client";
import type { PaginatedProducts, ProductListFilters, PublicProductDetail } from "./types";

export async function getProducts(filters: ProductListFilters = {}): Promise<PaginatedProducts> {
  const qs = toQueryString({
    categoryId: filters.categoryId,
    brandId: filters.brandId,
    search: filters.search,
    sort: filters.sort,
    page: filters.page,
    limit: filters.limit,
    priceMin: filters.priceMin,
    priceMax: filters.priceMax,
    inStock: filters.inStock ? "true" : undefined,
    ...filters.attrs,
  });
  return apiGet<PaginatedProducts>(`/public/products${qs}`, 60);
}

export async function getProduct(idOrSku: string): Promise<PublicProductDetail> {
  return apiGet<PublicProductDetail>(`/public/products/${encodeURIComponent(idOrSku)}`, 60);
}
