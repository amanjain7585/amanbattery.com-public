import { apiGet } from "./client";
import type { ServiceabilityResult } from "./types";

// Not cached (revalidate: 0) — serviceability is checked on-demand per user
// input, not something we want stale across visitors.
export async function checkServiceability(pincode: string): Promise<ServiceabilityResult> {
  return apiGet<ServiceabilityResult>(`/public/serviceability?pincode=${encodeURIComponent(pincode)}`, 0);
}
