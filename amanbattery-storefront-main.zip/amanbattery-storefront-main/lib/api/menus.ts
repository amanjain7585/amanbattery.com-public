import { apiGet } from "./client";
import type { MenuItem } from "./types";

export async function getMenu(location: "HEADER" | "FOOTER"): Promise<MenuItem[]> {
  return apiGet<MenuItem[]>(`/public/menus?location=${location}`, 300);
}
