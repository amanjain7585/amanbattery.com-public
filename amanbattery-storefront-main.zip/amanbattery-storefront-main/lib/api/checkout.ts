import { apiPostAuth } from "./client";
import type { PlaceOrderRequest, PlaceOrderResponse } from "./types";

// Checkout requires a logged-in Customer — token is required, not optional.
export async function placeOrder(payload: PlaceOrderRequest, token: string): Promise<PlaceOrderResponse> {
  return apiPostAuth<PlaceOrderResponse>("/public/checkout", payload, token);
}
