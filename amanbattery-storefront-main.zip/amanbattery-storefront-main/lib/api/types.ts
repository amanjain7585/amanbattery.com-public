// Mirrors the response shape from apps/backend/src/modules/storefront/storefront.service.ts
// (toPublicProduct). Kept as its own type file, not reused from the OMS
// repo, since the two repos are intentionally separate — this is the
// contract the storefront depends on, not an implementation detail.

export interface PublicCategory {
  id: string;
  categoryName: string;
  slug: string | null;
  categoryType?: "STANDARD" | "COMBO";
}

export interface PublicBrand {
  id: string;
  brandName: string;
}

export type ProductAvailability = "available" | "out_of_stock";

export interface PublicFaqEntry {
  question: string;
  answer: string;
}

export interface PublicProduct {
  id: string;
  sku: string;
  slug: string;
  title: string;
  images: string[];
  brand: string | null;
  category: string | null;
  categorySlug: string | null;
  price: number | null;
  mrp: number | null;
  discountPercent: number | null;
  // Flat key/value map — kept for backward compat, but prefer the richer
  // `attributes` array on PublicProductDetail (has proper labels/units and
  // display order); this map is what powers filter-facet value matching.
  specifications: Record<string, string>;
  availability: ProductAvailability;
  // Customer-facing override string only (e.g. "Ships in 3-5 days") — never
  // changes `availability` itself. Stock status is intentionally separate
  // from pincode/courier serviceability (see PincodeChecker).
  availabilityText: string | null;
  shortDescription: string | null;
  fullDescription: string | null;
  highlights: string[];
  faqs: PublicFaqEntry[];
  seoTitle: string | null;
  seoDescription: string | null;
  canonicalUrl: string | null;
}

// Named/unit-labeled attribute value, ordered per the category's
// CategoryAttributeMapping.displayOrder — this is what the PDP spec table
// and highlight chips should render, not the raw `specifications` map.
export interface PublicProductAttribute {
  code: string;
  name: string;
  unit: string | null;
  comparisonVisible: boolean;
  value: unknown;
}

// "CONFIRMED" = verified fitment; "ESTIMATED" = inferred, not yet verified
// against the actual vehicle — shown to customers so an unverified link
// never reads as a guarantee.
export type VehicleCompatibilityConfidence = "CONFIRMED" | "ESTIMATED";

export interface PublicVehicleCompatibility {
  make: string;
  model: string;
  variant: string;
  yearFrom: number | null;
  yearTo: number | null;
  confidence: VehicleCompatibilityConfidence;
  notes: string | null;
}

// Car Battery Finder — Make -> Model -> Variant -> compatible products.
// Mirrors apps/backend storefront.service.ts's listVehicleMakes/Models/Variants
// and findProductsForVariant/getCarBatteriesByMake(Model).
export interface VehicleMake {
  id: string;
  name: string;
  slug: string;
}

export interface VehicleModel {
  id: string;
  name: string;
  slug: string;
}

export interface VehicleVariant {
  id: string;
  name: string;
  yearFrom: number | null;
  yearTo: number | null;
}

export interface VehicleFinderProduct extends PublicProduct {
  compatibilityConfidence: VehicleCompatibilityConfidence;
  compatibilityNotes: string | null;
}

export interface VehicleFinderResult {
  vehicle: {
    make: string;
    model: string;
    variant: string;
    yearFrom: number | null;
    yearTo: number | null;
  };
  products: VehicleFinderProduct[];
}

export interface CarBatteriesByMake {
  make: { id: string; name: string; slug: string };
  models: { id: string; name: string; slug: string; productCount: number }[];
}

export interface CarBatteriesByMakeModel {
  make: { id: string; name: string; slug: string };
  model: { id: string; name: string; slug: string };
  variants: { id: string; name: string; yearFrom: number | null; yearTo: number | null }[];
  products: PublicProduct[];
}

// One line of a combo product's pick list (see OMS ComboComponent) — `slug`
// is null when the component's standalone SKU has been deactivated, so the
// storefront can show the name without linking to a dead product page.
export interface PublicComboComponent {
  quantity: number;
  name: string;
  sku: string;
  image: string | null;
  slug: string | null;
}

// "FIXED" = exchangeValue is a guaranteed credit; "ESTIMATED" = indicative
// starting point, confirmed at pickup; "INSPECTION" = no online quote,
// determined entirely on physical inspection (exchangeValue is null).
export type ExchangeValueType = "FIXED" | "ESTIMATED" | "INSPECTION";

export interface PublicExchangeOffer {
  eligibleBatteryTypes: string[];
  eligibleCapacityMinAh: number | null;
  eligibleCapacityMaxAh: number | null;
  valueType: ExchangeValueType;
  exchangeValue: number | null;
  notes: string | null;
}

export interface PublicProductDetail extends PublicProduct {
  attributes: PublicProductAttribute[];
  // Admin-curated (CategoryAttributeMapping.showOnPdpSummary) subset of
  // `attributes` for the above-the-fold key-spec strip — falls back to the
  // first 4 attributes server-side when a category hasn't been curated yet.
  keySpecs: PublicProductAttribute[];
  vehicleCompatibility: PublicVehicleCompatibility[];
  comboComponents: PublicComboComponent[];
  exchangeOffer: PublicExchangeOffer | null;
  relatedProducts: PublicProduct[];
  // PDP Page Builder (Website > Product Page) — already resolved
  // (PRODUCT override -> CATEGORY template -> GLOBAL default) and already
  // condition-filtered for this exact product, server-side. Optional so a
  // storefront build from before this field existed (or a backend that
  // hasn't deployed it yet) degrades gracefully rather than crashing.
  pageLayout?: import("../page-layout-types").LayoutDocument;
  pageLayoutSource?: "GLOBAL" | "CATEGORY" | "PRODUCT";
}

export interface BlogCategory {
  id: string;
  name: string;
  slug: string;
}

export interface BlogPostSummary {
  id: string;
  title: string;
  slug: string;
  excerpt: string | null;
  featuredImageUrl: string | null;
  publishedAt: string | null;
  category: { name: string; slug: string } | null;
  author: { name: string } | null;
}

export interface BlogPostDetail extends BlogPostSummary {
  content: string;
  updatedAt: string;
  seoTitle: string | null;
  seoDescription: string | null;
  relatedProducts: PublicProduct[];
  relatedPosts: BlogPostSummary[];
}

export interface PaginatedBlogPosts {
  data: BlogPostSummary[];
  total: number;
  page: number;
  limit: number;
  pages: number;
}

export interface CategoryFilterValue {
  value: string;
  count: number;
}

export interface CategoryFilterAttribute {
  code: string;
  name: string;
  dataType: string;
  unit: string | null;
  displayOrder: number;
  configuration: Record<string, unknown> | null;
  values: CategoryFilterValue[];
}

export interface CategoryFilters {
  category: PublicCategory;
  attributes: CategoryFilterAttribute[];
  brands: PublicBrand[];
  priceMin: number | null;
  priceMax: number | null;
}

export interface PaginatedProducts {
  data: PublicProduct[];
  total: number;
  page: number;
  limit: number;
  pages: number;
}

export interface ProductListFilters {
  categoryId?: string;
  brandId?: string;
  search?: string;
  sort?: "price_asc" | "price_desc" | "newest";
  page?: number;
  limit?: number;
  priceMin?: number;
  priceMax?: number;
  inStock?: boolean;
  // Attribute-code-keyed filter values — OR within one attribute's values,
  // AND across attributes (matches CategoryAttributeMapping.filterable).
  attrs?: Record<string, string[]>;
}

// `courier` is null when the courier check itself failed (e.g. Delhivery
// unreachable) but self-delivery already covers the pincode — see backend
// storefront.service.ts checkServiceability. No shippingCharge/eta fields:
// the OMS doesn't price shipping or return an ETA, so this never fabricates
// either.
export interface ServiceabilityResult {
  pincode: string;
  deliverable: boolean;
  selfDelivery: { city: string } | null;
  courier: { serviceable: boolean; cod: boolean; prepaid: boolean } | null;
}

export interface PlaceOrderItem {
  productId: string;
  quantity: number;
}

export interface PlaceOrderRequest {
  recipientName: string;
  recipientPhone: string;
  shippingAddress: string;
  city: string;
  state: string;
  pincode: string;
  items: PlaceOrderItem[];
}

export interface PlaceOrderResponse {
  orderNumber: string;
  total: number;
  message: string;
}

export interface PaymentMethods {
  codAvailable: boolean;
  prepaidAvailable: boolean;
}

// Same shape as PlaceOrderRequest — recipient/address/items — just posted
// to the prepaid endpoint instead of the COD one.
export type CreatePrepaidOrderRequest = PlaceOrderRequest;

export interface CreatePrepaidOrderResponse {
  orderNumber: string;
  razorpayOrderId: string;
  amount: number; // paise
  keyId: string;
}

export interface ConfirmPaymentRequest {
  orderNumber: string;
  razorpayOrderId: string;
  razorpayPaymentId: string;
  razorpaySignature: string;
}

export interface ConfirmPaymentResponse {
  orderNumber: string;
  paymentStatus: "PAID";
}

// Cashfree 1-Click Onboarding (Smart Address Autofill) — mirrors the OMS
// backend's safe response shapes exactly (apps/backend/src/modules/cashfree
// in the oms-phase1a repo). Only what the storefront is ever allowed to
// see; the backend never returns an access_token or auth_code.
export interface CashfreeAvailabilityResponse {
  available: boolean;
}

export interface CashfreeInitiateResponse {
  success: true;
  sessionId: string;
  environment: "sandbox" | "production";
}

export interface CashfreeNormalizedProfile {
  firstName?: string;
  lastName?: string;
  fullName?: string;
  phone: string;
  email?: string;
  addressLine1?: string;
  addressLine2?: string;
  landmark?: string;
  city?: string;
  state?: string;
  postalCode?: string;
  country: string;
}

export interface CashfreeCompleteResponse {
  success: true;
  profile: CashfreeNormalizedProfile;
}

export interface MenuItem {
  id: string;
  location: "HEADER" | "FOOTER";
  label: string;
  url: string;
  sortOrder: number;
  openInNewTab: boolean;
}

export interface CustomerProfile {
  id: string;
  name: string;
  phone: string | null;
  email: string | null;
}

export interface AuthResponse {
  accessToken: string;
}

export interface CustomerAddress {
  id: string;
  label: string | null;
  recipientName: string;
  phone: string;
  addressLine: string;
  addressLine2: string | null;
  city: string;
  state: string;
  pincode: string;
  isDefault: boolean;
}

export interface CreateAddressRequest {
  label?: string;
  recipientName: string;
  phone: string;
  addressLine: string;
  addressLine2?: string;
  city: string;
  state: string;
  pincode: string;
  isDefault?: boolean;
}

export interface CustomerOrder {
  orderNumber: string;
  status: string;
  paymentMethod: string | null;
  paymentStatus: string | null;
  shipmentStatus: string | null;
  orderDate: string;
  items: { productName: string; quantity: number; amount: number }[];
}
