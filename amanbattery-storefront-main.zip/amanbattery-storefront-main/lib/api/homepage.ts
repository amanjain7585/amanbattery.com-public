import { apiGet } from "./client";

export interface HomepageSection {
  id: string;
  type: string;
  enabled: boolean;
  title?: string | null;
  subtitle?: string | null;
  imageUrl?: string | null;
  content?: Record<string, unknown> | null;
  dataSource?: Record<string, unknown> | null;
  displaySettings?: Record<string, unknown> | null;
  sortOrder: number;
}

export async function getHomepageSections(): Promise<HomepageSection[]> {
  return apiGet<HomepageSection[]>("/public/homepage", 60);
}
