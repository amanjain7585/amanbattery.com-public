import { apiGet, apiPost, apiPostAuth } from "./client";
import type {
  PaymentMethods,
  CreatePrepaidOrderRequest,
  CreatePrepaidOrderResponse,
  ConfirmPaymentRequest,
  ConfirmPaymentResponse,
} from "./types";

// Not cached — checked fresh each checkout visit so a just-configured (or
// just-removed) Razorpay account takes effect immediately, no stale state.
export async function getPaymentMethods(): Promise<PaymentMethods> {
  return apiGet<PaymentMethods>("/public/checkout/payment-methods", 0);
}

// Requires a logged-in Customer — same gate as COD checkout.
export async function createPrepaidOrder(payload: CreatePrepaidOrderRequest, token: string): Promise<CreatePrepaidOrderResponse> {
  return apiPostAuth<CreatePrepaidOrderResponse>("/public/checkout/prepaid", payload, token);
}

export async function confirmPayment(payload: ConfirmPaymentRequest): Promise<ConfirmPaymentResponse> {
  return apiPost<ConfirmPaymentResponse>("/public/checkout/prepaid/confirm", payload);
}
