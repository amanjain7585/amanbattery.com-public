import { apiGet, toQueryString } from "./client";
import type { CategoryFilters, ProductListFilters, PublicCategory } from "./types";

export async function getCategories(): Promise<PublicCategory[]> {
  return apiGet<PublicCategory[]>("/public/categories", 300);
}

// Filter definitions (from CategoryAttributeMapping.filterable) + available
// values/brands/price range for a category, scoped to whatever filters are
// currently active — so facets narrow consistently with the product list.
// Takes the same filter shape as getProducts so both stay in sync.
export async function getCategoryFilters(slug: string, filters: ProductListFilters = {}): Promise<CategoryFilters> {
  const qs = toQueryString({
    brandId: filters.brandId,
    search: filters.search,
    priceMin: filters.priceMin,
    priceMax: filters.priceMax,
    inStock: filters.inStock ? "true" : undefined,
    ...filters.attrs,
  });
  return apiGet<CategoryFilters>(`/public/categories/${encodeURIComponent(slug)}/filters${qs}`, 30);
}
