import { apiGet } from "./client";
import type { PublicBrand } from "./types";

export async function getBrands(): Promise<PublicBrand[]> {
  return apiGet<PublicBrand[]>("/public/brands", 300);
}
