import { apiGet, apiPost, apiGetAuth, apiPostAuth, apiDeleteAuth } from "./client";
import type {
  AuthResponse,
  CustomerProfile,
  CustomerAddress,
  CreateAddressRequest,
  CustomerOrder,
} from "./types";

export function signup(payload: { name: string; phone: string; password: string }): Promise<AuthResponse> {
  return apiPost<AuthResponse>("/customer/auth/signup", payload);
}

export function login(payload: { phone: string; password: string }): Promise<AuthResponse> {
  return apiPost<AuthResponse>("/customer/auth/login", payload);
}

export function googleLogin(idToken: string): Promise<AuthResponse> {
  return apiPost<AuthResponse>("/customer/auth/google", { idToken });
}

// DB-backed on the OMS side (Settings > Google Sign-In), not a build-time
// env var — checked fresh (no cache) so a just-configured Client ID works
// immediately, no storefront redeploy needed.
export function getGoogleClientId(): Promise<{ googleClientId: string | null }> {
  return apiGet<{ googleClientId: string | null }>("/customer/auth/config", 0);
}

export function requestOtp(phone: string): Promise<{ sent: true }> {
  return apiPost<{ sent: true }>("/customer/auth/otp/request", { phone });
}

export function otpLogin(payload: { phone: string; code: string; name?: string }): Promise<AuthResponse> {
  return apiPost<AuthResponse>("/customer/auth/otp/login", payload);
}

export function forgotPassword(phone: string): Promise<{ sent: true }> {
  return apiPost<{ sent: true }>("/customer/auth/forgot-password", { phone });
}

export function resetPassword(payload: { phone: string; code: string; newPassword: string }): Promise<{ reset: true }> {
  return apiPost<{ reset: true }>("/customer/auth/reset-password", payload);
}

export function getProfile(token: string): Promise<CustomerProfile> {
  return apiGetAuth<CustomerProfile>("/customer/auth/me", token);
}

export function listAddresses(token: string): Promise<CustomerAddress[]> {
  return apiGetAuth<CustomerAddress[]>("/customer/addresses", token);
}

export function createAddress(token: string, payload: CreateAddressRequest): Promise<CustomerAddress> {
  return apiPostAuth<CustomerAddress>("/customer/addresses", payload, token);
}

export function deleteAddress(token: string, id: string): Promise<{ deleted: true }> {
  return apiDeleteAuth<{ deleted: true }>(`/customer/addresses/${id}`, token);
}

export function listOrders(token: string): Promise<CustomerOrder[]> {
  return apiGetAuth<CustomerOrder[]>("/customer/orders", token);
}
