import { apiGet } from "./client";

export interface CmsPage {
  title: string;
  slug: string;
  content: string;
  featuredImageUrl: string | null;
  seoTitle: string | null;
  seoDescription: string | null;
  publishedAt: string;
}

// Returns null on any failure (404 = no page published at this slug yet,
// or the API being briefly unreachable) — every call site falls back to
// its existing hardcoded content rather than showing a broken page.
export async function getPageBySlug(slug: string): Promise<CmsPage | null> {
  try {
    return await apiGet<CmsPage>(`/public/pages/${slug}`, 300);
  } catch {
    return null;
  }
}
