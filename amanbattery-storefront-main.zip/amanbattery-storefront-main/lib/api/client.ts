// lib/api/client.ts
//
// Thin fetch wrapper for the OMS public API. Deliberately NOT a copy of the
// OMS admin app's apiFetch (JWT-in-localStorage, hard-redirect-on-401) —
// this repo only ever calls @Public() read endpoints, has no auth
// concept yet, and runs mostly in Server Components, so it leans on
// Next.js's built-in fetch caching (`next: { revalidate }`) instead of a
// client-side cache layer.

function getApiUrl(): string {
  // When running on the server (Node.js runtime in Next.js SSR / Server Components),
  // prefer INTERNAL_API_URL (e.g. http://oms-backend.railway.internal:3001/api)
  // to keep all server-to-server traffic inside Railway's private network ($0 egress fees).
  if (typeof window === "undefined" && process.env.INTERNAL_API_URL) {
    return process.env.INTERNAL_API_URL;
  }
  return process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:3001/api";
}

export class ApiError extends Error {
  constructor(public status: number, message: string) {
    super(message);
    this.name = "ApiError";
  }
}

// revalidate: seconds before Next.js will re-fetch in the background
// (ISR-style) — catalog data doesn't change every second, so a short cache
// window is fine and meaningfully reduces load on the OMS backend.
export async function apiGet<T>(path: string, revalidateSeconds = 60): Promise<T> {
  const res = await fetch(`${getApiUrl()}${path}`, {
    next: { revalidate: revalidateSeconds },
  });

  if (!res.ok) {
    const body = await res.text().catch(() => "");
    let message = `Request failed (${res.status})`;
    try {
      const parsed = JSON.parse(body);
      message = parsed?.message ?? message;
    } catch {
      // not JSON — keep the generic message, don't leak a raw HTML/error page
    }
    throw new ApiError(res.status, message);
  }

  return res.json() as Promise<T>;
}

// No caching — used for the one write endpoint (checkout), where every
// request is a fresh submission, never something to reuse from cache.
export async function apiPost<T>(path: string, body: unknown): Promise<T> {
  const res = await fetch(`${getApiUrl()}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const responseBody = await res.text().catch(() => "");
    let message = `Request failed (${res.status})`;
    try {
      const parsed = JSON.parse(responseBody);
      message = Array.isArray(parsed?.message) ? parsed.message.join(", ") : parsed?.message ?? message;
    } catch {
      // not JSON — keep the generic message, don't leak a raw HTML/error page
    }
    throw new ApiError(res.status, message);
  }

  return res.json() as Promise<T>;
}

// Authenticated variants — used by customer-auth and checkout, which now
// require a logged-in Customer. Token comes from AuthContext (localStorage),
// passed in explicitly rather than read here, since this file has no
// knowledge of the auth layer.
export async function apiGetAuth<T>(path: string, token: string): Promise<T> {
  const res = await fetch(`${getApiUrl()}${path}`, {
    headers: { Authorization: `Bearer ${token}` },
    cache: 'no-store',
  });
  return handleAuthResponse<T>(res);
}

export async function apiPostAuth<T>(path: string, body: unknown, token?: string): Promise<T> {
  const res = await fetch(`${getApiUrl()}${path}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: JSON.stringify(body),
  });
  return handleAuthResponse<T>(res);
}

export async function apiDeleteAuth<T>(path: string, token: string): Promise<T> {
  const res = await fetch(`${getApiUrl()}${path}`, {
    method: 'DELETE',
    headers: { Authorization: `Bearer ${token}` },
  });
  return handleAuthResponse<T>(res);
}

async function handleAuthResponse<T>(res: Response): Promise<T> {
  if (!res.ok) {
    const body = await res.text().catch(() => "");
    let message = `Request failed (${res.status})`;
    try {
      const parsed = JSON.parse(body);
      message = Array.isArray(parsed?.message) ? parsed.message.join(", ") : parsed?.message ?? message;
    } catch {
      // not JSON — keep the generic message
    }
    throw new ApiError(res.status, message);
  }
  return res.json() as Promise<T>;
}

function toQueryString(params: Record<string, string | number | string[] | undefined>): string {
  const search = new URLSearchParams();
  for (const [key, value] of Object.entries(params)) {
    if (value === undefined || value === "") continue;
    if (Array.isArray(value)) {
      if (value.length > 0) search.set(key, value.join(","));
    } else {
      search.set(key, String(value));
    }
  }
  const qs = search.toString();
  return qs ? `?${qs}` : "";
}

export { toQueryString };
