import { apiPostAuth } from "./client";
import type {
  CashfreeAvailabilityResponse,
  CashfreeInitiateResponse,
  CashfreeCompleteResponse,
} from "./types";

// All four routes require a logged-in Customer — same gate as COD/prepaid
// checkout (see backend CashfreeController, CustomerJwtAuthGuard). Not
// cached — each is a live check/action, never something to reuse.

export function checkCashfreeAvailability(phone: string, token: string): Promise<CashfreeAvailabilityResponse> {
  return apiPostAuth<CashfreeAvailabilityResponse>("/storefront/cashfree/availability", { phone }, token);
}

export function initiateCashfreeOnboarding(phone: string, token: string): Promise<CashfreeInitiateResponse> {
  return apiPostAuth<CashfreeInitiateResponse>("/storefront/cashfree/initiate", { phone }, token);
}

export function completeCashfreeOnboarding(
  payload: { authCode: string; sessionId: string; verificationId?: string },
  token: string,
): Promise<CashfreeCompleteResponse> {
  return apiPostAuth<CashfreeCompleteResponse>("/storefront/cashfree/complete", payload, token);
}

// Fire-and-forget client-side UX telemetry (widget closed / profile
// applied) — see CLIENT_REPORTABLE_EVENT_TYPES on the backend. Callers
// should call this without awaiting/blocking on it.
export function trackCashfreeEvent(
  eventType: "CASHFREE_ONBOARDING_CLOSED" | "CASHFREE_PROFILE_APPLIED",
  sessionId: string | undefined,
  token: string,
): Promise<{ tracked: true }> {
  return apiPostAuth<{ tracked: true }>("/storefront/cashfree/track", { eventType, sessionId }, token);
}
