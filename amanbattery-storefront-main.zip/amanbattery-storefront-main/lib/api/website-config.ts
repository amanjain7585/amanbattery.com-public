import { apiGet } from "./client";

export interface WebsiteBranding {
  siteName?: string;
  logoUrl?: string;
  logoAlt?: string;
  mobileLogoUrl?: string;
  faviconUrl?: string;
  socialImageUrl?: string;
  colors?: {
    primaryColor?: string;
    secondaryColor?: string;
    accentColor?: string;
    textColor?: string;
  };
}

export interface WebsiteFooter {
  footerLogoUrl?: string;
  aboutText?: string;
  copyrightText?: string;
  contactHeading?: string;
  paymentIcons?: string[];
  nav: { id: string; label: string; url: string; openInNewTab: boolean }[];
  columns: {
    id: string;
    title: string;
    isContactBlock?: boolean;
    links: { id: string; label: string; url: string; openInNewTab: boolean }[];
  }[];
}

export interface WebsiteContact {
  businessName?: string;
  phone?: string;
  whatsapp?: string;
  email?: string;
  supportEmail?: string;
  address?: string;
  city?: string;
  state?: string;
  pincode?: string;
  businessHours?: string;
  googleMapsUrl?: string;
  googleMapsEmbed?: string;
}

export interface WebsiteSocialLink {
  platform: string;
  url?: string;
  enabled?: boolean;
  sortOrder?: number;
}

export interface WebsiteSeo {
  global?: {
    titleTemplate?: string;
    defaultMetaDescription?: string;
    defaultSocialImageUrl?: string;
    googleVerification?: string;
    gaMeasurementId?: string;
    gtmContainerId?: string;
    structuredDataEnabled?: boolean;
  };
  homepage?: {
    title?: string;
    description?: string;
    imageUrl?: string;
  };
}

export interface WebsiteNavItem {
  id: string;
  label: string;
  url: string;
  openInNewTab: boolean;
  children: WebsiteNavItem[];
}

// Config-driven trust-strip facts (StorefrontService.getCommerceTrustSignals
// on the OMS backend) — never hardcode these on the storefront; they're
// only true when a payment gateway is actually active / a warehouse
// actually has a GSTIN on file.
export interface WebsiteCommerceSignals {
  securePayments: boolean;
  gstInvoiceAvailable: boolean;
}

export interface WebsiteConfig {
  commerce?: WebsiteCommerceSignals;
  branding: WebsiteBranding;
  header: {
    announcementBar?: { enabled?: boolean; message?: string; link?: string; dismissible?: boolean };
    stickyHeader?: boolean;
    searchEnabled?: boolean;
    accountEnabled?: boolean;
    cartEnabled?: boolean;
    nav: WebsiteNavItem[];
  };
  footer: WebsiteFooter;
  contact: WebsiteContact;
  social: { links: WebsiteSocialLink[] };
  seo: WebsiteSeo;
  scripts: { headHtml?: string; bodyEndHtml?: string };
  publishedAt: string | null;
}

// Site-wide config (branding/header/footer/contact/social/seo) — one call,
// cached longer than catalog data since these change rarely.
export async function getWebsiteConfig(): Promise<WebsiteConfig> {
  return apiGet<WebsiteConfig>("/public/website-config", 300);
}
