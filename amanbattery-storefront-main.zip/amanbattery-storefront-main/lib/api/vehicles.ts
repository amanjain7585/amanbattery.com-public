import { apiGet } from "./client";
import type {
  VehicleMake,
  VehicleModel,
  VehicleVariant,
  VehicleFinderResult,
  CarBatteriesByMake,
  CarBatteriesByMakeModel,
} from "./types";

export async function getVehicleMakes(): Promise<VehicleMake[]> {
  return apiGet<VehicleMake[]>(`/public/vehicle-makes`, 300);
}

export async function getVehicleModels(makeId: string): Promise<VehicleModel[]> {
  return apiGet<VehicleModel[]>(`/public/vehicle-makes/${makeId}/models`, 300);
}

export async function getVehicleVariants(modelId: string): Promise<VehicleVariant[]> {
  return apiGet<VehicleVariant[]>(`/public/vehicle-models/${modelId}/variants`, 300);
}

export async function getProductsForVariant(variantId: string): Promise<VehicleFinderResult> {
  return apiGet<VehicleFinderResult>(`/public/vehicle-variants/${variantId}/products`, 60);
}

export async function getCarBatteriesByMake(makeSlug: string): Promise<CarBatteriesByMake> {
  return apiGet<CarBatteriesByMake>(`/public/car-batteries/${makeSlug}`, 300);
}

export async function getCarBatteriesByMakeModel(makeSlug: string, modelSlug: string): Promise<CarBatteriesByMakeModel> {
  return apiGet<CarBatteriesByMakeModel>(`/public/car-batteries/${makeSlug}/${modelSlug}`, 300);
}
