import { apiGet, toQueryString } from "./client";
import type { BlogCategory, BlogPostDetail, PaginatedBlogPosts } from "./types";

export async function getBlogCategories(): Promise<BlogCategory[]> {
  return apiGet<BlogCategory[]>("/public/blog/categories", 300);
}

export async function getBlogPosts(filters: { category?: string; page?: number; limit?: number } = {}): Promise<PaginatedBlogPosts> {
  const qs = toQueryString({ category: filters.category, page: filters.page, limit: filters.limit });
  return apiGet<PaginatedBlogPosts>(`/public/blog/posts${qs}`, 60);
}

export async function getBlogPost(slug: string): Promise<BlogPostDetail> {
  return apiGet<BlogPostDetail>(`/public/blog/posts/${encodeURIComponent(slug)}`, 60);
}
