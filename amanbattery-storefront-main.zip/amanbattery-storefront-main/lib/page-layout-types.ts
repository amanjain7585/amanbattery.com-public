// Type-only mirror of the OMS backend's layout-schema.util.ts —
// deliberately types only, no logic. Validation and condition-evaluation
// stay server-side (see that file's own header comment on why); this repo
// only ever renders an already-resolved, already-condition-filtered
// `pageLayout` handed to it by /public/products/:id.

export type ColumnPreset = "100" | "50-50" | "60-40" | "40-60" | "33-33-33";

export interface LayoutModuleVisibility {
  desktop: boolean;
  tablet: boolean;
  mobile: boolean;
}

export interface LayoutModuleStyle {
  background?: "none" | "muted" | "card";
  border?: "none" | "subtle" | "card";
  spacing?: "compact" | "normal" | "roomy";
  headingSize?: "sm" | "md" | "lg";
  align?: "left" | "center";
}

export interface LayoutModule {
  id: string;
  type: string;
  enabled: boolean;
  heading: string;
  showHeading: boolean;
  visibility: LayoutModuleVisibility;
  hideWhenEmpty: boolean;
  style?: LayoutModuleStyle;
  config: Record<string, unknown>;
}

export interface LayoutColumn {
  id: string;
  modules: LayoutModule[];
}

export interface LayoutSection {
  id: string;
  columnPreset: ColumnPreset;
  columns: LayoutColumn[];
}

export interface LayoutDocument {
  schemaVersion: number;
  sections: LayoutSection[];
}

export const COLUMN_PRESET_CLASSES: Record<ColumnPreset, string[]> = {
  "100": ["col-span-12"],
  "50-50": ["col-span-12 lg:col-span-6", "col-span-12 lg:col-span-6"],
  "60-40": ["col-span-12 lg:col-span-7", "col-span-12 lg:col-span-5"],
  "40-60": ["col-span-12 lg:col-span-5", "col-span-12 lg:col-span-7"],
  "33-33-33": ["col-span-12 lg:col-span-4", "col-span-12 lg:col-span-4", "col-span-12 lg:col-span-4"],
};

export function visibilityClassName(v: LayoutModuleVisibility): string {
  // Tailwind responsive show/hide — "mobile" is the base (< sm), "tablet"
  // is sm..lg, "desktop" is lg+. A module hidden on one tier but shown on
  // others still renders in the DOM (server-rendered, so SEO-critical
  // modules stay crawlable) — just visually hidden with `hidden`/`block`.
  const classes: string[] = [];
  classes.push(v.mobile ? "block" : "hidden");
  classes.push(v.tablet ? "sm:block" : "sm:hidden");
  classes.push(v.desktop ? "lg:block" : "lg:hidden");
  return classes.join(" ");
}
