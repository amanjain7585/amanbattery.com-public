// Single formatter for customer-facing attribute values — every place that
// renders `<value> <unit>` (PDP key specs, Specifications table) must go
// through this, not repeat the concatenation inline. Fixes the
// "90_AHAh"-style bug: the OMS backend's attribute extraction bakes the
// unit into the stored value at import time (e.g.
// customFields.battery_capacity = "90Ah", or "90_AH" for older/
// unnormalized rows), so re-appending Attribute.unit ("Ah") at render time
// duplicated it. This never rewrites stored data — it's presentation-only.

export function formatAttributeValue(rawValue: unknown, unit?: string | null): string {
  if (rawValue == null) return "";
  // Legacy extraction artifacts stored a stray underscore where a space
  // belongs (e.g. "90_AH") — collapse those and normalize whitespace.
  const value = String(rawValue).trim().replace(/_/g, " ").replace(/\s+/g, " ").trim();
  if (!value) return "";

  const normalizedUnit = unit?.trim();
  if (!normalizedUnit) return value;

  const escaped = normalizedUnit.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const trailingUnitPattern = new RegExp(`\\s*${escaped}$`, "i");
  if (trailingUnitPattern.test(value)) {
    // The value already carries this unit (possibly different case/spacing
    // than Attribute.unit's canonical form) — reattach it once instead of
    // duplicating it ("90Ah Ah").
    return value.replace(trailingUnitPattern, "") + normalizedUnit;
  }
  return `${value} ${normalizedUnit}`;
}
