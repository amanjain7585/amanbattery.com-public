// The one place a Cashfree normalized profile gets turned into checkout
// form field values — never spread this mapping across components. Rules:
// never invent a value Cashfree didn't return; never overwrite a field the
// customer already typed without the caller asking for confirmation first
// (see shouldConfirmOverwrite).

import type { CashfreeNormalizedProfile } from "./api/types";

export interface CheckoutFormFields {
  recipientName: string;
  recipientPhone: string;
  shippingAddress: string;
  city: string;
  state: string;
  pincode: string;
}

export function shouldConfirmOverwrite(current: CheckoutFormFields): boolean {
  return Object.values(current).some((v) => v.trim().length > 0);
}

// Combines Cashfree's separate address line/landmark fields into this
// storefront's single free-text "Delivery Address" field. Fields Cashfree
// didn't return fall back to whatever is already in the form — this never
// blanks a field the customer typed.
export function applyCashfreeProfile(
  profile: CashfreeNormalizedProfile,
  current: CheckoutFormFields,
): CheckoutFormFields {
  const name = profile.fullName ?? [profile.firstName, profile.lastName].filter(Boolean).join(" ").trim();
  const addressParts = [profile.addressLine1, profile.landmark, profile.addressLine2].filter((v) => v && v.trim());
  const shippingAddress = addressParts.length > 0 ? addressParts.join(", ") : current.shippingAddress;

  return {
    recipientName: name || current.recipientName,
    recipientPhone: profile.phone || current.recipientPhone,
    shippingAddress,
    city: profile.city ?? current.city,
    state: profile.state ?? current.state,
    pincode: profile.postalCode ?? current.pincode,
  };
}
