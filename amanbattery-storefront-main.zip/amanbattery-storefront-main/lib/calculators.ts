// Pure calculation functions for the Inverter Load Calculator and Backup
// Calculator (Part 8 of the storefront brief). Kept dependency-free and
// side-effect-free so they're easy to reason about and reuse from either
// calculator's UI — no product data or fetching happens in here, only math.
// Product recommendations are computed separately by querying real
// inventory (see app/inverter-calculator/page.tsx) — never hardcoded here.

export interface ApplianceOption {
  name: string;
  watts: number;
}

// Typical wattage for common Indian household appliances — reasonable
// planning defaults, not a spec for any specific product. Customers can
// override any of these or add a custom load.
export const COMMON_APPLIANCES: ApplianceOption[] = [
  { name: "LED Bulb", watts: 10 },
  { name: "Tube Light / LED Tube", watts: 20 },
  { name: "Ceiling Fan", watts: 75 },
  { name: "Television (LED, 32-42\")", watts: 80 },
  { name: "Laptop", watts: 65 },
  { name: "Wi-Fi Router", watts: 15 },
  { name: "Refrigerator (direct-cool, running load)", watts: 150 },
  { name: "Mixer / Grinder", watts: 500 },
  { name: "Washing Machine", watts: 500 },
  { name: "Water Pump (0.5 HP)", watts: 375 },
  { name: "Desktop Computer + Monitor", watts: 200 },
  { name: "Air Cooler", watts: 200 },
];

// Standard VA ratings inverters are commonly sold in — used to round a raw
// VA requirement up to a size that's actually stocked/manufactured, rather
// than quoting an arbitrary number like "742 VA".
const STANDARD_INVERTER_VA_STEPS = [
  500, 600, 700, 850, 900, 1100, 1250, 1500, 1600, 2000, 2500, 3000, 3500, 4000, 5000, 6000, 7500, 10000,
];

export interface LoadItem {
  name: string;
  watts: number;
  quantity: number;
}

export function calculateTotalLoad(items: LoadItem[]): number {
  return items.reduce((sum, item) => sum + item.watts * Math.max(item.quantity, 0), 0);
}

export interface InverterRecommendation {
  totalLoadWatts: number;
  requiredVA: number;
  recommendedVA: number;
}

// power factor: real-world inverter loads (mixed resistive + inductive)
// rarely run at unity power factor — 0.8 is a standard planning assumption.
// safetyMargin: headroom so the inverter isn't run at its rated limit
// continuously (shortens component life / trips on any load spike).
export function recommendInverterVA(
  totalLoadWatts: number,
  powerFactor = 0.8,
  safetyMargin = 1.25,
): InverterRecommendation {
  const requiredVA = totalLoadWatts > 0 ? (totalLoadWatts / powerFactor) * safetyMargin : 0;
  const recommendedVA = STANDARD_INVERTER_VA_STEPS.find((va) => va >= requiredVA) ?? STANDARD_INVERTER_VA_STEPS[STANDARD_INVERTER_VA_STEPS.length - 1];
  return { totalLoadWatts, requiredVA: Math.round(requiredVA), recommendedVA };
}

export interface BatteryConfigRecommendation {
  requiredAh: number;
  batteryVoltage: number;
  batteryCount: number;
  ahPerBattery: number;
}

// Standard battery bank voltages we size for — matches how batteries are
// actually wired for a given inverter system voltage.
const BATTERY_BANK_VOLTAGES = [12, 24, 48] as const;

// efficiency: round-trip inverter + battery losses (charging losses,
// inverter conversion losses, not discharging to 100% depth of discharge) —
// 0.8 is a conservative, commonly used planning assumption for lead-acid.
export function recommendBatteryConfig(
  totalLoadWatts: number,
  backupHours: number,
  systemVoltage: 12 | 24 | 48 = 12,
  efficiency = 0.8,
): BatteryConfigRecommendation {
  const batteryCount = BATTERY_BANK_VOLTAGES.includes(systemVoltage) ? systemVoltage / 12 : 1;
  const requiredAh = totalLoadWatts > 0 && backupHours > 0
    ? (totalLoadWatts * backupHours) / (systemVoltage * efficiency)
    : 0;
  return {
    requiredAh: Math.round(requiredAh),
    batteryVoltage: systemVoltage,
    batteryCount,
    // Each 12V battery in the bank needs to supply this Ah individually —
    // wiring batteries in series (for 24V/48V) doesn't change per-battery Ah.
    ahPerBattery: Math.round(requiredAh),
  };
}

export interface BackupEstimate {
  estimatedHours: number;
}

// Reverse of recommendBatteryConfig — given a battery's actual capacity,
// how long will it back up this load. Used by the Backup Calculator to
// show "your current/chosen battery gives you ~X hours" rather than only
// "you need X Ah".
export function estimateBackupHours(
  loadWatts: number,
  batteryCapacityAh: number,
  systemVoltage: 12 | 24 | 48 = 12,
  batteryCount = 1,
  efficiency = 0.8,
): BackupEstimate {
  if (loadWatts <= 0) return { estimatedHours: 0 };
  const usableWattHours = batteryCapacityAh * systemVoltage * batteryCount * efficiency;
  return { estimatedHours: Math.round((usableWattHours / loadWatts) * 10) / 10 };
}
