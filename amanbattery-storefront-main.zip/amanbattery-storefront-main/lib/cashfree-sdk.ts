// Loads and launches the official Cashfree 1-Click Onboarding Web SDK —
// same script-loading shape as lib/razorpay.ts. Cashfree's script/init/
// callback contract (script URL, global function name, container div id)
// comes from their documented web integration snippet.

const SCRIPT_URL = "https://vssdk-prod.cashfree.com/vsvault/prod/1.0.0/index.js";
export const CASHFREE_SDK_CONTAINER_ID = "cf-sdk";

let loadPromise: Promise<void> | null = null;

function loadCashfreeScript(): Promise<void> {
  if (loadPromise) return loadPromise;
  loadPromise = new Promise<void>((resolve, reject) => {
    if (document.querySelector(`script[src="${SCRIPT_URL}"]`)) {
      resolve();
      return;
    }
    const script = document.createElement("script");
    script.src = SCRIPT_URL;
    script.onload = () => resolve();
    script.onerror = () => reject(new Error("Failed to load Cashfree Onboarding SDK"));
    document.body.appendChild(script);
  }).catch((err) => {
    loadPromise = null; // allow a retry on the next launch attempt
    throw err;
  });
  return loadPromise;
}

// Documented status values (SUCCESS/CLOSED/SESSION_EXPIRED/
// SESSION_ID_MISSING/DIV_MISSING). Cashfree documents these but does not
// currently publish a complete web error-callback schema for every failure
// mode, so parsing below stays defensive — only ever reads a top-level
// `status` field, never a guessed nested path.
export const CASHFREE_SDK_OUTCOMES = {
  SUCCESS: "SUCCESS",
  CLOSED: "CLOSED",
  SESSION_EXPIRED: "SESSION_EXPIRED",
  SESSION_ID_MISSING: "SESSION_ID_MISSING",
  DIV_MISSING: "DIV_MISSING",
} as const;

type CashfreeSdkOutcome = (typeof CASHFREE_SDK_OUTCOMES)[keyof typeof CASHFREE_SDK_OUTCOMES];

export type CashfreeLaunchResult =
  | { outcome: typeof CASHFREE_SDK_OUTCOMES.SUCCESS; authCode: string; verificationId?: string }
  | { outcome: Exclude<CashfreeSdkOutcome, typeof CASHFREE_SDK_OUTCOMES.SUCCESS> | "ERROR"; message?: string };

interface CashfreeSdkHandle {
  closeSDK: () => void;
}

declare global {
  interface Window {
    CF1ClickOnboarding?: (config: {
      sessionId: string;
      successCb: (data: unknown) => void;
      errorCb: (error: unknown) => void;
      mode?: "sandbox" | "production";
    }) => CashfreeSdkHandle;
  }
}

const KNOWN_STATUSES: readonly CashfreeSdkOutcome[] = [
  CASHFREE_SDK_OUTCOMES.SUCCESS,
  CASHFREE_SDK_OUTCOMES.CLOSED,
  CASHFREE_SDK_OUTCOMES.SESSION_EXPIRED,
  CASHFREE_SDK_OUTCOMES.SESSION_ID_MISSING,
  CASHFREE_SDK_OUTCOMES.DIV_MISSING,
];

function getSdkStatus(value: unknown): CashfreeSdkOutcome | null {
  if (typeof value !== "object" || value === null) return null;
  const status = (value as { status?: unknown }).status;
  return typeof status === "string" && (KNOWN_STATUSES as readonly string[]).includes(status)
    ? (status as CashfreeSdkOutcome)
    : null;
}

function extractMessage(value: unknown): string | undefined {
  if (typeof value !== "object" || value === null) return undefined;
  const message = (value as { message?: unknown }).message;
  return typeof message === "string" ? message : undefined;
}

function mapError(error: unknown): CashfreeLaunchResult {
  const status = getSdkStatus(error);
  if (status && status !== CASHFREE_SDK_OUTCOMES.SUCCESS) return { outcome: status };
  return { outcome: "ERROR", message: extractMessage(error) };
}

// Documented success shape: { verification_id, auth_code, status: "SUCCESS" }
// — still parsed defensively (a malformed/missing auth_code resolves to an
// ERROR outcome, never a crash).
function parseSuccess(data: unknown): CashfreeLaunchResult {
  if (typeof data !== "object" || data === null) {
    return { outcome: "ERROR", message: "Cashfree returned an unexpected success payload" };
  }
  const payload = data as { auth_code?: unknown; verification_id?: unknown };
  if (typeof payload.auth_code !== "string" || !payload.auth_code) {
    return { outcome: "ERROR", message: "Cashfree did not return an auth code" };
  }
  return {
    outcome: CASHFREE_SDK_OUTCOMES.SUCCESS,
    authCode: payload.auth_code,
    verificationId: typeof payload.verification_id === "string" ? payload.verification_id : undefined,
  };
}

// Resolves — never rejects — with a discriminated outcome, so callers
// always have a safe, non-blocking fallback to manual checkout.
export async function launchCashfreeOnboarding(
  sessionId: string,
  mode: "sandbox" | "production",
): Promise<CashfreeLaunchResult> {
  if (!sessionId) return { outcome: CASHFREE_SDK_OUTCOMES.SESSION_ID_MISSING };
  if (!document.getElementById(CASHFREE_SDK_CONTAINER_ID)) {
    return { outcome: CASHFREE_SDK_OUTCOMES.DIV_MISSING };
  }

  try {
    await loadCashfreeScript();
  } catch (err) {
    return { outcome: "ERROR", message: err instanceof Error ? err.message : "Failed to load Cashfree SDK" };
  }

  if (!window.CF1ClickOnboarding) {
    return { outcome: "ERROR", message: "Cashfree SDK did not initialize" };
  }

  return new Promise<CashfreeLaunchResult>((resolve) => {
    let settled = false;
    window.CF1ClickOnboarding!({
      sessionId,
      mode,
      successCb: (data) => {
        if (settled) return;
        settled = true;
        resolve(parseSuccess(data));
      },
      errorCb: (error) => {
        if (settled) return;
        settled = true;
        resolve(mapError(error));
      },
    });
  });
}
