import type { Metadata } from "next";
import LegalPageLayout from "@/components/legal/LegalPageLayout";
import { whatsappDisplayNumber } from "@/lib/whatsapp";
import { SITE_URL } from "@/lib/seo";
import { getPageBySlug } from "@/lib/api/pages";
import { getWebsiteConfig } from "@/lib/api/website-config";

const SLUG = "privacy-policy";

export async function generateMetadata(): Promise<Metadata> {
  const page = await getPageBySlug(SLUG);
  return {
    title: page?.seoTitle || "Privacy Policy",
    description: page?.seoDescription || "How Amanbattery.com handles your information.",
    alternates: { canonical: `${SITE_URL}/${SLUG}` },
  };
}

export default async function PrivacyPolicyPage() {
  const [page, config] = await Promise.all([getPageBySlug(SLUG), getWebsiteConfig().catch(() => null)]);
  const waNumber = config?.contact?.whatsapp;

  if (page) {
    return (
      <LegalPageLayout title={page.title}>
        <div dangerouslySetInnerHTML={{ __html: page.content }} />
      </LegalPageLayout>
    );
  }

  return (
    <LegalPageLayout title="Privacy Policy">
      <p>
        This website has account sign-up, a cart, and checkout, so we collect the information needed
        to create your account and process an order — name, phone number, delivery address, and order
        details. You can also reach us directly on WhatsApp; anything you share there is used the same
        way, solely to process your enquiry or order, and isn&apos;t sold or shared with third parties
        for marketing purposes.
      </p>

      <h2>Information We Receive</h2>
      <ul>
        <li>Account details you provide when you sign up (name, phone number, email if given).</li>
        <li>Delivery address and order details you provide at checkout.</li>
        <li>Whatever you send us directly via WhatsApp when asking a question or discussing an order.</li>
        <li>
          Standard technical information collected automatically by any website (browser type,
          general location from IP address, pages visited) for keeping the site running reliably.
        </li>
      </ul>

      <h2>How We Use It</h2>
      <p>
        Account and order information is used only to process your order — arranging shipment,
        confirming delivery, and handling any support you need afterward.
      </p>

      <h2>Third Parties</h2>
      <p>
        We share delivery details (name, address, phone number) with our courier partner only as
        needed to ship your order. We don&apos;t sell your information to anyone.
      </p>

      <h2>Contact</h2>
      <p>
        Questions about this policy — or a request to have information we hold about you deleted —
        can be sent to us on WhatsApp: {whatsappDisplayNumber(waNumber)}.
      </p>
    </LegalPageLayout>
  );
}
