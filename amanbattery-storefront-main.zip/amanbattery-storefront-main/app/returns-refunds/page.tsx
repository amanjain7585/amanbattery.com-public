import type { Metadata } from "next";
import LegalPageLayout from "@/components/legal/LegalPageLayout";
import { whatsappDisplayNumber } from "@/lib/whatsapp";
import { SITE_URL } from "@/lib/seo";
import { getPageBySlug } from "@/lib/api/pages";
import { getWebsiteConfig } from "@/lib/api/website-config";

const SLUG = "returns-refunds";

export async function generateMetadata(): Promise<Metadata> {
  const page = await getPageBySlug(SLUG);
  return {
    title: page?.seoTitle || "Returns & Refunds",
    description: page?.seoDescription || "Return and refund policy for Amanbattery.com orders.",
    alternates: { canonical: `${SITE_URL}/${SLUG}` },
  };
}

export default async function ReturnsRefundsPage() {
  const [page, config] = await Promise.all([getPageBySlug(SLUG), getWebsiteConfig().catch(() => null)]);
  const waNumber = config?.contact?.whatsapp;

  if (page) {
    return (
      <LegalPageLayout title={page.title}>
        <div dangerouslySetInnerHTML={{ __html: page.content }} />
      </LegalPageLayout>
    );
  }

  return (
    <LegalPageLayout title="Returns & Refunds">
      <p>
        If a product arrives damaged, defective, or different from what you ordered, message us on
        WhatsApp as soon as possible after delivery with your order details and photos of the issue,
        and we&apos;ll work out a replacement or refund with you.
      </p>

      <h2>How It Works</h2>
      <ul>
        <li>Message us on WhatsApp with your order details and photos/description of the issue.</li>
        <li>We&apos;ll confirm pickup or return shipping details with you directly.</li>
        <li>Once the returned item is received and checked, we&apos;ll process a replacement or refund.</li>
      </ul>

      <h2>What Isn&apos;t Covered</h2>
      <p>
        Damage caused by misuse, normal wear and tear, or a simple change of mind after the product
        has been used isn&apos;t eligible for return — battery and electrical products are checked
        case by case.
      </p>

      <h2>Contact</h2>
      <p>To start a return or ask about eligibility, message us on WhatsApp: {whatsappDisplayNumber(waNumber)}.</p>
    </LegalPageLayout>
  );
}
