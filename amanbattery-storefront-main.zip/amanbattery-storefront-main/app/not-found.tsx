import Link from "next/link";
import { buttonVariants } from "@/components/ui/button";

export default function NotFound() {
  return (
    <div className="container flex min-h-[50vh] flex-col items-center justify-center gap-4 py-16 text-center">
      <h1 className="text-4xl font-bold">404</h1>
      <p className="text-muted-foreground">
        We couldn&apos;t find that page — it may have been moved or the product is no longer available.
      </p>
      <Link href="/shop" className={buttonVariants()}>
        Continue Shopping
      </Link>
    </div>
  );
}
