import type { Metadata } from "next";
import Script from "next/script";
import { Inter } from "next/font/google";
import "./globals.css";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import WhatsAppButton from "@/components/layout/WhatsAppButton";
import { CartProvider } from "@/lib/cart/CartContext";
import { AuthProvider } from "@/lib/auth/AuthContext";
import { SITE_URL } from "@/lib/seo";
import { getWebsiteConfig } from "@/lib/api/website-config";

const inter = Inter({ subsets: ["latin"], variable: "--font-sans" });

const DEFAULT_SITE_NAME = "Amanbattery.com";
const DEFAULT_DESCRIPTION = "Reliable battery and power products from a trusted seller.";

// Dynamic so the tab title/favicon/OG defaults follow whatever's set in
// OMS Admin > Website > Branding / SEO & Advanced — falls back to the
// previous hardcoded values if the CMS has nothing configured yet or is
// unreachable at build time.
export async function generateMetadata(): Promise<Metadata> {
  const config = await getWebsiteConfig().catch(() => null);
  const siteName = config?.branding?.siteName || DEFAULT_SITE_NAME;
  const description = config?.seo?.global?.defaultMetaDescription || DEFAULT_DESCRIPTION;
  const titleTemplate = config?.seo?.global?.titleTemplate || `%s | ${siteName}`;
  const socialImage = config?.seo?.global?.defaultSocialImageUrl || config?.branding?.socialImageUrl;
  const faviconUrl = config?.branding?.faviconUrl;

  return {
    metadataBase: new URL(SITE_URL),
    title: {
      default: `${siteName} — Batteries, Inverters & Power Products`,
      template: titleTemplate,
    },
    description,
    icons: faviconUrl ? { icon: faviconUrl } : undefined,
    other: config?.seo?.global?.googleVerification
      ? { "google-site-verification": config.seo.global.googleVerification }
      : undefined,
    openGraph: {
      type: "website",
      siteName,
      title: `${siteName} — Batteries, Inverters & Power Products`,
      description,
      images: socialImage ? [socialImage] : undefined,
    },
    twitter: {
      card: "summary_large_image",
      title: `${siteName} — Batteries, Inverters & Power Products`,
      description,
      images: socialImage ? [socialImage] : undefined,
    },
  };
}

// Organization JSON-LD, composed from Branding/Contact/Social rather than
// re-entered as raw structured data (see Website > SEO & Advanced) — keeps
// business info in one place instead of two.
function buildOrganizationJsonLd(config: Awaited<ReturnType<typeof getWebsiteConfig>>) {
  const { branding, contact, social } = config;
  const sameAs = (social?.links ?? []).filter((l) => l.enabled && l.url).map((l) => l.url as string);

  return {
    "@context": "https://schema.org",
    "@type": "Organization",
    name: contact?.businessName || branding?.siteName || DEFAULT_SITE_NAME,
    url: SITE_URL,
    ...(branding?.logoUrl ? { logo: branding.logoUrl } : {}),
    ...(contact?.phone ? { telephone: contact.phone } : {}),
    ...(contact?.email ? { email: contact.email } : {}),
    ...(contact?.address
      ? {
          address: {
            "@type": "PostalAddress",
            streetAddress: contact.address,
            addressLocality: contact.city,
            addressRegion: contact.state,
            postalCode: contact.pincode,
            addressCountry: "IN",
          },
        }
      : {}),
    ...(sameAs.length ? { sameAs } : {}),
  };
}

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const config = await getWebsiteConfig().catch(() => null);
  const ga = config?.seo?.global?.gaMeasurementId;
  const gtm = config?.seo?.global?.gtmContainerId;
  const structuredDataEnabled = config?.seo?.global?.structuredDataEnabled;
  const headHtml = config?.scripts?.headHtml;
  const bodyEndHtml = config?.scripts?.bodyEndHtml;

  return (
    <html lang="en">
      <head>
        {gtm && (
          <Script id="gtm" strategy="afterInteractive">
            {`(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);})(window,document,'script','dataLayer','${gtm}');`}
          </Script>
        )}
        {ga && (
          <>
            <Script src={`https://www.googletagmanager.com/gtag/js?id=${ga}`} strategy="afterInteractive" />
            <Script id="ga" strategy="afterInteractive">
              {`window.dataLayer = window.dataLayer || [];function gtag(){dataLayer.push(arguments);}gtag('js', new Date());gtag('config', '${ga}');`}
            </Script>
          </>
        )}
        {structuredDataEnabled && config && (
          <script
            type="application/ld+json"
            // eslint-disable-next-line react/no-danger
            dangerouslySetInnerHTML={{ __html: JSON.stringify(buildOrganizationJsonLd(config)) }}
          />
        )}
        {/* Admin-authored custom scripts (Website > SEO & Advanced > Custom Scripts,
            gated by a dedicated permission) — trusted content, runs in every visitor's browser. */}
        {headHtml && <div dangerouslySetInnerHTML={{ __html: headHtml }} />}
      </head>
      <body className={`${inter.variable} font-sans antialiased flex min-h-screen flex-col`}>
        {gtm && (
          <noscript>
            <iframe
              src={`https://www.googletagmanager.com/ns.html?id=${gtm}`}
              height="0"
              width="0"
              style={{ display: "none", visibility: "hidden" }}
            />
          </noscript>
        )}
        <AuthProvider>
          <CartProvider>
            <Header />
            <main className="flex-1">{children}</main>
            <Footer />
            <WhatsAppButton number={config?.contact?.whatsapp} />
          </CartProvider>
        </AuthProvider>
        {bodyEndHtml && <div dangerouslySetInnerHTML={{ __html: bodyEndHtml }} />}
      </body>
    </html>
  );
}
