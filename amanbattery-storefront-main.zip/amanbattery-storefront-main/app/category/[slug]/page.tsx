import Link from "next/link";
import { notFound, permanentRedirect } from "next/navigation";
import type { Metadata } from "next";
import AttributeFilters from "@/components/product/AttributeFilters";
import FilterBar from "@/components/product/FilterBar";
import Pagination from "@/components/product/Pagination";
import ProductGrid from "@/components/product/ProductGrid";
import { getBrands } from "@/lib/api/brands";
import { getCategories, getCategoryFilters } from "@/lib/api/categories";
import { getProducts } from "@/lib/api/products";
import type { ProductListFilters } from "@/lib/api/types";
import { SITE_URL } from "@/lib/seo";

const SORT_VALUES: ProductListFilters["sort"][] = ["price_asc", "price_desc", "newest"];
const RESERVED_PARAM_KEYS = new Set(["brandId", "sort", "page", "priceMin", "priceMax", "inStock"]);

// Everything in searchParams that isn't one of the known filter params is
// an attribute-code filter (e.g. ?battery_capacity=65Ah,75Ah) — nothing
// here is hardcoded to a specific attribute name.
function parseAttrFilters(searchParams: Record<string, string | undefined>): Record<string, string[]> {
  const attrs: Record<string, string[]> = {};
  for (const [key, value] of Object.entries(searchParams)) {
    if (RESERVED_PARAM_KEYS.has(key) || !value) continue;
    attrs[key] = value.split(",").filter(Boolean);
  }
  return attrs;
}

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const categories = await getCategories().catch(() => []);
  const category = categories.find((c) => c.slug === params.slug);
  if (!category) return {};

  return {
    title: category.categoryName,
    description: `Shop ${category.categoryName} at Amanbattery.com — genuine products, delivered pan-India.`,
    alternates: { canonical: `${SITE_URL}/category/${category.slug}` },
  };
}

export default async function CategoryPage({
  params,
  searchParams,
}: {
  params: { slug: string };
  searchParams: Record<string, string | undefined>;
}) {
  const categories = await getCategories().catch(() => []);
  const category = categories.find((c) => c.slug === params.slug);
  if (!category) {
    // Old URLs used the category's raw id — redirect those permanently to
    // the slug URL instead of 404ing (this route used to be /category/[id]).
    // permanentRedirect (308) rather than redirect (307): the id URL isn't
    // coming back, so crawlers should update their index to the slug URL
    // rather than keep re-checking the old one.
    const byId = categories.find((c) => c.id === params.slug);
    if (byId?.slug) permanentRedirect(`/category/${byId.slug}`);
    notFound();
  }

  const page = searchParams.page ? parseInt(searchParams.page, 10) : 1;
  const sort = SORT_VALUES.includes(searchParams.sort as ProductListFilters["sort"])
    ? (searchParams.sort as ProductListFilters["sort"])
    : undefined;
  const attrs = parseAttrFilters(searchParams);
  const brandId = searchParams.brandId;
  const priceMin = searchParams.priceMin ? Number(searchParams.priceMin) : undefined;
  const priceMax = searchParams.priceMax ? Number(searchParams.priceMax) : undefined;
  const inStock = searchParams.inStock === "true";
  const basePath = `/category/${params.slug}`;

  const [brands, result, categoryFilters] = await Promise.all([
    getBrands().catch(() => []),
    getProducts({ categoryId: category.id, brandId, sort, page, priceMin, priceMax, inStock, attrs }).catch(() => null),
    getCategoryFilters(params.slug, { brandId, priceMin, priceMax, inStock, attrs }).catch(() => null),
  ]);

  return (
    <div className="container space-y-6 py-8">
      <nav className="text-sm text-muted-foreground">
        <Link href="/" className="hover:text-primary">Home</Link> <span className="mx-1">/</span> {category.categoryName}
      </nav>
      <h1 className="text-2xl font-semibold">{category.categoryName}</h1>

      <div className="flex flex-col gap-6 lg:flex-row lg:gap-8">
        {categoryFilters && <AttributeFilters data={categoryFilters} basePath={basePath} />}
        <div className="flex-1 space-y-6">
          <FilterBar categories={categories} brands={brands} showCategoryFilter={false} basePath={basePath} />
          {result ? (
            <>
              <p className="text-sm text-muted-foreground">{result.total} product{result.total !== 1 ? "s" : ""}</p>
              <ProductGrid products={result.data} />
              <Pagination basePath={basePath} searchParams={searchParams} page={result.page} pages={result.pages} />
            </>
          ) : (
            <p className="text-sm text-destructive">Couldn&apos;t load products right now — please try again.</p>
          )}
        </div>
      </div>
    </div>
  );
}
