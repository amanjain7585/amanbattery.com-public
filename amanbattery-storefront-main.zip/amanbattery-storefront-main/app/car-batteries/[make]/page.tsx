import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { getCarBatteriesByMake } from "@/lib/api/vehicles";
import type { ApiError } from "@/lib/api/client";
import { SITE_URL } from "@/lib/seo";

async function loadMake(makeSlug: string) {
  return getCarBatteriesByMake(makeSlug).catch((err: ApiError) => {
    if (err?.status === 404) return null;
    throw err;
  });
}

export async function generateMetadata({ params }: { params: { make: string } }): Promise<Metadata> {
  const data = await loadMake(params.make);
  if (!data) return {};

  return {
    title: `${data.make.name} Car Batteries — Find the Right Fit`,
    description: `Browse genuine car batteries compatible with ${data.make.name} models — correct fitment, delivered pan-India.`,
    alternates: { canonical: `${SITE_URL}/car-batteries/${data.make.slug}` },
  };
}

// Only renders when at least one model under this make has a compatible,
// active product — see storefront.service.ts getCarBatteriesByMake, which
// returns null rather than an empty shape so this route can 404 instead of
// showing a thin/empty SEO page.
export default async function CarBatteriesByMakePage({ params }: { params: { make: string } }) {
  const data = await loadMake(params.make);
  if (!data) notFound();

  return (
    <div className="container space-y-6 py-8">
      <nav className="text-sm text-muted-foreground">
        <Link href="/" className="hover:text-primary">Home</Link>{" "}
        <span className="mx-1">/</span>{" "}
        <Link href="/car-battery-finder" className="hover:text-primary">Car Battery Finder</Link>{" "}
        <span className="mx-1">/</span> {data.make.name}
      </nav>
      <h1 className="text-2xl font-semibold">{data.make.name} Car Batteries</h1>
      <p className="text-sm text-muted-foreground">Select your {data.make.name} model to see compatible batteries.</p>

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
        {data.models.map((m) => (
          <Link
            key={m.id}
            href={`/car-batteries/${data.make.slug}/${m.slug}`}
            className="rounded-lg border border-border p-4 text-center transition-shadow hover:shadow-md"
          >
            <p className="font-medium">{m.name}</p>
            <p className="mt-1 text-xs text-muted-foreground">
              {m.productCount} compatible {m.productCount === 1 ? "battery" : "batteries"}
            </p>
          </Link>
        ))}
      </div>
    </div>
  );
}
