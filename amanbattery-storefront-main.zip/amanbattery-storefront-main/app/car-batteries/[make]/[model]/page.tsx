import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import ProductGrid from "@/components/product/ProductGrid";
import { getCarBatteriesByMakeModel } from "@/lib/api/vehicles";
import type { ApiError } from "@/lib/api/client";
import { SITE_URL } from "@/lib/seo";

async function loadMakeModel(makeSlug: string, modelSlug: string) {
  return getCarBatteriesByMakeModel(makeSlug, modelSlug).catch((err: ApiError) => {
    if (err?.status === 404) return null;
    throw err;
  });
}

function yearRangeLabel(v: { yearFrom: number | null; yearTo: number | null }): string | null {
  if (v.yearFrom && v.yearTo) return `${v.yearFrom}–${v.yearTo}`;
  if (v.yearFrom) return `${v.yearFrom}+`;
  return null;
}

export async function generateMetadata({
  params,
}: {
  params: { make: string; model: string };
}): Promise<Metadata> {
  const data = await loadMakeModel(params.make, params.model);
  if (!data) return {};

  return {
    title: `${data.make.name} ${data.model.name} Battery — Compatible Car Batteries`,
    description: `Genuine, compatible car batteries for the ${data.make.name} ${data.model.name} — correct fitment, delivered pan-India.`,
    alternates: { canonical: `${SITE_URL}/car-batteries/${data.make.slug}/${data.model.slug}` },
  };
}

// Only renders when this make/model has at least one compatible, active
// product across any of its variants — see storefront.service.ts
// getCarBatteriesByMakeModel, which returns null otherwise so this route
// can 404 instead of showing a thin/empty SEO page.
export default async function CarBatteriesByMakeModelPage({
  params,
}: {
  params: { make: string; model: string };
}) {
  const data = await loadMakeModel(params.make, params.model);
  if (!data) notFound();

  return (
    <div className="container space-y-6 py-8">
      <nav className="text-sm text-muted-foreground">
        <Link href="/" className="hover:text-primary">Home</Link>{" "}
        <span className="mx-1">/</span>{" "}
        <Link href={`/car-batteries/${data.make.slug}`} className="hover:text-primary">{data.make.name}</Link>{" "}
        <span className="mx-1">/</span> {data.model.name}
      </nav>
      <h1 className="text-2xl font-semibold">{data.make.name} {data.model.name} Battery</h1>

      {data.variants.length > 0 && (
        <p className="text-sm text-muted-foreground">
          Fits variants:{" "}
          {data.variants
            .map((v) => (yearRangeLabel(v) ? `${v.name} (${yearRangeLabel(v)})` : v.name))
            .join(", ")}
        </p>
      )}

      <ProductGrid products={data.products} />
    </div>
  );
}
