import Link from "next/link";
import { buttonVariants } from "@/components/ui/button";
import ProductGrid from "@/components/product/ProductGrid";
import { getCategories } from "@/lib/api/categories";
import { getBrands } from "@/lib/api/brands";
import { getProducts, getProduct } from "@/lib/api/products";
import { getHomepageSections, HomepageSection } from "@/lib/api/homepage";
import type { PublicProduct, PublicProductDetail } from "@/lib/api/types";

function str(v: unknown): string | undefined {
  return typeof v === "string" && v ? v : undefined;
}

function idList(v: unknown): string[] {
  return Array.isArray(v) ? v.filter((x): x is string => typeof x === "string") : [];
}

function items(v: unknown): Record<string, string>[] {
  return Array.isArray(v) ? (v as Record<string, string>[]) : [];
}

async function HeroBannerSection({ section }: { section: HomepageSection }) {
  const cta = str(section.content?.ctaLabel);
  const ctaLink = str(section.content?.ctaLink) || "/shop";

  return (
    <section
      className="relative overflow-hidden rounded-xl bg-secondary/50 px-6 py-14 text-center sm:py-20"
      style={
        section.imageUrl
          ? { backgroundImage: `url(${section.imageUrl})`, backgroundSize: "cover", backgroundPosition: "center" }
          : undefined
      }
    >
      {section.imageUrl && <div className="absolute inset-0 bg-black/40" aria-hidden="true" />}
      <div className={`relative ${section.imageUrl ? "text-white" : ""}`}>
        {section.title && (
          <h1 className="mx-auto max-w-2xl text-3xl font-bold tracking-tight sm:text-4xl">{section.title}</h1>
        )}
        {section.subtitle && (
          <p className={`mx-auto mt-4 max-w-xl ${section.imageUrl ? "text-white/90" : "text-muted-foreground"}`}>
            {section.subtitle}
          </p>
        )}
        {cta && (
          <div className="mt-8 flex justify-center gap-3">
            <Link href={ctaLink} className={buttonVariants({ size: "lg" })}>
              {cta}
            </Link>
          </div>
        )}
      </div>
    </section>
  );
}

async function ShopByCategorySection({ section }: { section: HomepageSection }) {
  const all = await getCategories().catch(() => []);
  const ids = idList(section.dataSource?.ids);
  const categories = ids.length ? all.filter((c) => ids.includes(c.id)) : all;
  if (categories.length === 0) return null;

  return (
    <section>
      <h2 className="mb-5 text-xl font-semibold">{section.title || "Shop by Category"}</h2>
      {section.subtitle && <p className="mb-5 text-sm text-muted-foreground">{section.subtitle}</p>}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4">
        {categories.map((c) => (
          <Link
            key={c.id}
            href={`/category/${c.slug ?? c.id}`}
            className="flex items-center justify-center rounded-lg border border-border bg-card px-4 py-6 text-center text-sm font-medium transition-colors hover:border-primary hover:text-primary"
          >
            {c.categoryName}
          </Link>
        ))}
      </div>
    </section>
  );
}

async function FeaturedProductsSection({ section }: { section: HomepageSection }) {
  const ids = idList(section.dataSource?.ids);
  let products: PublicProduct[];
  if (ids.length) {
    const results = await Promise.all(ids.map((id) => getProduct(id).catch(() => null)));
    // getProduct now returns the richer PublicProductDetail (a PublicProduct
    // superset) — narrow to that concrete type first so the `S extends T`
    // constraint on Array.filter's type-guard overload is satisfied, then
    // it's assignable to PublicProduct[] structurally.
    products = results.filter((p): p is PublicProductDetail => p !== null);
  } else {
    const res = await getProducts({ limit: 8, sort: "newest" }).catch(() => null);
    products = res?.data ?? [];
  }

  return (
    <section>
      <div className="mb-5 flex items-center justify-between">
        <h2 className="text-xl font-semibold">{section.title || "Featured Products"}</h2>
        <Link href="/shop" className="text-sm text-primary hover:underline">
          View all
        </Link>
      </div>
      {section.subtitle && <p className="mb-5 text-sm text-muted-foreground">{section.subtitle}</p>}
      {products.length > 0 ? (
        <ProductGrid products={products} />
      ) : (
        <p className="text-sm text-muted-foreground">No products available yet — check back soon.</p>
      )}
    </section>
  );
}

async function PopularBrandsSection({ section }: { section: HomepageSection }) {
  const all = await getBrands().catch(() => []);
  const ids = idList(section.dataSource?.ids);
  const brands = ids.length ? all.filter((b) => ids.includes(b.id)) : all;
  if (brands.length === 0) return null;

  return (
    <section>
      <h2 className="mb-5 text-xl font-semibold">{section.title || "Shop by Brand"}</h2>
      {section.subtitle && <p className="mb-5 text-sm text-muted-foreground">{section.subtitle}</p>}
      <div className="flex flex-wrap gap-3">
        {brands.map((b) => (
          <Link
            key={b.id}
            href={`/shop?brandId=${b.id}`}
            className="rounded-full border border-border px-4 py-2 text-sm font-medium hover:border-primary hover:text-primary"
          >
            {b.brandName}
          </Link>
        ))}
      </div>
    </section>
  );
}

function WhyChooseUsSection({ section }: { section: HomepageSection }) {
  const points = items(section.content?.items);
  if (points.length === 0) return null;

  return (
    <section>
      <h2 className="mb-5 text-xl font-semibold">{section.title || "Why Buy From Us"}</h2>
      {section.subtitle && <p className="mb-5 text-sm text-muted-foreground">{section.subtitle}</p>}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {points.map((point, i) => (
          <div key={i} className="rounded-lg border border-border p-4">
            <h3 className="font-medium">{point.title}</h3>
            <p className="mt-1 text-sm text-muted-foreground">{point.text}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

function PromotionalBannerSection({ section }: { section: HomepageSection }) {
  const cta = str(section.content?.ctaLabel);
  const ctaLink = str(section.content?.ctaLink) || "/shop";

  return (
    <section className="overflow-hidden rounded-xl border border-border">
      {section.imageUrl && (
        // Full image shown at its natural aspect ratio (object-contain, no
        // forced max-height) — a fixed crop was cutting off promotional
        // images that weren't shot at this section's aspect ratio.
        // eslint-disable-next-line @next/next/no-img-element
        <img src={section.imageUrl} alt={section.title || ""} className="w-full h-auto object-contain bg-secondary/30" />
      )}
      <div className="p-6 text-center">
        {section.title && <h2 className="text-xl font-semibold">{section.title}</h2>}
        {section.subtitle && <p className="mt-2 text-sm text-muted-foreground">{section.subtitle}</p>}
        {cta && (
          <Link href={ctaLink} className={`${buttonVariants({ size: "lg" })} mt-4 inline-flex`}>
            {cta}
          </Link>
        )}
      </div>
    </section>
  );
}

function TestimonialsSection({ section }: { section: HomepageSection }) {
  const testimonials = items(section.content?.items);

  return (
    <section>
      <h2 className="mb-5 text-xl font-semibold">{section.title || "Customer Reviews"}</h2>
      {testimonials.length > 0 ? (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {testimonials.map((t, i) => (
            <div key={i} className="rounded-lg border border-border p-4">
              <p className="text-sm text-muted-foreground">&ldquo;{t.text}&rdquo;</p>
              {t.name && <p className="mt-2 text-sm font-medium">— {t.name}</p>}
            </div>
          ))}
        </div>
      ) : (
        <div className="rounded-lg border border-dashed border-border py-12 text-center text-sm text-muted-foreground">
          No reviews yet — be the first to shop with us.
        </div>
      )}
    </section>
  );
}

function FaqSection({ section }: { section: HomepageSection }) {
  const faqs = items(section.content?.items);
  if (faqs.length === 0) return null;

  return (
    <section>
      <h2 className="mb-5 text-xl font-semibold">{section.title || "Frequently Asked Questions"}</h2>
      <div className="divide-y divide-border rounded-lg border border-border">
        {faqs.map((item, i) => (
          <details key={i} className="group p-4">
            <summary className="cursor-pointer list-none font-medium marker:content-none">{item.question}</summary>
            <p className="mt-2 text-sm text-muted-foreground">{item.answer}</p>
          </details>
        ))}
      </div>
    </section>
  );
}

function CustomContentSection({ section }: { section: HomepageSection }) {
  const body = str(section.content?.body);
  if (!body) return null;

  return (
    <section>
      {section.title && <h2 className="mb-5 text-xl font-semibold">{section.title}</h2>}
      <div dangerouslySetInnerHTML={{ __html: body }} />
    </section>
  );
}

export default async function HomePage() {
  const sections = (await getHomepageSections().catch(() => [])).filter((s) => s.enabled);

  return (
    <div className="container space-y-16 py-10">
      {sections.map((section) => {
        switch (section.type) {
          case "HERO_BANNER":
            return <HeroBannerSection key={section.id} section={section} />;
          case "SHOP_BY_CATEGORY":
            return <ShopByCategorySection key={section.id} section={section} />;
          case "FEATURED_PRODUCTS":
            return <FeaturedProductsSection key={section.id} section={section} />;
          case "POPULAR_BRANDS":
            return <PopularBrandsSection key={section.id} section={section} />;
          case "WHY_CHOOSE_US":
            return <WhyChooseUsSection key={section.id} section={section} />;
          case "PROMOTIONAL_BANNER":
            return <PromotionalBannerSection key={section.id} section={section} />;
          case "TESTIMONIALS":
            return <TestimonialsSection key={section.id} section={section} />;
          case "FAQ":
            return <FaqSection key={section.id} section={section} />;
          case "CUSTOM_CONTENT":
            return <CustomContentSection key={section.id} section={section} />;
          default:
            return null;
        }
      })}
    </div>
  );
}
