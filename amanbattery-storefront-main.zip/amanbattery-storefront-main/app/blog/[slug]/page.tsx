import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { getBlogPost } from "@/lib/api/blog";
import type { ApiError } from "@/lib/api/client";
import ProductGrid from "@/components/product/ProductGrid";
import { SITE_URL } from "@/lib/seo";

async function loadPost(slug: string) {
  return getBlogPost(slug).catch((err: ApiError) => {
    if (err?.status === 404) return null;
    throw err;
  });
}

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const post = await loadPost(params.slug);
  if (!post) return {};

  return {
    title: post.seoTitle || post.title,
    description: post.seoDescription || post.excerpt || undefined,
    alternates: { canonical: `${SITE_URL}/blog/${post.slug}` },
    openGraph: {
      title: post.seoTitle || post.title,
      description: post.seoDescription || post.excerpt || undefined,
      images: post.featuredImageUrl ? [post.featuredImageUrl] : undefined,
    },
  };
}

export default async function BlogPostPage({ params }: { params: { slug: string } }) {
  const post = await loadPost(params.slug);
  if (!post) notFound();

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Article",
    headline: post.title,
    image: post.featuredImageUrl ? [post.featuredImageUrl] : undefined,
    datePublished: post.publishedAt ?? undefined,
    dateModified: post.updatedAt,
    author: post.author ? { "@type": "Person", name: post.author.name } : undefined,
  };

  return (
    <div className="container max-w-3xl space-y-6 py-8">
      {/* eslint-disable-next-line react/no-danger -- static JSON-LD built above, not user input */}
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <nav className="text-sm text-muted-foreground">
        <Link href="/blog" className="hover:text-primary">Blog</Link>
        {post.category && (
          <>
            <span className="mx-1">/</span>
            <Link href={`/blog?category=${encodeURIComponent(post.category.slug)}`} className="hover:text-primary">
              {post.category.name}
            </Link>
          </>
        )}
      </nav>

      <div>
        <h1 className="text-2xl font-semibold">{post.title}</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          {post.author?.name && `By ${post.author.name} · `}
          {post.publishedAt && new Date(post.publishedAt).toLocaleDateString("en-IN", { year: "numeric", month: "long", day: "numeric" })}
        </p>
      </div>

      {post.featuredImageUrl && (
        <div className="relative aspect-video w-full overflow-hidden rounded-lg bg-secondary/40">
          <Image src={post.featuredImageUrl} alt={post.title} fill sizes="768px" className="object-cover" />
        </div>
      )}

      {/* eslint-disable-next-line react/no-danger -- admin-authored content, same pattern as CMS Pages */}
      <div
        className="max-w-none space-y-4 text-sm leading-relaxed text-foreground [&_a]:text-primary [&_a]:underline-offset-4 [&_a]:hover:underline [&_h2]:text-lg [&_h2]:font-semibold [&_h3]:text-base [&_h3]:font-semibold [&_li]:ml-4 [&_ol]:list-decimal [&_ul]:list-disc"
        dangerouslySetInnerHTML={{ __html: post.content }}
      />

      {post.relatedProducts.length > 0 && (
        <section className="border-t border-border pt-6">
          <h2 className="mb-3 text-lg font-semibold">Related Products</h2>
          <ProductGrid products={post.relatedProducts} />
        </section>
      )}

      {post.relatedPosts.length > 0 && (
        <section className="border-t border-border pt-6">
          <h2 className="mb-3 text-lg font-semibold">Related Articles</h2>
          <ul className="space-y-2">
            {post.relatedPosts.map((p) => (
              <li key={p.id}>
                <Link href={`/blog/${encodeURIComponent(p.slug)}`} className="text-sm font-medium hover:text-primary">
                  {p.title}
                </Link>
              </li>
            ))}
          </ul>
        </section>
      )}
    </div>
  );
}
