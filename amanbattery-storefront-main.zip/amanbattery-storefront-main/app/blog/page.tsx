import Image from "next/image";
import Link from "next/link";
import type { Metadata } from "next";
import { getBlogCategories, getBlogPosts } from "@/lib/api/blog";
import Pagination from "@/components/product/Pagination";
import { SITE_URL, SITE_NAME } from "@/lib/seo";

export async function generateMetadata(): Promise<Metadata> {
  return {
    title: "Blog & Guides",
    description: `Battery, inverter and power product guides, comparisons and maintenance tips from ${SITE_NAME}.`,
    alternates: { canonical: `${SITE_URL}/blog` },
  };
}

export default async function BlogIndexPage({
  searchParams,
}: {
  searchParams: Record<string, string | undefined>;
}) {
  const page = searchParams.page ? parseInt(searchParams.page, 10) : 1;
  const [categories, result] = await Promise.all([
    getBlogCategories().catch(() => []),
    getBlogPosts({ category: searchParams.category, page }).catch(() => null),
  ]);

  return (
    <div className="container space-y-6 py-8">
      <div>
        <h1 className="text-2xl font-semibold">Blog &amp; Guides</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Battery, inverter and power product guides, comparisons and maintenance tips.
        </p>
      </div>

      {categories.length > 0 && (
        <div className="flex flex-wrap gap-2">
          <Link
            href="/blog"
            className={`rounded-full px-3 py-1 text-sm ${!searchParams.category ? "bg-primary text-primary-foreground" : "bg-secondary text-secondary-foreground"}`}
          >
            All
          </Link>
          {categories.map((c) => (
            <Link
              key={c.id}
              href={`/blog?category=${encodeURIComponent(c.slug)}`}
              className={`rounded-full px-3 py-1 text-sm ${searchParams.category === c.slug ? "bg-primary text-primary-foreground" : "bg-secondary text-secondary-foreground"}`}
            >
              {c.name}
            </Link>
          ))}
        </div>
      )}

      {!result ? (
        <p className="text-sm text-destructive">Couldn&apos;t load articles right now — please try again.</p>
      ) : result.data.length === 0 ? (
        <div className="rounded-lg border border-dashed border-border py-16 text-center text-sm text-muted-foreground">
          No articles published yet — check back soon.
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {result.data.map((post) => (
              <Link key={post.id} href={`/blog/${encodeURIComponent(post.slug)}`} className="group flex flex-col overflow-hidden rounded-lg border border-border">
                <div className="relative aspect-video w-full bg-secondary/40">
                  {post.featuredImageUrl ? (
                    <Image src={post.featuredImageUrl} alt={post.title} fill sizes="(min-width: 1024px) 33vw, 50vw" className="object-cover" />
                  ) : (
                    <div className="flex h-full items-center justify-center text-xs text-muted-foreground">No image</div>
                  )}
                </div>
                <div className="flex flex-1 flex-col gap-1 p-4">
                  {post.category && <span className="text-xs text-muted-foreground">{post.category.name}</span>}
                  <h2 className="line-clamp-2 text-base font-semibold group-hover:text-primary">{post.title}</h2>
                  {post.excerpt && <p className="line-clamp-2 text-sm text-muted-foreground">{post.excerpt}</p>}
                </div>
              </Link>
            ))}
          </div>
          <Pagination basePath="/blog" searchParams={searchParams} page={result.page} pages={result.pages} />
        </>
      )}
    </div>
  );
}
