import type { Metadata } from "next";
import LegalPageLayout from "@/components/legal/LegalPageLayout";
import { whatsappDisplayNumber } from "@/lib/whatsapp";
import { SITE_URL } from "@/lib/seo";
import { getPageBySlug } from "@/lib/api/pages";
import { getWebsiteConfig } from "@/lib/api/website-config";

const SLUG = "shipping-policy";

export async function generateMetadata(): Promise<Metadata> {
  const page = await getPageBySlug(SLUG);
  return {
    title: page?.seoTitle || "Shipping Policy",
    description: page?.seoDescription || "Delivery information for Amanbattery.com orders.",
    alternates: { canonical: `${SITE_URL}/${SLUG}` },
  };
}

export default async function ShippingPolicyPage() {
  const [page, config] = await Promise.all([getPageBySlug(SLUG), getWebsiteConfig().catch(() => null)]);
  const waNumber = config?.contact?.whatsapp;

  if (page) {
    return (
      <LegalPageLayout title={page.title}>
        <div dangerouslySetInnerHTML={{ __html: page.content }} />
      </LegalPageLayout>
    );
  }

  return (
    <LegalPageLayout title="Shipping Policy">
      <p>We deliver pan-India through our courier partners.</p>

      <h2>Delivery Timelines</h2>
      <p>
        Delivery time depends on your location and the specific product, so we confirm an estimated
        delivery window with you directly on WhatsApp when your order is placed, rather than
        promising a fixed number of days upfront.
      </p>

      <h2>Shipping Charges</h2>
      <p>
        Any shipping charges (if applicable) are confirmed along with the order total before you
        confirm the order.
      </p>

      <h2>Order Tracking</h2>
      <p>
        Once your order ships, we&apos;ll share the courier tracking details with you on WhatsApp.
      </p>

      <h2>Contact</h2>
      <p>
        For a delivery estimate before ordering, or a status update on an existing order, message us
        on WhatsApp: {whatsappDisplayNumber(waNumber)}.
      </p>
    </LegalPageLayout>
  );
}
