import type { Metadata } from "next";
import FilterBar from "@/components/product/FilterBar";
import Pagination from "@/components/product/Pagination";
import ProductGrid from "@/components/product/ProductGrid";
import { getBrands } from "@/lib/api/brands";
import { getCategories } from "@/lib/api/categories";
import { getProducts } from "@/lib/api/products";
import type { ProductListFilters } from "@/lib/api/types";
import { SITE_URL } from "@/lib/seo";

const SORT_VALUES: ProductListFilters["sort"][] = ["price_asc", "price_desc", "newest"];

export function generateMetadata({ searchParams }: { searchParams: { search?: string } }): Metadata {
  return searchParams.search
    ? { title: `Results for "${searchParams.search}"`, alternates: { canonical: `${SITE_URL}/shop` } }
    : { title: "Shop All Products", alternates: { canonical: `${SITE_URL}/shop` } };
}

// Generic listing — backs "Shop All", brand links, category-filter links,
// and search results. Category/brand/sort filters and pagination all live
// in the URL (via FilterBar/Pagination), not local state, so results are
// shareable/bookmarkable links.
export default async function ShopPage({
  searchParams,
}: {
  searchParams: { search?: string; brandId?: string; categoryId?: string; sort?: string; page?: string };
}) {
  const page = searchParams.page ? parseInt(searchParams.page, 10) : 1;
  const sort = SORT_VALUES.includes(searchParams.sort as ProductListFilters["sort"])
    ? (searchParams.sort as ProductListFilters["sort"])
    : undefined;

  const [categories, brands, result] = await Promise.all([
    getCategories().catch(() => []),
    getBrands().catch(() => []),
    getProducts({
      search: searchParams.search,
      brandId: searchParams.brandId,
      categoryId: searchParams.categoryId,
      sort,
      page,
    }).catch(() => null),
  ]);

  const heading = searchParams.search ? `Results for "${searchParams.search}"` : "Shop All Products";

  return (
    <div className="container space-y-6 py-8">
      <h1 className="text-2xl font-semibold">{heading}</h1>
      <FilterBar categories={categories} brands={brands} basePath="/shop" />
      {result ? (
        <>
          <p className="text-sm text-muted-foreground">{result.total} product{result.total !== 1 ? "s" : ""}</p>
          <ProductGrid products={result.data} />
          <Pagination basePath="/shop" searchParams={searchParams} page={result.page} pages={result.pages} />
        </>
      ) : (
        <p className="text-sm text-destructive">Couldn&apos;t load products right now — please try again.</p>
      )}
    </div>
  );
}
