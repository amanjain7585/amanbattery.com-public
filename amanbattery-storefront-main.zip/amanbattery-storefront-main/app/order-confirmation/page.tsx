import Link from "next/link";
import { MessageCircle } from "lucide-react";
import { buttonVariants } from "@/components/ui/button";
import { whatsappDisplayNumber, whatsappLink } from "@/lib/whatsapp";
import { getWebsiteConfig } from "@/lib/api/website-config";
import { cn } from "@/lib/utils";

export default async function OrderConfirmationPage({
  searchParams,
}: {
  searchParams: { order?: string; phone?: string; paid?: string };
}) {
  const orderNumber = searchParams.order;
  const isPrepaid = searchParams.paid === "1";
  const config = await getWebsiteConfig().catch(() => null);
  const waNumber = config?.contact?.whatsapp;

  return (
    <div className="container flex min-h-[60vh] flex-col items-center justify-center gap-4 py-16 text-center">
      <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/10 text-3xl">✓</div>
      <h1 className="text-2xl font-semibold">{isPrepaid ? "Payment Received!" : "Order Placed!"}</h1>
      {orderNumber && (
        <p className="text-sm text-muted-foreground">
          Order number: <span className="font-mono font-medium text-foreground">{orderNumber}</span>
        </p>
      )}
      <p className="max-w-md text-sm text-muted-foreground">
        {isPrepaid
          ? `We've received your payment. We'll call you${searchParams.phone ? ` on ${searchParams.phone}` : ""} to confirm your order before shipping.`
          : `We'll call you${searchParams.phone ? ` on ${searchParams.phone}` : ""} to confirm your order before shipping. This is a Cash on Delivery order — pay when it arrives.`}
      </p>
      <div className="mt-4 flex flex-col gap-3 sm:flex-row">
        <Link href="/shop" className={buttonVariants({ variant: "outline" })}>
          Continue Shopping
        </Link>
        <a
          href={whatsappLink(orderNumber ? `Hi, I just placed order ${orderNumber} and have a question.` : "Hi, I have a question about my order.", waNumber)}
          target="_blank"
          rel="noopener noreferrer"
          className={cn(buttonVariants(), "gap-2")}
        >
          <MessageCircle className="h-4 w-4" fill="currentColor" strokeWidth={0} />
          Questions? WhatsApp us: {whatsappDisplayNumber(waNumber)}
        </a>
      </div>
    </div>
  );
}
