import type { Metadata } from "next";
import { MessageCircle, Phone, Mail, MapPin, Clock } from "lucide-react";
import LegalPageLayout from "@/components/legal/LegalPageLayout";
import { buttonVariants } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { whatsappDisplayNumber, whatsappLink } from "@/lib/whatsapp";
import { getWebsiteConfig } from "@/lib/api/website-config";
import { getPageBySlug } from "@/lib/api/pages";
import { SITE_URL } from "@/lib/seo";

const SLUG = "contact";

export async function generateMetadata(): Promise<Metadata> {
  const page = await getPageBySlug(SLUG);
  return {
    title: page?.seoTitle || "Contact Us",
    description: page?.seoDescription || "Reach Amanbattery.com via WhatsApp for orders, questions, or support.",
    alternates: { canonical: `${SITE_URL}/${SLUG}` },
  };
}

export default async function ContactPage() {
  const [config, page] = await Promise.all([
    getWebsiteConfig().catch(() => null),
    getPageBySlug(SLUG),
  ]);
  const contact = config?.contact;

  return (
    <LegalPageLayout title={page?.title || "Contact Us"}>
      {page ? (
        <div dangerouslySetInnerHTML={{ __html: page.content }} />
      ) : (
        <p>
          You can order directly through the site, or reach us on WhatsApp — for product questions,
          delivery timelines, or support on an existing order.
        </p>
      )}
      <a
        href={whatsappLink("Hi, I'd like to get in touch about Amanbattery.com", contact?.whatsapp)}
        target="_blank"
        rel="noopener noreferrer"
        className={cn(buttonVariants({ variant: "accent", size: "lg" }), "gap-2")}
      >
        <MessageCircle className="h-5 w-5" fill="currentColor" strokeWidth={0} />
        Chat on WhatsApp: {whatsappDisplayNumber(contact?.whatsapp)}
      </a>

      {contact && (contact.phone || contact.email || contact.address || contact.businessHours) && (
        <div className="mt-6 space-y-3 rounded-lg border border-border p-4 not-prose">
          {contact.businessName && <p className="font-semibold text-foreground">{contact.businessName}</p>}
          {contact.phone && (
            <p className="flex items-center gap-2 text-sm text-muted-foreground">
              <Phone className="h-4 w-4 shrink-0" />
              <a href={`tel:${contact.phone}`} className="hover:text-primary">
                {contact.phone}
              </a>
            </p>
          )}
          {contact.email && (
            <p className="flex items-center gap-2 text-sm text-muted-foreground">
              <Mail className="h-4 w-4 shrink-0" />
              <a href={`mailto:${contact.email}`} className="hover:text-primary">
                {contact.email}
              </a>
            </p>
          )}
          {contact.address && (
            <p className="flex items-start gap-2 text-sm text-muted-foreground">
              <MapPin className="h-4 w-4 shrink-0 mt-0.5" />
              <span>
                {contact.address}
                {contact.city ? `, ${contact.city}` : ""}
                {contact.state ? `, ${contact.state}` : ""}
                {contact.pincode ? ` - ${contact.pincode}` : ""}
              </span>
            </p>
          )}
          {contact.businessHours && (
            <p className="flex items-center gap-2 text-sm text-muted-foreground">
              <Clock className="h-4 w-4 shrink-0" />
              {contact.businessHours}
            </p>
          )}
          {contact.googleMapsEmbed && (
            <div
              className="mt-3 overflow-hidden rounded-lg [&_iframe]:w-full"
              dangerouslySetInnerHTML={{ __html: contact.googleMapsEmbed }}
            />
          )}
        </div>
      )}
    </LegalPageLayout>
  );
}
