import type { Metadata } from "next";
import LoadCalculator from "@/components/calculators/LoadCalculator";
import BackupCalculator from "@/components/calculators/BackupCalculator";
import { SITE_URL, SITE_NAME } from "@/lib/seo";

const SLUG = "inverter-calculator";

export async function generateMetadata(): Promise<Metadata> {
  return {
    title: "Inverter & Backup Calculator — Size Your Inverter and Battery",
    description: `Calculate the inverter VA and battery capacity you need, or estimate backup time from a battery's capacity — with real in-stock recommendations from ${SITE_NAME}.`,
    alternates: { canonical: `${SITE_URL}/${SLUG}` },
  };
}

export default function InverterCalculatorPage() {
  return (
    <div className="container max-w-3xl space-y-8 py-8">
      <div>
        <h1 className="text-2xl font-semibold">Inverter &amp; Backup Calculator</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Work out the right inverter and battery for your home, or check how long a battery will back up your load.
        </p>
      </div>
      <LoadCalculator />
      <BackupCalculator />
    </div>
  );
}
