"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Input } from "@/components/ui/input";
import { Button, buttonVariants } from "@/components/ui/button";
import { useAuth } from "@/lib/auth/AuthContext";
import * as authApi from "@/lib/api/auth";
import { cn } from "@/lib/utils";
import type { ApiError } from "@/lib/api/client";

export default function SignupPage() {
  const router = useRouter();
  const { setToken } = useAuth();
  const [form, setForm] = useState({ name: "", phone: "", password: "" });
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    try {
      const res = await authApi.signup(form);
      await setToken(res.accessToken);
      router.push("/account");
    } catch (err) {
      setError((err as ApiError)?.message || "Could not create account");
      setSubmitting(false);
    }
  }

  return (
    <div className="container max-w-sm space-y-6 py-12">
      <h1 className="text-2xl font-semibold">Create an Account</h1>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-1.5">
          <label className="text-sm font-medium">Full Name</label>
          <Input required value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} />
        </div>
        <div className="space-y-1.5">
          <label className="text-sm font-medium">Phone Number</label>
          <Input
            required
            inputMode="numeric"
            placeholder="10-digit mobile number"
            value={form.phone}
            onChange={(e) => setForm((f) => ({ ...f, phone: e.target.value.replace(/[^\d+]/g, "") }))}
          />
        </div>
        <div className="space-y-1.5">
          <label className="text-sm font-medium">Password</label>
          <Input
            required
            type="password"
            minLength={8}
            value={form.password}
            onChange={(e) => setForm((f) => ({ ...f, password: e.target.value }))}
          />
          <p className="text-xs text-muted-foreground">At least 8 characters.</p>
        </div>
        {error && <p className="text-sm text-destructive">{error}</p>}
        <Button type="submit" className="w-full" disabled={submitting}>
          {submitting ? "Creating account..." : "Create Account"}
        </Button>
      </form>

      <p className="text-center text-sm text-muted-foreground">
        Already have an account?{" "}
        <Link href="/account/login" className={cn(buttonVariants({ variant: "link" }), "h-auto p-0")}>
          Log in
        </Link>
      </p>
    </div>
  );
}
