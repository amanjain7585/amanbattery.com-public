"use client";

import { Suspense, useEffect, useRef, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import { Input } from "@/components/ui/input";
import { Button, buttonVariants } from "@/components/ui/button";
import { useAuth } from "@/lib/auth/AuthContext";
import * as authApi from "@/lib/api/auth";
import { renderGoogleSignInButton } from "@/lib/google-auth";
import { cn } from "@/lib/utils";
import type { ApiError } from "@/lib/api/client";

type Tab = "password" | "otp";

// useSearchParams() requires a Suspense boundary for static export.
export default function LoginPage() {
  return (
    <Suspense>
      <LoginForm />
    </Suspense>
  );
}

function LoginForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const redirectTo = searchParams.get("redirect") || "/account";
  const { setToken } = useAuth();
  const googleButtonRef = useRef<HTMLDivElement>(null);

  const [tab, setTab] = useState<Tab>("password");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");

  const [otpSent, setOtpSent] = useState(false);
  const [code, setCode] = useState("");

  useEffect(() => {
    if (googleButtonRef.current) {
      renderGoogleSignInButton(googleButtonRef.current, async (idToken) => {
        setError(null);
        try {
          const res = await authApi.googleLogin(idToken);
          await setToken(res.accessToken);
          router.push(redirectTo);
        } catch (err) {
          setError((err as ApiError)?.message || "Google sign-in failed");
        }
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function handlePasswordLogin(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    try {
      const res = await authApi.login({ phone, password });
      await setToken(res.accessToken);
      router.push(redirectTo);
    } catch (err) {
      setError((err as ApiError)?.message || "Login failed");
    } finally {
      setSubmitting(false);
    }
  }

  async function handleRequestOtp(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    try {
      await authApi.requestOtp(phone);
      setOtpSent(true);
    } catch (err) {
      setError((err as ApiError)?.message || "Could not send OTP");
    } finally {
      setSubmitting(false);
    }
  }

  async function handleOtpLogin(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    try {
      const res = await authApi.otpLogin({ phone, code });
      await setToken(res.accessToken);
      router.push(redirectTo);
    } catch (err) {
      setError((err as ApiError)?.message || "Invalid OTP");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="container max-w-sm space-y-6 py-12">
      <h1 className="text-2xl font-semibold">Log In</h1>

      <div className="grid grid-cols-2 gap-2">
        <button
          type="button"
          onClick={() => { setTab("password"); setError(null); }}
          className={cn(
            "rounded-lg border p-2 text-sm font-medium",
            tab === "password" ? "border-primary bg-primary/5" : "text-muted-foreground",
          )}
        >
          Password
        </button>
        <button
          type="button"
          onClick={() => { setTab("otp"); setError(null); }}
          className={cn(
            "rounded-lg border p-2 text-sm font-medium",
            tab === "otp" ? "border-primary bg-primary/5" : "text-muted-foreground",
          )}
        >
          OTP
        </button>
      </div>

      {tab === "password" && (
        <form onSubmit={handlePasswordLogin} className="space-y-4">
          <div className="space-y-1.5">
            <label className="text-sm font-medium">Phone Number</label>
            <Input required inputMode="numeric" value={phone} onChange={(e) => setPhone(e.target.value.replace(/[^\d+]/g, ""))} />
          </div>
          <div className="space-y-1.5">
            <label className="text-sm font-medium">Password</label>
            <Input required type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
          </div>
          <div className="text-right text-xs">
            <Link href="/account/forgot-password" className="text-primary hover:underline">
              Forgot password?
            </Link>
          </div>
          {error && <p className="text-sm text-destructive">{error}</p>}
          <Button type="submit" className="w-full" disabled={submitting}>
            {submitting ? "Logging in..." : "Log In"}
          </Button>
        </form>
      )}

      {tab === "otp" && !otpSent && (
        <form onSubmit={handleRequestOtp} className="space-y-4">
          <div className="space-y-1.5">
            <label className="text-sm font-medium">Phone Number</label>
            <Input required inputMode="numeric" value={phone} onChange={(e) => setPhone(e.target.value.replace(/[^\d+]/g, ""))} />
          </div>
          {error && <p className="text-sm text-destructive">{error}</p>}
          <Button type="submit" className="w-full" disabled={submitting}>
            {submitting ? "Sending..." : "Send OTP"}
          </Button>
        </form>
      )}

      {tab === "otp" && otpSent && (
        <form onSubmit={handleOtpLogin} className="space-y-4">
          <p className="text-sm text-muted-foreground">Enter the code sent to {phone}.</p>
          <div className="space-y-1.5">
            <label className="text-sm font-medium">OTP Code</label>
            <Input required inputMode="numeric" maxLength={6} value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, ""))} />
          </div>
          {error && <p className="text-sm text-destructive">{error}</p>}
          <Button type="submit" className="w-full" disabled={submitting}>
            {submitting ? "Verifying..." : "Verify & Log In"}
          </Button>
          <button type="button" className="text-xs text-muted-foreground hover:underline" onClick={() => setOtpSent(false)}>
            Change phone number
          </button>
        </form>
      )}

      <div className="flex items-center gap-3 text-xs text-muted-foreground">
        <div className="h-px flex-1 bg-border" />
        or
        <div className="h-px flex-1 bg-border" />
      </div>

      <div ref={googleButtonRef} className="flex justify-center" />

      <p className="text-center text-sm text-muted-foreground">
        New here?{" "}
        <Link href="/account/signup" className={cn(buttonVariants({ variant: "link" }), "h-auto p-0")}>
          Create an account
        </Link>
      </p>
    </div>
  );
}
