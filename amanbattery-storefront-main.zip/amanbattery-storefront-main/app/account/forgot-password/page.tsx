"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import * as authApi from "@/lib/api/auth";
import type { ApiError } from "@/lib/api/client";

type Step = "request" | "reset" | "done";

export default function ForgotPasswordPage() {
  const router = useRouter();
  const [step, setStep] = useState<Step>("request");
  const [phone, setPhone] = useState("");
  const [code, setCode] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  async function handleRequest(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    try {
      await authApi.forgotPassword(phone);
      setStep("reset");
    } catch (err) {
      setError((err as ApiError)?.message || "Could not send OTP");
    } finally {
      setSubmitting(false);
    }
  }

  async function handleReset(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    try {
      await authApi.resetPassword({ phone, code, newPassword });
      setStep("done");
    } catch (err) {
      setError((err as ApiError)?.message || "Could not reset password");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="container max-w-sm space-y-6 py-12">
      <h1 className="text-2xl font-semibold">Reset Password</h1>

      {step === "request" && (
        <form onSubmit={handleRequest} className="space-y-4">
          <div className="space-y-1.5">
            <label className="text-sm font-medium">Phone Number</label>
            <Input required inputMode="numeric" value={phone} onChange={(e) => setPhone(e.target.value.replace(/[^\d+]/g, ""))} />
          </div>
          {error && <p className="text-sm text-destructive">{error}</p>}
          <Button type="submit" className="w-full" disabled={submitting}>
            {submitting ? "Sending..." : "Send Reset Code"}
          </Button>
        </form>
      )}

      {step === "reset" && (
        <form onSubmit={handleReset} className="space-y-4">
          <p className="text-sm text-muted-foreground">Enter the code sent to {phone} and choose a new password.</p>
          <div className="space-y-1.5">
            <label className="text-sm font-medium">OTP Code</label>
            <Input required inputMode="numeric" maxLength={6} value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, ""))} />
          </div>
          <div className="space-y-1.5">
            <label className="text-sm font-medium">New Password</label>
            <Input required type="password" minLength={8} value={newPassword} onChange={(e) => setNewPassword(e.target.value)} />
          </div>
          {error && <p className="text-sm text-destructive">{error}</p>}
          <Button type="submit" className="w-full" disabled={submitting}>
            {submitting ? "Resetting..." : "Reset Password"}
          </Button>
        </form>
      )}

      {step === "done" && (
        <div className="space-y-4">
          <p className="text-sm text-muted-foreground">Your password has been reset. You can now log in.</p>
          <Button className="w-full" onClick={() => router.push("/account/login")}>
            Go to Login
          </Button>
        </div>
      )}

      <p className="text-center text-sm">
        <Link href="/account/login" className="text-primary hover:underline">
          Back to login
        </Link>
      </p>
    </div>
  );
}
