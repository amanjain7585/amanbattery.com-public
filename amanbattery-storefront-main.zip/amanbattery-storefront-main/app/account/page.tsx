"use client";

import { useEffect, useState, useCallback } from "react";
import { useRouter } from "next/navigation";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/auth/AuthContext";
import * as authApi from "@/lib/api/auth";
import type { CustomerAddress, CustomerOrder } from "@/lib/api/types";
import { formatINR } from "@/lib/utils";

const EMPTY_ADDRESS = {
  label: "",
  recipientName: "",
  phone: "",
  addressLine: "",
  addressLine2: "",
  city: "",
  state: "",
  pincode: "",
};

export default function AccountPage() {
  const router = useRouter();
  const { token, customer, hydrated, isLoggedIn, logout } = useAuth();

  const [addresses, setAddresses] = useState<CustomerAddress[]>([]);
  const [orders, setOrders] = useState<CustomerOrder[]>([]);
  const [addingAddress, setAddingAddress] = useState(false);
  const [addressForm, setAddressForm] = useState(EMPTY_ADDRESS);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (hydrated && !isLoggedIn) router.replace("/account/login?redirect=/account");
  }, [hydrated, isLoggedIn, router]);

  const loadData = useCallback(async () => {
    if (!token) return;
    const [addressList, orderList] = await Promise.all([
      authApi.listAddresses(token).catch(() => []),
      authApi.listOrders(token).catch(() => []),
    ]);
    setAddresses(addressList);
    setOrders(orderList);
  }, [token]);

  useEffect(() => {
    if (token) loadData();
  }, [token, loadData]);

  async function handleAddAddress(e: React.FormEvent) {
    e.preventDefault();
    if (!token) return;
    setSaving(true);
    try {
      await authApi.createAddress(token, addressForm);
      setAddressForm(EMPTY_ADDRESS);
      setAddingAddress(false);
      loadData();
    } finally {
      setSaving(false);
    }
  }

  async function handleDeleteAddress(id: string) {
    if (!token) return;
    await authApi.deleteAddress(token, id);
    loadData();
  }

  if (!hydrated || !isLoggedIn) return null;

  return (
    <div className="container max-w-2xl space-y-8 py-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">My Account</h1>
          {customer && <p className="text-sm text-muted-foreground">{customer.name} — {customer.phone ?? customer.email}</p>}
        </div>
        <Button variant="outline" onClick={() => { logout(); router.push("/"); }}>
          Log Out
        </Button>
      </div>

      <section>
        <div className="mb-3 flex items-center justify-between">
          <h2 className="font-semibold">Saved Addresses</h2>
          <Button size="sm" variant="outline" onClick={() => setAddingAddress((a) => !a)}>
            Add Address
          </Button>
        </div>

        {addingAddress && (
          <form onSubmit={handleAddAddress} className="mb-4 space-y-3 rounded-lg border p-4">
            <div className="grid grid-cols-2 gap-3">
              <Input placeholder="Label (Home, Work)" value={addressForm.label} onChange={(e) => setAddressForm((f) => ({ ...f, label: e.target.value }))} />
              <Input required placeholder="Recipient Name" value={addressForm.recipientName} onChange={(e) => setAddressForm((f) => ({ ...f, recipientName: e.target.value }))} />
            </div>
            <Input required placeholder="Phone Number" value={addressForm.phone} onChange={(e) => setAddressForm((f) => ({ ...f, phone: e.target.value.replace(/[^\d+]/g, "") }))} />
            <Input required placeholder="Address Line" value={addressForm.addressLine} onChange={(e) => setAddressForm((f) => ({ ...f, addressLine: e.target.value }))} />
            <div className="grid grid-cols-3 gap-3">
              <Input required placeholder="City" value={addressForm.city} onChange={(e) => setAddressForm((f) => ({ ...f, city: e.target.value }))} />
              <Input required placeholder="State" value={addressForm.state} onChange={(e) => setAddressForm((f) => ({ ...f, state: e.target.value }))} />
              <Input required placeholder="Pincode" inputMode="numeric" maxLength={6} value={addressForm.pincode} onChange={(e) => setAddressForm((f) => ({ ...f, pincode: e.target.value.replace(/\D/g, "") }))} />
            </div>
            <Button type="submit" size="sm" disabled={saving}>{saving ? "Saving..." : "Save Address"}</Button>
          </form>
        )}

        {addresses.length === 0 ? (
          <p className="text-sm text-muted-foreground">No saved addresses yet.</p>
        ) : (
          <div className="space-y-2">
            {addresses.map((a) => (
              <div key={a.id} className="flex items-start justify-between rounded-lg border p-3 text-sm">
                <div>
                  {a.label && <div className="font-medium">{a.label}</div>}
                  <div>{a.recipientName} — {a.phone}</div>
                  <div className="text-muted-foreground">
                    {a.addressLine}{a.addressLine2 ? `, ${a.addressLine2}` : ""}, {a.city}, {a.state} {a.pincode}
                  </div>
                </div>
                <button type="button" className="text-xs text-destructive hover:underline" onClick={() => handleDeleteAddress(a.id)}>
                  Remove
                </button>
              </div>
            ))}
          </div>
        )}
      </section>

      <section>
        <h2 className="mb-3 font-semibold">Order History</h2>
        {orders.length === 0 ? (
          <p className="text-sm text-muted-foreground">No orders yet.</p>
        ) : (
          <div className="space-y-2">
            {orders.map((o) => (
              <div key={o.orderNumber} className="rounded-lg border p-3 text-sm">
                <div className="flex justify-between font-medium">
                  <span>{o.orderNumber}</span>
                  <span>{new Date(o.orderDate).toLocaleDateString()}</span>
                </div>
                <div className="text-muted-foreground">
                  {o.items.map((i) => `${i.productName} × ${i.quantity}`).join(", ")}
                </div>
                <div className="mt-1 flex justify-between text-xs text-muted-foreground">
                  <span>{o.paymentMethod === "PREPAID" ? `Paid (${o.paymentStatus})` : "Cash on Delivery"}</span>
                  <span>{formatINR(o.items.reduce((sum, i) => sum + i.amount, 0))}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
