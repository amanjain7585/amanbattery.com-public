import type { Metadata } from "next";
import LegalPageLayout from "@/components/legal/LegalPageLayout";
import { whatsappDisplayNumber } from "@/lib/whatsapp";
import { SITE_URL } from "@/lib/seo";
import { getPageBySlug } from "@/lib/api/pages";
import { getWebsiteConfig } from "@/lib/api/website-config";

const SLUG = "terms";

export async function generateMetadata(): Promise<Metadata> {
  const page = await getPageBySlug(SLUG);
  return {
    title: page?.seoTitle || "Terms & Conditions",
    description: page?.seoDescription || "Terms of use for Amanbattery.com.",
    alternates: { canonical: `${SITE_URL}/${SLUG}` },
  };
}

export default async function TermsPage() {
  const [page, config] = await Promise.all([getPageBySlug(SLUG), getWebsiteConfig().catch(() => null)]);
  const waNumber = config?.contact?.whatsapp;

  if (page) {
    return (
      <LegalPageLayout title={page.title}>
        <div dangerouslySetInnerHTML={{ __html: page.content }} />
      </LegalPageLayout>
    );
  }

  return (
    <LegalPageLayout title="Terms & Conditions">
      <p>By browsing or ordering from Amanbattery.com, you agree to the following terms.</p>

      <h2>Orders</h2>
      <p>
        Orders can be placed directly through checkout on this site, or discussed with us on
        WhatsApp before ordering. Pricing and availability shown on the site are current at the time
        you view them but can change before an order is confirmed — the price and details confirmed
        at checkout (or with us directly, for a WhatsApp order) are what apply to your order.
      </p>

      <h2>Products</h2>
      <p>
        We sell genuine battery, inverter, and power products sourced through authorized channels.
        Product images and descriptions are sourced from the manufacturer/marketplace listing and
        are as accurate as we can make them, but the physical product is the final source of truth.
      </p>

      <h2>Pricing</h2>
      <p>
        Prices shown are in Indian Rupees (INR) and may change without notice. The price confirmed
        with you at the time of order is the one that applies.
      </p>

      <h2>Limitation of Liability</h2>
      <p>
        We aren&apos;t liable for indirect or consequential losses arising from use of this website
        or products purchased through it, beyond what&apos;s required by applicable Indian consumer
        protection law.
      </p>

      <h2>Contact</h2>
      <p>Questions about these terms can be sent to us on WhatsApp: {whatsappDisplayNumber(waNumber)}.</p>
    </LegalPageLayout>
  );
}
