import type { Metadata } from "next";
import { notFound } from "next/navigation";
import LegalPageLayout from "@/components/legal/LegalPageLayout";
import { SITE_URL } from "@/lib/seo";
import { getPageBySlug } from "@/lib/api/pages";

// Generic handler for any Page created in OMS Admin > Website > Pages that
// isn't one of the specific pre-built routes (about, privacy-policy, etc)
// — those keep their own hardcoded-fallback route files. Next.js resolves
// static routes before this dynamic one, so this only catches slugs with
// no matching file-based route, e.g. a new "warranty-policy" page.
interface Props {
  params: { slug: string };
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const page = await getPageBySlug(params.slug);
  if (!page) return {};
  return {
    title: page.seoTitle || page.title,
    description: page.seoDescription || undefined,
    alternates: { canonical: `${SITE_URL}/${params.slug}` },
  };
}

export default async function CmsPage({ params }: Props) {
  const page = await getPageBySlug(params.slug);
  if (!page) notFound();

  return (
    <LegalPageLayout title={page.title}>
      <div dangerouslySetInnerHTML={{ __html: page.content }} />
    </LegalPageLayout>
  );
}
