"use client";

import Image from "next/image";
import Link from "next/link";
import { Minus, Plus } from "lucide-react";
import { buttonVariants } from "@/components/ui/button";
import PincodeChecker from "@/components/product/PincodeChecker";
import { useCart } from "@/lib/cart/CartContext";
import { formatINR, cn } from "@/lib/utils";

export default function CartPage() {
  const { items, subtotal, setQuantity, removeItem } = useCart();

  if (items.length === 0) {
    return (
      <div className="container flex min-h-[50vh] flex-col items-center justify-center gap-4 py-16 text-center">
        <h1 className="text-2xl font-semibold">Your cart is empty</h1>
        <p className="text-muted-foreground">Add some products to get started.</p>
        <Link href="/shop" className={buttonVariants()}>
          Continue Shopping
        </Link>
      </div>
    );
  }

  return (
    <div className="container max-w-3xl space-y-6 py-8">
      <h1 className="text-2xl font-semibold">Your Cart</h1>

      <div className="divide-y divide-border rounded-lg border border-border">
        {items.map((item) => (
          <div key={item.productId} className="flex gap-4 p-4">
            <div className="relative h-20 w-20 shrink-0 rounded-md bg-secondary/40">
              {item.image ? (
                <Image src={item.image} alt={item.title} fill sizes="80px" className="object-contain p-2" />
              ) : (
                <div className="flex h-full items-center justify-center text-[10px] text-muted-foreground">No image</div>
              )}
            </div>

            <div className="flex flex-1 flex-col gap-1">
              <Link href={`/product/${encodeURIComponent(item.slug)}`} className="line-clamp-2 text-sm font-medium hover:text-primary">
                {item.title}
              </Link>
              <span className="text-sm font-semibold">{formatINR(item.price)}</span>

              <div className="mt-auto flex items-center gap-3">
                <div className="flex items-center rounded-md border border-input">
                  <button
                    type="button"
                    className="flex h-8 w-8 items-center justify-center hover:bg-secondary"
                    onClick={() => setQuantity(item.productId, item.quantity - 1)}
                    aria-label="Decrease quantity"
                  >
                    <Minus className="h-3.5 w-3.5" />
                  </button>
                  <span className="w-8 text-center text-sm">{item.quantity}</span>
                  <button
                    type="button"
                    className="flex h-8 w-8 items-center justify-center hover:bg-secondary disabled:opacity-40"
                    onClick={() => setQuantity(item.productId, item.quantity + 1)}
                    disabled={item.quantity >= 10}
                    aria-label="Increase quantity"
                  >
                    <Plus className="h-3.5 w-3.5" />
                  </button>
                </div>
                <button
                  type="button"
                  className="text-xs text-muted-foreground hover:text-destructive"
                  onClick={() => removeItem(item.productId)}
                >
                  Remove
                </button>
              </div>
            </div>

            <span className="shrink-0 text-sm font-semibold">{formatINR(item.price * item.quantity)}</span>
          </div>
        ))}
      </div>

      <PincodeChecker />

      <div className="flex items-center justify-between rounded-lg border border-border p-4">
        <span className="text-sm text-muted-foreground">Subtotal</span>
        <span className="text-xl font-bold">{formatINR(subtotal)}</span>
      </div>

      <Link href="/checkout" className={cn(buttonVariants({ variant: "accent", size: "lg" }), "w-full")}>
        Proceed to Checkout
      </Link>
    </div>
  );
}
