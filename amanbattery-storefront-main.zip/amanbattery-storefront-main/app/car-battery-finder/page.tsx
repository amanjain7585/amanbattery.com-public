import type { Metadata } from "next";
import CarBatteryFinder from "@/components/finder/CarBatteryFinder";
import { SITE_URL, SITE_NAME } from "@/lib/seo";

const SLUG = "car-battery-finder";

export async function generateMetadata(): Promise<Metadata> {
  return {
    title: "Car Battery Finder — Find the Right Battery for Your Car",
    description: `Select your car's make, model and variant to find genuine, compatible batteries in stock at ${SITE_NAME}.`,
    alternates: { canonical: `${SITE_URL}/${SLUG}` },
  };
}

export default function CarBatteryFinderPage() {
  return (
    <div className="container max-w-3xl space-y-6 py-8">
      <div>
        <h1 className="text-2xl font-semibold">Car Battery Finder</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Tell us your vehicle and we&apos;ll show you batteries that fit it — genuine products, correct
          fitment, delivered.
        </p>
      </div>
      <CarBatteryFinder />
    </div>
  );
}
