import type { MetadataRoute } from "next";
import { getCategories } from "@/lib/api/categories";
import { getProducts } from "@/lib/api/products";
import { SITE_URL } from "@/lib/seo";

// Static routes always included; categories/products are fetched live so
// the sitemap never drifts from what's actually in the catalog. Both fetches
// fail soft (empty array) so a backend hiccup doesn't break the whole map.
export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const [categories, products] = await Promise.all([
    getCategories().catch(() => []),
    getProducts({ limit: 100 }).catch(() => null),
  ]);

  const staticRoutes: MetadataRoute.Sitemap = [
    { url: SITE_URL, changeFrequency: "daily", priority: 1 },
    { url: `${SITE_URL}/shop`, changeFrequency: "daily", priority: 0.8 },
  ];

  const categoryRoutes: MetadataRoute.Sitemap = categories.map((c) => ({
    url: `${SITE_URL}/category/${c.slug ?? c.id}`,
    changeFrequency: "weekly",
    priority: 0.6,
  }));

  const productRoutes: MetadataRoute.Sitemap = (products?.data ?? []).map((p) => ({
    // slug is a product SKU, not a guaranteed-clean URL segment (some
    // legacy/test SKUs contain spaces) — always encode it.
    url: `${SITE_URL}/product/${encodeURIComponent(p.slug)}`,
    changeFrequency: "weekly",
    priority: 0.5,
  }));

  return [...staticRoutes, ...categoryRoutes, ...productRoutes];
}
