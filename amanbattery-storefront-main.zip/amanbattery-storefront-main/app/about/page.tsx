import type { Metadata } from "next";
import LegalPageLayout from "@/components/legal/LegalPageLayout";
import { whatsappDisplayNumber, whatsappLink } from "@/lib/whatsapp";
import { SITE_URL, SITE_NAME } from "@/lib/seo";
import { getPageBySlug } from "@/lib/api/pages";
import { getWebsiteConfig } from "@/lib/api/website-config";

const SLUG = "about";

export async function generateMetadata(): Promise<Metadata> {
  const page = await getPageBySlug(SLUG);
  return {
    title: page?.seoTitle || "About Us",
    description: page?.seoDescription || `About ${SITE_NAME} — battery, inverter, and power products.`,
    alternates: { canonical: `${SITE_URL}/${SLUG}` },
  };
}

export default async function AboutPage() {
  const [page, config] = await Promise.all([getPageBySlug(SLUG), getWebsiteConfig().catch(() => null)]);
  const waNumber = config?.contact?.whatsapp;

  if (page) {
    return (
      <LegalPageLayout title={page.title}>
        <div dangerouslySetInnerHTML={{ __html: page.content }} />
      </LegalPageLayout>
    );
  }

  return (
    <LegalPageLayout title="About Us">
      <p>
        {SITE_NAME} sells genuine battery, inverter, and power products — car and bike batteries,
        home inverters, chargers, and accessories from trusted brands like Exide, Amaron, Luminous,
        and Okaya.
      </p>

      <h2>What We Do</h2>
      <p>
        We source directly through authorized channels and stock everything we list, so what you
        see is what we can actually deliver — no third-party drop-shipping delays.
      </p>

      <h2>Why Buy From Us</h2>
      <ul>
        <li>Genuine products sourced through authorized channels</li>
        <li>Fast, reliable delivery across serviceable pincodes</li>
        <li>Real support over WhatsApp — a person, not a bot</li>
      </ul>

      <h2>Get In Touch</h2>
      <p>
        Questions about a product or an order? Message us on WhatsApp:{" "}
        <a href={whatsappLink(`Hi, I have a question about ${SITE_NAME}.`, waNumber)} target="_blank" rel="noopener noreferrer">
          {whatsappDisplayNumber(waNumber)}
        </a>
        .
      </p>
    </LegalPageLayout>
  );
}
