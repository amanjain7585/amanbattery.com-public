import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { getProduct } from "@/lib/api/products";
import type { ApiError } from "@/lib/api/client";
import { SITE_URL } from "@/lib/seo";
import { getWebsiteConfig } from "@/lib/api/website-config";
import { formatAttributeValue } from "@/lib/format-attribute";
import { COLUMN_PRESET_CLASSES, visibilityClassName } from "@/lib/page-layout-types";
import { MODULE_RENDERERS, ModuleHeading, type ModuleRenderContext } from "@/components/product/page-modules";

async function loadProduct(id: string) {
  return getProduct(id).catch((err: ApiError) => {
    if (err?.status === 404) return null;
    throw err;
  });
}

export async function generateMetadata({ params }: { params: { id: string } }): Promise<Metadata> {
  const product = await loadProduct(params.id);
  if (!product) return {};

  const description =
    product.seoDescription ||
    product.shortDescription ||
    (product.brand
      ? `${product.title} by ${product.brand}. Genuine product, delivered pan-India.`
      : `${product.title}. Genuine product, delivered pan-India.`);
  const title = product.seoTitle || product.title;

  return {
    title,
    description,
    alternates: { canonical: product.canonicalUrl || `${SITE_URL}/product/${product.slug}` },
    openGraph: {
      title,
      description,
      images: product.images[0] ? [product.images[0]] : undefined,
    },
  };
}

export default async function ProductDetailPage({ params }: { params: { id: string } }) {
  const [product, config] = await Promise.all([loadProduct(params.id), getWebsiteConfig().catch(() => null)]);
  if (!product) notFound();

  // Named/unit-labeled attributes (from CategoryAttributeMapping), ordered
  // by displayOrder — this is the full Specifications table. Falls back to
  // the flat specifications map only if a product's category has no
  // attribute mappings configured yet, so nothing goes blank.
  const attrs = product.attributes.length > 0
    ? product.attributes.map((a) => ({ code: a.code, label: a.name, value: formatAttributeValue(a.value, a.unit) }))
    : Object.entries(product.specifications).map(([key, value]) => ({ code: key, label: key, value: formatAttributeValue(value) }));
  // Above-the-fold key-spec strip — a deliberate, admin-curated 3-5
  // buying-decision attributes (Capacity/Voltage/Battery Type/Warranty for
  // an inverter battery, etc. — see CategoryAttributeMapping.showOnPdpSummary),
  // never the raw grey-pill dump of every mapped attribute.
  const keySpecs = product.keySpecs.map((a) => ({ label: a.name, value: formatAttributeValue(a.value, a.unit) }));
  const modelCode = product.specifications?.model || product.sku;
  const inStock = product.availability === "available";
  const hasWarranty = product.attributes.some((a) => /warranty/i.test(a.code));
  const waNumber = config?.contact?.whatsapp;

  // GTIN is deliberately never emitted — no verified manufacturer barcode
  // data exists in this catalog, and inventing one violates Merchant Center
  // policy. sku/mpn (real, OMS-sourced identifiers) are used instead.
  // NOTE: these SEO/GMC-critical tags are always server-rendered here,
  // completely independent of the Page Builder — the builder controls
  // presentation only (see module-registry.ts's own header comment); no
  // module can ever remove or duplicate this JSON-LD.
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: product.title,
    image: product.images,
    description: product.shortDescription ?? product.seoDescription ?? undefined,
    sku: product.sku,
    mpn: product.specifications?.model || product.sku,
    brand: product.brand ? { "@type": "Brand", name: product.brand } : undefined,
    category: product.category ?? undefined,
    ...(product.price != null && {
      offers: {
        "@type": "Offer",
        priceCurrency: "INR",
        price: product.price,
        availability: inStock ? "https://schema.org/InStock" : "https://schema.org/OutOfStock",
        itemCondition: "https://schema.org/NewCondition",
        url: `${SITE_URL}/product/${product.slug}`,
      },
    }),
  };

  const breadcrumbJsonLd = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      { "@type": "ListItem", position: 1, name: "Home", item: SITE_URL },
      { "@type": "ListItem", position: 2, name: "Shop", item: `${SITE_URL}/shop` },
      ...(product.category && product.categorySlug
        ? [{ "@type": "ListItem", position: 3, name: product.category, item: `${SITE_URL}/category/${product.categorySlug}` }]
        : []),
      {
        "@type": "ListItem",
        position: product.categorySlug ? 4 : 3,
        name: product.title,
        item: `${SITE_URL}/product/${product.slug}`,
      },
    ],
  };

  const ctxBase: Omit<ModuleRenderContext, "module"> = { product, config, attrs, keySpecs, modelCode, inStock, hasWarranty, waNumber };

  return (
    <div className="container space-y-8 py-8">
      {/* eslint-disable-next-line react/no-danger -- static JSON-LD we built above, not user input */}
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      {/* eslint-disable-next-line react/no-danger -- static JSON-LD we built above, not user input */}
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd) }} />

      {/* pageLayout is always populated by a healthy backend (it falls
          back to a hardcoded default server-side even with zero
          templates published) — this is a last-resort safety net only,
          for a stale cached response or an older API version, never the
          expected path. */}
      {!product.pageLayout && (
        <div className="grid grid-cols-1 gap-8 lg:grid-cols-2">
          <div>{MODULE_RENDERERS.PRODUCT_GALLERY({ ...ctxBase, module: { id: "fallback-gallery", type: "PRODUCT_GALLERY", enabled: true, heading: "", showHeading: false, visibility: { desktop: true, tablet: true, mobile: true }, hideWhenEmpty: true, config: {} } })}</div>
          <div className="space-y-4">
            {(["PRODUCT_BRAND", "PRODUCT_TITLE", "MODEL_SKU", "PRICE", "AVAILABILITY", "PURCHASE_ACTIONS"] as const).map((type) => (
              <div key={type}>
                {MODULE_RENDERERS[type]({ ...ctxBase, module: { id: `fallback-${type}`, type, enabled: true, heading: "", showHeading: false, visibility: { desktop: true, tablet: true, mobile: true }, hideWhenEmpty: true, config: {} } })}
              </div>
            ))}
          </div>
        </div>
      )}

      {product.pageLayout?.sections.map((section) => (
        <div key={section.id} className="grid grid-cols-12 gap-8">
          {section.columns.map((column, colIdx) => (
            <div key={column.id} className={COLUMN_PRESET_CLASSES[section.columnPreset][colIdx]}>
              <div className="space-y-4">
                {column.modules
                  .filter((m) => m.enabled)
                  .map((mod) => {
                    const renderer = MODULE_RENDERERS[mod.type];
                    if (!renderer) return null; // unknown/unimplemented module type — safe no-op, never crashes the page
                    const content = renderer({ ...ctxBase, module: mod });
                    if (content == null && mod.hideWhenEmpty) return null;
                    return (
                      <div key={mod.id} className={visibilityClassName(mod.visibility)}>
                        <ModuleHeading ctx={{ ...ctxBase, module: mod }} fallback={mod.heading} />
                        {content}
                      </div>
                    );
                  })}
              </div>
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}
