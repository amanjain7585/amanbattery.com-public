"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Input } from "@/components/ui/input";
import { Button, buttonVariants } from "@/components/ui/button";
import { useCart } from "@/lib/cart/CartContext";
import { useAuth } from "@/lib/auth/AuthContext";
import { placeOrder } from "@/lib/api/checkout";
import { getPaymentMethods, createPrepaidOrder, confirmPayment } from "@/lib/api/payments";
import { checkServiceability } from "@/lib/api/serviceability";
import { openRazorpayCheckout } from "@/lib/razorpay";
import { formatINR, cn } from "@/lib/utils";
import { SITE_NAME } from "@/lib/seo";
import type { ApiError } from "@/lib/api/client";
import type { CashfreeNormalizedProfile } from "@/lib/api/types";
import { applyCashfreeProfile, shouldConfirmOverwrite } from "@/lib/cashfree-profile-mapper";
import SmartAutofillCard from "@/components/checkout/SmartAutofillCard";

interface FormState {
  recipientName: string;
  recipientPhone: string;
  shippingAddress: string;
  city: string;
  state: string;
  pincode: string;
}

const EMPTY_FORM: FormState = {
  recipientName: "",
  recipientPhone: "",
  shippingAddress: "",
  city: "",
  state: "",
  pincode: "",
};

type ServiceabilityNote = { kind: "idle" } | { kind: "checking" } | { kind: "ok"; message: string } | { kind: "warn"; message: string };
type PaymentChoice = "COD" | "PREPAID";

export default function CheckoutPage() {
  const { items, subtotal, clear } = useCart();
  const router = useRouter();
  const { token, customer, hydrated, isLoggedIn } = useAuth();
  const [form, setForm] = useState<FormState>(EMPTY_FORM);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [serviceability, setServiceability] = useState<ServiceabilityNote>({ kind: "idle" });
  const [prepaidAvailable, setPrepaidAvailable] = useState(false);
  const [paymentChoice, setPaymentChoice] = useState<PaymentChoice>("COD");
  const [pendingProfile, setPendingProfile] = useState<CashfreeNormalizedProfile | null>(null);

  // Checkout requires a logged-in Customer.
  useEffect(() => {
    if (hydrated && !isLoggedIn) router.replace("/account/login?redirect=/checkout");
  }, [hydrated, isLoggedIn, router]);

  // Prefill name/phone from the account once known.
  useEffect(() => {
    if (customer) {
      setForm((f) => ({
        ...f,
        recipientName: f.recipientName || customer.name,
        recipientPhone: f.recipientPhone || customer.phone || "",
      }));
    }
  }, [customer]);

  useEffect(() => {
    getPaymentMethods()
      .then((res) => setPrepaidAvailable(res.prepaidAvailable))
      .catch(() => setPrepaidAvailable(false)); // soft failure — COD stays available regardless
  }, []);

  function update<K extends keyof FormState>(key: K, value: FormState[K]) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  function applyProfile(profile: CashfreeNormalizedProfile) {
    if (shouldConfirmOverwrite(form)) {
      setPendingProfile(profile);
      return;
    }
    setForm((current) => applyCashfreeProfile(profile, current));
  }

  function confirmReplace() {
    if (!pendingProfile) return;
    setForm((current) => applyCashfreeProfile(pendingProfile, current));
    setPendingProfile(null);
  }

  async function handlePincodeBlur() {
    if (!/^\d{6}$/.test(form.pincode)) return;
    setServiceability({ kind: "checking" });
    try {
      const result = await checkServiceability(form.pincode);
      setServiceability(
        result.deliverable
          ? {
              kind: "ok",
              message: result.selfDelivery
                ? `Delivery available to ${result.pincode} (local delivery in ${result.selfDelivery.city}).`
                : `Delivery available to ${result.pincode}${result.courier?.cod ? " (COD available)" : ""}.`,
            }
          : { kind: "warn", message: `We may not currently deliver to ${result.pincode} — we'll confirm by phone.` },
      );
    } catch {
      // Soft failure — doesn't block checkout, staff confirm by phone regardless.
      setServiceability({ kind: "idle" });
    }
  }

  async function handleCodSubmit() {
    if (!token) throw new Error("You need to be logged in to place an order.");
    const result = await placeOrder(
      { ...form, items: items.map((i) => ({ productId: i.productId, quantity: i.quantity })) },
      token,
    );
    clear();
    router.push(`/order-confirmation?order=${encodeURIComponent(result.orderNumber)}&phone=${encodeURIComponent(form.recipientPhone)}`);
  }

  async function handlePrepaidSubmit() {
    if (!token) throw new Error("You need to be logged in to place an order.");
    const orderPayload = {
      ...form,
      items: items.map((i) => ({ productId: i.productId, quantity: i.quantity })),
    };
    const prepaidOrder = await createPrepaidOrder(orderPayload, token);

    let paymentResult;
    try {
      paymentResult = await openRazorpayCheckout({
        keyId: prepaidOrder.keyId,
        razorpayOrderId: prepaidOrder.razorpayOrderId,
        amount: prepaidOrder.amount,
        name: SITE_NAME,
        description: `Order ${prepaidOrder.orderNumber}`,
        prefillName: form.recipientName,
        prefillContact: form.recipientPhone,
      });
    } catch {
      // Widget dismissed without paying — the Order already exists as
      // PENDING, nothing to re-create. Let the customer retry.
      throw new Error("Payment was cancelled — your order is saved, you can try paying again.");
    }

    await confirmPayment({
      orderNumber: prepaidOrder.orderNumber,
      razorpayOrderId: paymentResult.razorpay_order_id,
      razorpayPaymentId: paymentResult.razorpay_payment_id,
      razorpaySignature: paymentResult.razorpay_signature,
    });

    clear();
    router.push(`/order-confirmation?order=${encodeURIComponent(prepaidOrder.orderNumber)}&phone=${encodeURIComponent(form.recipientPhone)}&paid=1`);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (items.length === 0) return;
    setSubmitting(true);
    setError(null);
    try {
      if (paymentChoice === "PREPAID") {
        await handlePrepaidSubmit();
      } else {
        await handleCodSubmit();
      }
    } catch (err) {
      const apiErr = err as ApiError;
      setError(apiErr?.message || "Couldn't place your order — please try again.");
      setSubmitting(false);
    }
  }

  if (!hydrated || !isLoggedIn) return null; // redirect effect above handles navigation

  if (items.length === 0) {
    return (
      <div className="container flex min-h-[50vh] flex-col items-center justify-center gap-4 py-16 text-center">
        <h1 className="text-2xl font-semibold">Your cart is empty</h1>
        <Link href="/shop" className={buttonVariants()}>
          Continue Shopping
        </Link>
      </div>
    );
  }

  return (
    <div className="container max-w-2xl space-y-6 py-8">
      <h1 className="text-2xl font-semibold">Checkout</h1>

      <section className="rounded-lg border border-border p-4">
        <h2 className="mb-3 text-sm font-semibold">Order Summary</h2>
        <div className="space-y-2 text-sm">
          {items.map((item) => (
            <div key={item.productId} className="flex justify-between gap-3">
              <span className="line-clamp-1 text-muted-foreground">
                {item.title} × {item.quantity}
              </span>
              <span className="shrink-0 font-medium">{formatINR(item.price * item.quantity)}</span>
            </div>
          ))}
        </div>
        <div className="mt-3 flex justify-between border-t border-border pt-3 text-base font-semibold">
          <span>Total</span>
          <span>{formatINR(subtotal)}</span>
        </div>
      </section>

      {prepaidAvailable && (
        <section>
          <h2 className="mb-2 text-sm font-semibold">Payment Method</h2>
          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => setPaymentChoice("COD")}
              className={cn(
                "rounded-lg border p-3 text-left text-sm transition-colors",
                paymentChoice === "COD" ? "border-primary bg-primary/5" : "hover:bg-muted",
              )}
            >
              <div className="font-medium">Cash on Delivery</div>
              <div className="text-xs text-muted-foreground">Pay when it arrives</div>
            </button>
            <button
              type="button"
              onClick={() => setPaymentChoice("PREPAID")}
              className={cn(
                "rounded-lg border p-3 text-left text-sm transition-colors",
                paymentChoice === "PREPAID" ? "border-primary bg-primary/5" : "hover:bg-muted",
              )}
            >
              <div className="font-medium">Pay Online</div>
              <div className="text-xs text-muted-foreground">Card, UPI, wallet — via Razorpay</div>
            </button>
          </div>
        </section>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        {token && <SmartAutofillCard phone={form.recipientPhone} token={token} onProfileFetched={applyProfile} />}

        {pendingProfile && (
          <div className="rounded-lg border border-primary/30 bg-primary/5 p-3 text-sm">
            <p className="font-medium">Use the information from Smart Autofill?</p>
            <p className="mt-1 text-xs text-muted-foreground">
              You&apos;ve already entered some details. Replacing will overwrite them with what Cashfree returned —
              you can still edit any field afterwards.
            </p>
            <div className="mt-2 flex gap-2">
              <Button type="button" size="sm" variant="outline" onClick={() => setPendingProfile(null)}>
                Keep my details
              </Button>
              <Button type="button" size="sm" onClick={confirmReplace}>
                Replace entered details
              </Button>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div className="space-y-1.5">
            <label htmlFor="recipientName" className="text-sm font-medium">Full Name</label>
            <Input id="recipientName" required value={form.recipientName} onChange={(e) => update("recipientName", e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <label htmlFor="recipientPhone" className="text-sm font-medium">Phone Number</label>
            <Input
              id="recipientPhone"
              type="tel"
              required
              placeholder="10-digit mobile number"
              value={form.recipientPhone}
              onChange={(e) => update("recipientPhone", e.target.value.replace(/[^\d+]/g, ""))}
            />
          </div>
        </div>

        <div className="space-y-1.5">
          <label htmlFor="shippingAddress" className="text-sm font-medium">Delivery Address</label>
          <Input id="shippingAddress" required value={form.shippingAddress} onChange={(e) => update("shippingAddress", e.target.value)} />
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          <div className="space-y-1.5">
            <label htmlFor="city" className="text-sm font-medium">City</label>
            <Input id="city" required value={form.city} onChange={(e) => update("city", e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <label htmlFor="state" className="text-sm font-medium">State</label>
            <Input id="state" required value={form.state} onChange={(e) => update("state", e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <label htmlFor="pincode" className="text-sm font-medium">Pincode</label>
            <Input
              id="pincode"
              required
              inputMode="numeric"
              maxLength={6}
              value={form.pincode}
              onChange={(e) => update("pincode", e.target.value.replace(/\D/g, ""))}
              onBlur={handlePincodeBlur}
            />
          </div>
        </div>

        {serviceability.kind === "checking" && <p className="text-xs text-muted-foreground">Checking delivery availability...</p>}
        {(serviceability.kind === "ok" || serviceability.kind === "warn") && (
          <p className={cn("text-xs", serviceability.kind === "ok" ? "text-muted-foreground" : "text-destructive")}>
            {serviceability.message}
          </p>
        )}

        {error && <p className="text-sm text-destructive">{error}</p>}

        <Button type="submit" variant="accent" size="lg" className="w-full" disabled={submitting}>
          {submitting
            ? paymentChoice === "PREPAID" ? "Opening payment..." : "Placing Order..."
            : paymentChoice === "PREPAID"
              ? `Pay ${formatINR(subtotal)} Online`
              : `Place Order — ${formatINR(subtotal)} (Cash on Delivery)`}
        </Button>
        <p className="text-xs text-muted-foreground">
          {paymentChoice === "PREPAID"
            ? "You'll be redirected to Razorpay's secure checkout to complete payment."
            : "We'll call you to confirm your order before shipping. Pay in cash when it arrives."}
        </p>
        <p className="text-xs text-muted-foreground">
          By placing this order, you agree to our{" "}
          <Link href="/terms" className="underline hover:text-primary">Terms &amp; Conditions</Link>,{" "}
          <Link href="/shipping-policy" className="underline hover:text-primary">Shipping Policy</Link>, and{" "}
          <Link href="/returns-refunds" className="underline hover:text-primary">Returns &amp; Refunds Policy</Link>.
        </p>
      </form>
    </div>
  );
}
