"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";

// Submits to /shop?search=... — real functionality (the listing page reads
// the query param and passes it straight through to the products API's
// search filter), not a decorative input. No autocomplete/suggestions yet
// (per the design spec that's grouped Products/Categories/Brands/Vehicle
// suggestions) — that's a later phase once there's enough traffic/data to
// make suggestions useful.
export default function SearchBar({ className }: { className?: string }) {
  const router = useRouter();
  const [value, setValue] = useState("");

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const trimmed = value.trim();
    router.push(trimmed ? `/shop?search=${encodeURIComponent(trimmed)}` : "/shop");
  }

  return (
    <form onSubmit={handleSubmit} className={`relative ${className ?? ""}`}>
      <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
      <Input
        type="search"
        value={value}
        onChange={(e) => setValue(e.target.value)}
        placeholder="Search batteries, inverters, chargers..."
        className="pl-9"
        aria-label="Search products"
      />
    </form>
  );
}
