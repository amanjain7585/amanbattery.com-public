"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { cn } from "@/lib/utils";
import { buttonVariants } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import ProductCard from "@/components/product/ProductCard";
import {
  getVehicleMakes,
  getVehicleModels,
  getVehicleVariants,
  getProductsForVariant,
} from "@/lib/api/vehicles";
import type { VehicleMake, VehicleModel, VehicleVariant, VehicleFinderProduct } from "@/lib/api/types";

const selectClass =
  "flex h-11 w-full rounded-md border border-input bg-background px-3 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50";

function variantLabel(v: VehicleVariant): string {
  const year = v.yearFrom && v.yearTo ? ` (${v.yearFrom}–${v.yearTo})` : v.yearFrom ? ` (${v.yearFrom}+)` : "";
  return `${v.name}${year}`;
}

// Client-side cascading Make -> Model -> Variant selector — each level
// fetches its children only once the parent is picked, so a customer with
// zero JS-caused-lag sees only the vehicles that are actually possible
// (never a stale/irrelevant model list for a different make).
export default function CarBatteryFinder() {
  const [makes, setMakes] = useState<VehicleMake[] | null>(null);
  const [models, setModels] = useState<VehicleModel[]>([]);
  const [variants, setVariants] = useState<VehicleVariant[]>([]);

  const [makeId, setMakeId] = useState("");
  const [modelId, setModelId] = useState("");
  const [variantId, setVariantId] = useState("");

  const [loadingModels, setLoadingModels] = useState(false);
  const [loadingVariants, setLoadingVariants] = useState(false);
  const [searching, setSearching] = useState(false);
  const [searched, setSearched] = useState(false);
  const [products, setProducts] = useState<VehicleFinderProduct[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    getVehicleMakes()
      .then(setMakes)
      .catch(() => setMakes([]));
  }, []);

  function handleMakeChange(id: string) {
    setMakeId(id);
    setModelId("");
    setVariantId("");
    setModels([]);
    setVariants([]);
    setSearched(false);
    if (!id) return;
    setLoadingModels(true);
    getVehicleModels(id)
      .then(setModels)
      .catch(() => setModels([]))
      .finally(() => setLoadingModels(false));
  }

  function handleModelChange(id: string) {
    setModelId(id);
    setVariantId("");
    setVariants([]);
    setSearched(false);
    if (!id) return;
    setLoadingVariants(true);
    getVehicleVariants(id)
      .then(setVariants)
      .catch(() => setVariants([]))
      .finally(() => setLoadingVariants(false));
  }

  async function handleFind() {
    if (!variantId) return;
    setSearching(true);
    setError(null);
    try {
      const result = await getProductsForVariant(variantId);
      setProducts(result.products);
      setSearched(true);
    } catch {
      setError("Couldn't look up compatible batteries right now — please try again.");
    } finally {
      setSearching(false);
    }
  }

  return (
    <div className="rounded-lg border border-border bg-card p-5">
      <h3 className="text-base font-semibold">Find My Car Battery</h3>
      <p className="mt-1 text-sm text-muted-foreground">
        Select your vehicle to see batteries that fit it.
      </p>

      <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-3">
        <select
          className={selectClass}
          value={makeId}
          onChange={(e) => handleMakeChange(e.target.value)}
          disabled={makes === null}
          aria-label="Vehicle Make"
        >
          <option value="">{makes === null ? "Loading makes…" : "Select Make"}</option>
          {makes?.map((m) => (
            <option key={m.id} value={m.id}>{m.name}</option>
          ))}
        </select>

        <select
          className={selectClass}
          value={modelId}
          onChange={(e) => handleModelChange(e.target.value)}
          disabled={!makeId || loadingModels}
          aria-label="Vehicle Model"
        >
          <option value="">
            {!makeId ? "Select Make first" : loadingModels ? "Loading models…" : "Select Model"}
          </option>
          {models.map((m) => (
            <option key={m.id} value={m.id}>{m.name}</option>
          ))}
        </select>

        <select
          className={selectClass}
          value={variantId}
          onChange={(e) => { setVariantId(e.target.value); setSearched(false); }}
          disabled={!modelId || loadingVariants}
          aria-label="Vehicle Variant / Year"
        >
          <option value="">
            {!modelId ? "Select Model first" : loadingVariants ? "Loading variants…" : "Select Variant / Year"}
          </option>
          {variants.map((v) => (
            <option key={v.id} value={v.id}>{variantLabel(v)}</option>
          ))}
        </select>
      </div>

      <button
        type="button"
        onClick={handleFind}
        disabled={!variantId || searching}
        className={cn(buttonVariants({ variant: "default" }), "mt-4 w-full sm:w-auto")}
      >
        {searching ? "Searching…" : "Find My Battery"}
      </button>

      {error && <p className="mt-3 text-sm text-destructive">{error}</p>}

      {searched && !error && (
        <div className="mt-6 border-t border-border pt-5">
          {products.length > 0 ? (
            <>
              <p className="mb-3 text-sm font-medium">
                {products.length} compatible {products.length === 1 ? "battery" : "batteries"} found
              </p>
              <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
                {products.map((p) => (
                  <div key={p.id} className="flex flex-col gap-1">
                    <ProductCard product={p} />
                    {p.compatibilityConfidence === "ESTIMATED" && (
                      <div className="px-1">
                        <Badge variant="outline" className="text-xs">Estimated fit</Badge>
                        {p.compatibilityNotes && (
                          <p className="mt-1 text-xs text-muted-foreground">{p.compatibilityNotes}</p>
                        )}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </>
          ) : (
            <div className="rounded-lg border border-dashed border-border py-8 text-center text-sm text-muted-foreground">
              No compatible battery found for this vehicle yet.{" "}
              <Link href="/shop?category=car-batteries" className="text-primary underline-offset-4 hover:underline">
                Browse all car batteries
              </Link>{" "}
              or ask us on WhatsApp.
            </div>
          )}
        </div>
      )}
    </div>
  );
}
