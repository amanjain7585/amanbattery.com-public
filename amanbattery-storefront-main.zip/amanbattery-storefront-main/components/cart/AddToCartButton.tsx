"use client";

import { useState } from "react";
import { Button, type ButtonProps } from "@/components/ui/button";
import { useCart } from "@/lib/cart/CartContext";
import { cn } from "@/lib/utils";

interface AddToCartButtonProps extends Omit<ButtonProps, "onClick"> {
  productId: string;
  slug: string;
  title: string;
  image: string | null;
  price: number;
  quantity?: number;
  onAdded?: () => void;
}

export default function AddToCartButton({
  productId,
  slug,
  title,
  image,
  price,
  quantity = 1,
  onAdded,
  className,
  children,
  ...buttonProps
}: AddToCartButtonProps) {
  const { addItem } = useCart();
  const [added, setAdded] = useState(false);

  function handleClick(e: React.MouseEvent) {
    e.preventDefault();
    e.stopPropagation();
    addItem({ productId, slug, title, image, price }, quantity);
    setAdded(true);
    onAdded?.();
    setTimeout(() => setAdded(false), 1500);
  }

  return (
    <Button type="button" onClick={handleClick} className={cn(className)} {...buttonProps}>
      {added ? "Added ✓" : children ?? "Add to Cart"}
    </Button>
  );
}
