"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { useCart } from "@/lib/cart/CartContext";

interface ProductCtaButtonsProps {
  productId: string;
  slug: string;
  title: string;
  image: string | null;
  price: number;
}

// Add to Cart / Buy Now for a priced, in-stock product. Buy Now = add +
// redirect straight to /cart (no separate "mini cart" flow — the cart page
// is the very next step either way).
export default function ProductCtaButtons({ productId, slug, title, image, price }: ProductCtaButtonsProps) {
  const { addItem } = useCart();
  const router = useRouter();
  const [added, setAdded] = useState(false);

  function handleAddToCart() {
    addItem({ productId, slug, title, image, price });
    setAdded(true);
    setTimeout(() => setAdded(false), 1500);
  }

  function handleBuyNow() {
    addItem({ productId, slug, title, image, price });
    router.push("/cart");
  }

  return (
    <div className="flex gap-3 pt-2">
      <Button type="button" variant="outline" size="lg" className="flex-1" onClick={handleAddToCart}>
        {added ? "Added ✓" : "Add to Cart"}
      </Button>
      <Button type="button" variant="accent" size="lg" className="flex-1" onClick={handleBuyNow}>
        Buy Now
      </Button>
    </div>
  );
}
