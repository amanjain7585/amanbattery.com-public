"use client";

import { useEffect, useMemo, useState } from "react";
import { Input } from "@/components/ui/input";
import ProductCard from "@/components/product/ProductCard";
import { getCategories } from "@/lib/api/categories";
import { getProducts } from "@/lib/api/products";
import { recommendBatteryConfig, estimateBackupHours } from "@/lib/calculators";
import type { PublicProduct } from "@/lib/api/types";

const selectClass =
  "flex h-10 w-full rounded-md border border-input bg-background px-3 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring sm:w-40";

function batteryCapacityAh(product: PublicProduct): number | null {
  const raw = product.specifications?.["battery_capacity"];
  const n = raw != null ? Number(raw) : NaN;
  return Number.isFinite(n) && n > 0 ? n : null;
}

// Given the load + desired backup time (Part 8's Backup Calculator), works
// out the required battery capacity and shows real in-stock batteries that
// meet it — plus, for each, the actual estimated backup that battery's real
// capacity gives (not just the rounded requirement).
export default function BackupCalculator() {
  const [loadWatts, setLoadWatts] = useState("200");
  const [backupHours, setBackupHours] = useState("4");
  const [systemVoltage, setSystemVoltage] = useState<12 | 24 | 48>(12);
  const [batteryProducts, setBatteryProducts] = useState<PublicProduct[] | null>(null);

  useEffect(() => {
    (async () => {
      const categories = await getCategories().catch(() => []);
      const batteryCategory = categories.find((c) => c.slug === "inverter-battery");
      const batteries = batteryCategory
        ? await getProducts({ categoryId: batteryCategory.id, limit: 100 }).then((r) => r.data).catch(() => [])
        : [];
      setBatteryProducts(batteries);
    })();
  }, []);

  const load = Number(loadWatts) || 0;
  const hours = Number(backupHours) || 0;
  const rec = recommendBatteryConfig(load, hours, systemVoltage);

  const matches = useMemo(() => {
    if (!batteryProducts || rec.requiredAh <= 0) return [];
    return batteryProducts
      .map((p) => ({ product: p, ah: batteryCapacityAh(p) }))
      .filter((x): x is { product: PublicProduct; ah: number } => x.ah != null && x.ah >= rec.requiredAh)
      .sort((a, b) => a.ah - b.ah)
      .slice(0, 4);
  }, [batteryProducts, rec.requiredAh]);

  return (
    <div className="rounded-lg border border-border bg-card p-5">
      <h3 className="text-base font-semibold">Backup Time Calculator</h3>
      <p className="mt-1 text-sm text-muted-foreground">
        Tell us your load and how long you need backup for — we&apos;ll work out the battery capacity you need.
      </p>

      <div className="mt-4 flex flex-wrap items-end gap-4">
        <div>
          <label className="text-xs text-muted-foreground">Load (Watts)</label>
          <Input type="number" min={0} value={loadWatts} onChange={(e) => setLoadWatts(e.target.value)} className="h-9 w-28" />
        </div>
        <div>
          <label className="text-xs text-muted-foreground">Required backup (hours)</label>
          <Input type="number" min={0.5} step={0.5} value={backupHours} onChange={(e) => setBackupHours(e.target.value)} className="h-9 w-28" />
        </div>
        <div>
          <label className="text-xs text-muted-foreground">Battery voltage</label>
          <select className={selectClass} value={systemVoltage} onChange={(e) => setSystemVoltage(Number(e.target.value) as 12 | 24 | 48)}>
            <option value={12}>12V</option>
            <option value={24}>24V</option>
            <option value={48}>48V</option>
          </select>
        </div>
      </div>

      {load > 0 && hours > 0 && (
        <div className="mt-6 space-y-4 border-t border-border pt-5">
          <div className="rounded-md bg-secondary/60 p-3">
            <p className="text-xs text-muted-foreground">You need at least</p>
            <p className="text-lg font-semibold">
              {rec.batteryCount} × {rec.ahPerBattery} Ah battery ({systemVoltage}V system)
            </p>
          </div>
          <p className="text-xs text-muted-foreground">
            Assumes 80% battery/inverter round-trip efficiency — actual backup varies with battery age, load
            variation, and depth of discharge.
          </p>

          <div>
            <p className="mb-2 text-sm font-medium">Compatible batteries</p>
            {batteryProducts === null ? (
              <p className="text-sm text-muted-foreground">Loading…</p>
            ) : matches.length > 0 ? (
              <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
                {matches.map(({ product, ah }) => {
                  const est = estimateBackupHours(load, ah, systemVoltage, rec.batteryCount);
                  return (
                    <div key={product.id} className="flex flex-col gap-1">
                      <ProductCard product={product} />
                      <p className="px-1 text-xs text-muted-foreground">~{est.estimatedHours}h backup at this load</p>
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">No battery in stock matches this capacity yet — ask us on WhatsApp.</p>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
