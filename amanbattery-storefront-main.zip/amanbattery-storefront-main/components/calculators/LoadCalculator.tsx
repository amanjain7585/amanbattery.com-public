"use client";

import { useEffect, useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import ProductCard from "@/components/product/ProductCard";
import { getCategories } from "@/lib/api/categories";
import { getProducts } from "@/lib/api/products";
import {
  COMMON_APPLIANCES,
  calculateTotalLoad,
  recommendInverterVA,
  recommendBatteryConfig,
  type LoadItem,
} from "@/lib/calculators";
import type { PublicProduct } from "@/lib/api/types";

const selectClass =
  "flex h-10 w-full rounded-md border border-input bg-background px-3 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring sm:w-40";

// Reads the numeric battery capacity (Ah) off a product's flat
// specifications map — CategoryAttributeMapping code "battery_capacity" per
// the Inverter Battery category (confirmed against live category data, not
// assumed). Falls back to null (excluded from recommendations) rather than
// guessing, if a product hasn't had that attribute filled in yet.
function batteryCapacityAh(product: PublicProduct): number | null {
  const raw = product.specifications?.["battery_capacity"];
  const n = raw != null ? Number(raw) : NaN;
  return Number.isFinite(n) && n > 0 ? n : null;
}

export default function LoadCalculator() {
  const [selected, setSelected] = useState<Record<string, number>>({});
  const [customItems, setCustomItems] = useState<LoadItem[]>([]);
  const [customName, setCustomName] = useState("");
  const [customWatts, setCustomWatts] = useState("");
  const [backupHours, setBackupHours] = useState("4");
  const [systemVoltage, setSystemVoltage] = useState<12 | 24 | 48>(12);

  const [batteryProducts, setBatteryProducts] = useState<PublicProduct[] | null>(null);
  const [inverterProducts, setInverterProducts] = useState<PublicProduct[] | null>(null);

  useEffect(() => {
    (async () => {
      const categories = await getCategories().catch(() => []);
      const batteryCategory = categories.find((c) => c.slug === "inverter-battery");
      const inverterCategory = categories.find((c) => c.slug === "inverter");
      const [batteries, inverters] = await Promise.all([
        batteryCategory
          ? getProducts({ categoryId: batteryCategory.id, limit: 100 }).then((r) => r.data).catch(() => [])
          : Promise.resolve([]),
        inverterCategory
          ? getProducts({ categoryId: inverterCategory.id, limit: 100 }).then((r) => r.data).catch(() => [])
          : Promise.resolve([]),
      ]);
      setBatteryProducts(batteries);
      setInverterProducts(inverters);
    })();
  }, []);

  const items: LoadItem[] = useMemo(() => {
    const fromAppliances = COMMON_APPLIANCES
      .filter((a) => (selected[a.name] ?? 0) > 0)
      .map((a) => ({ name: a.name, watts: a.watts, quantity: selected[a.name] }));
    return [...fromAppliances, ...customItems];
  }, [selected, customItems]);

  const totalLoad = calculateTotalLoad(items);
  const hours = Number(backupHours) || 0;
  const inverterRec = recommendInverterVA(totalLoad);
  const batteryRec = recommendBatteryConfig(totalLoad, hours, systemVoltage);

  const recommendedBatteries = useMemo(() => {
    if (!batteryProducts || batteryRec.requiredAh <= 0) return [];
    return batteryProducts
      .map((p) => ({ product: p, ah: batteryCapacityAh(p) }))
      .filter((x): x is { product: PublicProduct; ah: number } => x.ah != null && x.ah >= batteryRec.requiredAh)
      .sort((a, b) => a.ah - b.ah)
      .slice(0, 4)
      .map((x) => x.product);
  }, [batteryProducts, batteryRec.requiredAh]);

  function addCustomItem() {
    const watts = Number(customWatts);
    if (!customName.trim() || !Number.isFinite(watts) || watts <= 0) return;
    setCustomItems((prev) => [...prev, { name: customName.trim(), watts, quantity: 1 }]);
    setCustomName("");
    setCustomWatts("");
  }

  return (
    <div className="rounded-lg border border-border bg-card p-5">
      <h3 className="text-base font-semibold">Inverter Load Calculator</h3>
      <p className="mt-1 text-sm text-muted-foreground">
        Pick the appliances you want to run — we&apos;ll estimate the inverter size and battery capacity you need.
      </p>

      <div className="mt-4 grid grid-cols-1 gap-2 sm:grid-cols-2">
        {COMMON_APPLIANCES.map((a) => (
          <label key={a.name} className="flex items-center justify-between gap-2 rounded-md border border-border px-3 py-2 text-sm">
            <span>{a.name} <span className="text-xs text-muted-foreground">({a.watts}W)</span></span>
            <Input
              type="number"
              min={0}
              className="h-8 w-16 text-center"
              value={selected[a.name] ?? ""}
              placeholder="0"
              onChange={(e) => {
                const qty = Math.max(0, parseInt(e.target.value, 10) || 0);
                setSelected((prev) => ({ ...prev, [a.name]: qty }));
              }}
            />
          </label>
        ))}
      </div>

      <div className="mt-4 space-y-2">
        <p className="text-sm font-medium">Add a custom appliance</p>
        <div className="flex flex-wrap gap-2">
          <Input placeholder="Appliance name" value={customName} onChange={(e) => setCustomName(e.target.value)} className="max-w-[10rem]" />
          <Input placeholder="Watts" type="number" min={0} value={customWatts} onChange={(e) => setCustomWatts(e.target.value)} className="max-w-[6rem]" />
          <Button type="button" variant="outline" onClick={addCustomItem}>Add</Button>
        </div>
        {customItems.length > 0 && (
          <ul className="flex flex-wrap gap-2 text-xs text-muted-foreground">
            {customItems.map((item, i) => (
              <li key={i} className="rounded-full bg-secondary px-3 py-1">
                {item.name} ({item.watts}W)
                <button className="ml-2 text-destructive" onClick={() => setCustomItems((prev) => prev.filter((_, idx) => idx !== i))}>×</button>
              </li>
            ))}
          </ul>
        )}
      </div>

      <div className="mt-4 flex flex-wrap items-end gap-4">
        <div>
          <label className="text-xs text-muted-foreground">Desired backup time (hours)</label>
          <Input type="number" min={0.5} step={0.5} value={backupHours} onChange={(e) => setBackupHours(e.target.value)} className="h-9 w-28" />
        </div>
        <div>
          <label className="text-xs text-muted-foreground">System voltage</label>
          <select className={selectClass} value={systemVoltage} onChange={(e) => setSystemVoltage(Number(e.target.value) as 12 | 24 | 48)}>
            <option value={12}>12V</option>
            <option value={24}>24V</option>
            <option value={48}>48V</option>
          </select>
        </div>
      </div>

      {totalLoad > 0 && (
        <div className="mt-6 space-y-4 border-t border-border pt-5">
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            <div className="rounded-md bg-secondary/60 p-3">
              <p className="text-xs text-muted-foreground">Total Load</p>
              <p className="text-lg font-semibold">{totalLoad} W</p>
            </div>
            <div className="rounded-md bg-secondary/60 p-3">
              <p className="text-xs text-muted-foreground">Recommended Inverter</p>
              <p className="text-lg font-semibold">{inverterRec.recommendedVA} VA</p>
            </div>
            <div className="rounded-md bg-secondary/60 p-3">
              <p className="text-xs text-muted-foreground">Battery Bank</p>
              <p className="text-lg font-semibold">
                {batteryRec.batteryCount} × {batteryRec.ahPerBattery} Ah ({systemVoltage}V)
              </p>
            </div>
          </div>
          <p className="text-xs text-muted-foreground">
            Estimates assume a 0.8 power factor, 25% inverter safety margin, and 80% battery/inverter round-trip
            efficiency — actual requirements vary by appliance and usage pattern.
          </p>

          {inverterProducts && (
            <div>
              <p className="mb-2 text-sm font-medium">Inverters ({inverterRec.recommendedVA}+ VA)</p>
              {inverterProducts.length > 0 ? (
                <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
                  {inverterProducts.slice(0, 4).map((p) => <ProductCard key={p.id} product={p} />)}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">No inverters in stock right now — ask us on WhatsApp for availability.</p>
              )}
            </div>
          )}

          <div>
            <p className="mb-2 text-sm font-medium">Batteries ({batteryRec.ahPerBattery}+ Ah)</p>
            {batteryProducts === null ? (
              <p className="text-sm text-muted-foreground">Loading…</p>
            ) : recommendedBatteries.length > 0 ? (
              <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
                {recommendedBatteries.map((p) => <ProductCard key={p.id} product={p} />)}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">No battery in stock matches this capacity yet — ask us on WhatsApp.</p>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
