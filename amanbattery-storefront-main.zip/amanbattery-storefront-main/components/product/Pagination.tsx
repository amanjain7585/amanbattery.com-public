import Link from "next/link";
import { cn } from "@/lib/utils";

// Plain Link-based (no client JS) — preserves every existing query param
// except page, matching how FilterBar/SearchBar build their URLs.
export default function Pagination({
  basePath,
  searchParams,
  page,
  pages,
}: {
  basePath: string;
  searchParams: Record<string, string | undefined>;
  page: number;
  pages: number;
}) {
  if (pages <= 1) return null;

  function hrefFor(targetPage: number) {
    const params = new URLSearchParams();
    for (const [key, value] of Object.entries(searchParams)) {
      if (value && key !== "page") params.set(key, value);
    }
    if (targetPage > 1) params.set("page", String(targetPage));
    const qs = params.toString();
    return qs ? `${basePath}?${qs}` : basePath;
  }

  const pageNumbers = Array.from({ length: pages }, (_, i) => i + 1);

  return (
    <nav className="flex items-center justify-center gap-1 pt-4" aria-label="Pagination">
      <Link
        href={hrefFor(Math.max(1, page - 1))}
        aria-disabled={page <= 1}
        className={cn(
          "flex h-9 min-w-9 items-center justify-center rounded-md border border-input px-3 text-sm hover:bg-secondary",
          page <= 1 && "pointer-events-none opacity-40",
        )}
      >
        Prev
      </Link>
      {pageNumbers.map((n) => (
        <Link
          key={n}
          href={hrefFor(n)}
          aria-current={n === page ? "page" : undefined}
          className={cn(
            "flex h-9 min-w-9 items-center justify-center rounded-md border px-3 text-sm",
            n === page ? "border-primary bg-primary text-primary-foreground" : "border-input hover:bg-secondary",
          )}
        >
          {n}
        </Link>
      ))}
      <Link
        href={hrefFor(Math.min(pages, page + 1))}
        aria-disabled={page >= pages}
        className={cn(
          "flex h-9 min-w-9 items-center justify-center rounded-md border border-input px-3 text-sm hover:bg-secondary",
          page >= pages && "pointer-events-none opacity-40",
        )}
      >
        Next
      </Link>
    </nav>
  );
}
