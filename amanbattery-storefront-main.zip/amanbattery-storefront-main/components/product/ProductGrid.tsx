import ProductCard from "./ProductCard";
import type { PublicProduct } from "@/lib/api/types";

// 4 columns desktop / 3 tablet / 2 mobile — never forces 4 on small
// screens, per the design spec.
export default function ProductGrid({ products }: { products: PublicProduct[] }) {
  if (products.length === 0) {
    return (
      <div className="rounded-lg border border-dashed border-border py-16 text-center text-sm text-muted-foreground">
        No products found.
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
      {products.map((p) => (
        <ProductCard key={p.id} product={p} />
      ))}
    </div>
  );
}
