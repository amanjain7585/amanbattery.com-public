"use client";

import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { checkServiceability } from "@/lib/api/serviceability";
import type { ServiceabilityResult } from "@/lib/api/types";
import type { ApiError } from "@/lib/api/client";

type Status = { kind: "idle" } | { kind: "loading" } | { kind: "result"; data: ServiceabilityResult } | { kind: "error"; message: string };

// Delhivery's pin-code API returns serviceable/COD/prepaid flags, not an
// ETA — so this honestly reports availability without inventing a delivery
// date. Client component since it's driven by user input, not page load.
export default function PincodeChecker() {
  const [pincode, setPincode] = useState("");
  const [status, setStatus] = useState<Status>({ kind: "idle" });

  async function handleCheck(e: React.FormEvent) {
    e.preventDefault();
    if (!/^\d{6}$/.test(pincode)) {
      setStatus({ kind: "error", message: "Enter a valid 6-digit pincode" });
      return;
    }
    setStatus({ kind: "loading" });
    try {
      const data = await checkServiceability(pincode);
      setStatus({ kind: "result", data });
    } catch (err) {
      const apiErr = err as ApiError;
      setStatus({
        kind: "error",
        message: apiErr?.status === 400 ? "Enter a valid 6-digit pincode" : "Couldn't check delivery right now — please try again.",
      });
    }
  }

  return (
    <div className="rounded-lg border border-border p-3">
      <form onSubmit={handleCheck} className="flex gap-2">
        <Input
          type="text"
          inputMode="numeric"
          maxLength={6}
          placeholder="Enter pincode"
          value={pincode}
          onChange={(e) => setPincode(e.target.value.replace(/\D/g, ""))}
          aria-label="Delivery pincode"
          className="max-w-[140px]"
        />
        <Button type="submit" variant="outline" disabled={status.kind === "loading"}>
          {status.kind === "loading" ? "Checking..." : "Check"}
        </Button>
      </form>

      {status.kind === "result" && (
        <p className={`mt-2 text-sm ${status.data.deliverable ? "text-foreground" : "text-destructive"}`}>
          {status.data.deliverable
            ? status.data.selfDelivery
              ? `Delivery available to ${status.data.pincode} (local delivery in ${status.data.selfDelivery.city}).`
              : `Delivery available to ${status.data.pincode}${status.data.courier?.cod ? " (Cash on Delivery available)" : ""}.`
            : `Sorry, we don't currently deliver to ${status.data.pincode}.`}
        </p>
      )}
      {status.kind === "error" && <p className="mt-2 text-sm text-destructive">{status.message}</p>}
    </div>
  );
}
