import Image from "next/image";
import Link from "next/link";
import { formatINR } from "@/lib/utils";
import type { PublicProduct } from "@/lib/api/types";
import AddToCartButton from "@/components/cart/AddToCartButton";

// Card is a div (not a single wrapping Link) since it now has two
// interactive elements — the product Link and the Add to Cart button —
// which can't be nested inside each other in valid HTML. Consistent card
// height comes from the fixed-aspect image box + line-clamped title, not a
// hardcoded card height.
export default function ProductCard({ product }: { product: PublicProduct }) {
  const image = product.images[0];
  const href = `/product/${encodeURIComponent(product.slug)}`;

  return (
    <div className="group flex flex-col overflow-hidden rounded-lg border border-border bg-card transition-shadow hover:shadow-md">
      <Link href={href}>
        <div className="relative aspect-square w-full bg-secondary/40">
          {image ? (
            <Image
              src={image}
              alt={product.title}
              fill
              sizes="(min-width: 1024px) 25vw, (min-width: 640px) 33vw, 50vw"
              className="object-contain p-4"
            />
          ) : (
            <div className="flex h-full items-center justify-center text-xs text-muted-foreground">No image</div>
          )}
        </div>
      </Link>
      <div className="flex flex-1 flex-col gap-1 p-3">
        {product.brand && <span className="text-xs text-muted-foreground">{product.brand}</span>}
        <Link href={href}>
          <h3 className="line-clamp-2 text-sm font-medium leading-snug hover:text-primary">{product.title}</h3>
        </Link>
        <div className="mt-auto flex items-baseline gap-2 pt-1">
          {product.price != null ? (
            <>
              <span className="text-base font-semibold text-foreground">{formatINR(product.price)}</span>
              {product.mrp != null && product.mrp > product.price && (
                <span className="text-xs text-muted-foreground line-through">{formatINR(product.mrp)}</span>
              )}
            </>
          ) : (
            <span className="text-sm text-muted-foreground">Check price</span>
          )}
        </div>
        <span className="text-xs text-muted-foreground">Available for Delivery</span>
        {product.price != null && (
          <AddToCartButton
            productId={product.id}
            slug={product.slug}
            title={product.title}
            image={image ?? null}
            price={product.price}
            size="sm"
            variant="outline"
            className="mt-2 w-full"
          />
        )}
      </div>
    </div>
  );
}
