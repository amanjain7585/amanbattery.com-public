"use client";

// Thumbnail strip + main image, switching on click — products already carry
// multiple images (Amazon catalog import fetches the full set), the PDP was
// just only ever rendering images[0]. No zoom/lightbox yet, kept simple.

import { useState } from "react";
import Image from "next/image";
import { cn } from "@/lib/utils";

export default function ProductGallery({ images, title }: { images: string[]; title: string }) {
  const [active, setActive] = useState(0);
  const activeImage = images[active];

  if (images.length === 0) {
    return (
      <div className="relative aspect-square w-full rounded-lg border border-border bg-secondary/40">
        <div className="flex h-full items-center justify-center text-sm text-muted-foreground">No image available</div>
      </div>
    );
  }

  return (
    <div className="flex flex-col-reverse gap-3 sm:flex-row">
      {images.length > 1 && (
        <div className="flex gap-2 overflow-x-auto sm:w-20 sm:flex-col sm:overflow-y-auto">
          {images.map((img, i) => (
            <button
              key={img + i}
              type="button"
              onClick={() => setActive(i)}
              aria-label={`Show image ${i + 1}`}
              className={cn(
                "relative aspect-square w-16 shrink-0 overflow-hidden rounded-md border bg-secondary/40 sm:w-full",
                active === i ? "border-primary ring-1 ring-primary" : "border-border",
              )}
            >
              <Image src={img} alt={`${title} thumbnail ${i + 1}`} fill sizes="64px" className="object-contain p-1" />
            </button>
          ))}
        </div>
      )}

      <div className="relative aspect-square w-full flex-1 rounded-lg border border-border bg-secondary/40">
        <Image
          key={activeImage}
          src={activeImage}
          alt={title}
          fill
          sizes="(min-width: 1024px) 50vw, 100vw"
          className="object-contain p-6"
          priority
        />
      </div>
    </div>
  );
}
