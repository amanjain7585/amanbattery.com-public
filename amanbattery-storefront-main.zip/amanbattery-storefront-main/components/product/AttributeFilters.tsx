"use client";

// Category-scoped attribute/brand/price/stock filter sidebar (desktop) and
// drawer (mobile). Driven entirely by CategoryFilters from
// GET /public/categories/:slug/filters — nothing here is hardcoded to a
// specific attribute or category name, so a newly-mapped filterable
// Attribute appears automatically. Same URL-search-params pattern as
// FilterBar/Pagination (shareable/bookmarkable, no local-only state).

import { useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import type { CategoryFilters } from "@/lib/api/types";
import { cn } from "@/lib/utils";

const RESERVED_KEYS = new Set(["brandId", "sort", "page", "priceMin", "priceMax", "inStock"]);

function toggleValue(current: string[], value: string): string[] {
  return current.includes(value) ? current.filter((v) => v !== value) : [...current, value];
}

function activeFilterCount(searchParams: URLSearchParams): number {
  let count = 0;
  searchParams.forEach((value, key) => {
    if (!value) return;
    if (key === "brandId" || RESERVED_KEYS.has(key)) {
      if (key !== "sort" && key !== "page") count += 1;
    } else {
      count += value.split(",").filter(Boolean).length;
    }
  });
  return count;
}

function FilterContent({
  data,
  basePath,
  onNavigate,
}: {
  data: CategoryFilters;
  basePath: string;
  onNavigate?: () => void;
}) {
  const router = useRouter();
  const searchParams = useSearchParams();

  function updateParams(mutate: (params: URLSearchParams) => void) {
    const params = new URLSearchParams(searchParams.toString());
    mutate(params);
    params.delete("page");
    const qs = params.toString();
    router.push(qs ? `${basePath}?${qs}` : basePath);
    onNavigate?.();
  }

  function toggleAttr(code: string, value: string) {
    updateParams((params) => {
      const current = (params.get(code) ?? "").split(",").filter(Boolean);
      const next = toggleValue(current, value);
      if (next.length > 0) params.set(code, next.join(","));
      else params.delete(code);
    });
  }

  function toggleBrand(id: string) {
    updateParams((params) => {
      const current = (params.get("brandId") ?? "").split(",").filter(Boolean);
      const next = toggleValue(current, id);
      if (next.length > 0) params.set("brandId", next.join(","));
      else params.delete("brandId");
    });
  }

  const [priceMin, setPriceMin] = useState(searchParams.get("priceMin") ?? "");
  const [priceMax, setPriceMax] = useState(searchParams.get("priceMax") ?? "");

  function applyPrice() {
    updateParams((params) => {
      if (priceMin) params.set("priceMin", priceMin);
      else params.delete("priceMin");
      if (priceMax) params.set("priceMax", priceMax);
      else params.delete("priceMax");
    });
  }

  const activeCount = activeFilterCount(searchParams);

  return (
    <div className="flex flex-col gap-6">
      {activeCount > 0 && (
        <button
          type="button"
          onClick={() => updateParams((params) => {
            for (const key of Array.from(params.keys())) {
              if (key !== "sort") params.delete(key);
            }
          })}
          className="w-fit text-sm font-medium text-primary hover:underline"
        >
          Clear all ({activeCount})
        </button>
      )}

      <div>
        <label className="mb-2 flex items-center gap-2 text-sm">
          <input
            type="checkbox"
            checked={searchParams.get("inStock") === "true"}
            onChange={(e) => updateParams((params) => (e.target.checked ? params.set("inStock", "true") : params.delete("inStock")))}
            className="h-4 w-4 rounded border-input"
          />
          In stock only
        </label>
      </div>

      <div>
        <div className="mb-2 text-sm font-semibold">Price</div>
        <div className="flex items-center gap-2">
          <input
            type="number"
            min={0}
            placeholder={data.priceMin != null ? String(Math.floor(data.priceMin)) : "Min"}
            value={priceMin}
            onChange={(e) => setPriceMin(e.target.value)}
            onBlur={applyPrice}
            className="h-8 w-full rounded-md border border-input bg-background px-2 text-sm"
          />
          <span className="text-muted-foreground">–</span>
          <input
            type="number"
            min={0}
            placeholder={data.priceMax != null ? String(Math.ceil(data.priceMax)) : "Max"}
            value={priceMax}
            onChange={(e) => setPriceMax(e.target.value)}
            onBlur={applyPrice}
            className="h-8 w-full rounded-md border border-input bg-background px-2 text-sm"
          />
        </div>
      </div>

      {data.brands.length > 0 && (
        <div>
          <div className="mb-2 text-sm font-semibold">Brand</div>
          <div className="flex max-h-48 flex-col gap-2 overflow-y-auto">
            {data.brands.map((b) => (
              <label key={b.id} className="flex items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  checked={(searchParams.get("brandId") ?? "").split(",").includes(b.id)}
                  onChange={() => toggleBrand(b.id)}
                  className="h-4 w-4 rounded border-input"
                />
                {b.brandName}
              </label>
            ))}
          </div>
        </div>
      )}

      {data.attributes.map((attr) => (
        <div key={attr.code} className="border-t border-border pt-4">
          <div className="mb-2 text-sm font-semibold">
            {attr.name}
            {attr.unit ? ` (${attr.unit})` : ""}
          </div>
          <div className="flex max-h-48 flex-col gap-2 overflow-y-auto">
            {attr.values.map((v) => (
              <label key={v.value} className="flex items-center justify-between gap-2 text-sm">
                <span className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={(searchParams.get(attr.code) ?? "").split(",").includes(v.value)}
                    onChange={() => toggleAttr(attr.code, v.value)}
                    className="h-4 w-4 rounded border-input"
                  />
                  {v.value}
                </span>
                <span className="text-xs text-muted-foreground">({v.count})</span>
              </label>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

export default function AttributeFilters({ data, basePath }: { data: CategoryFilters; basePath: string }) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const searchParams = useSearchParams();

  // Body scroll lock while the mobile drawer is open.
  useEffect(() => {
    document.body.style.overflow = mobileOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [mobileOpen]);

  const activeCount = activeFilterCount(searchParams);

  return (
    <>
      {/* Desktop sidebar */}
      <aside className="hidden w-64 shrink-0 lg:block">
        <FilterContent data={data} basePath={basePath} />
      </aside>

      {/* Mobile trigger */}
      <button
        type="button"
        onClick={() => setMobileOpen(true)}
        className="flex h-10 items-center gap-2 rounded-md border border-input bg-background px-3 text-sm lg:hidden"
      >
        Filters
        {activeCount > 0 && (
          <span className="flex h-5 min-w-5 items-center justify-center rounded-full bg-primary px-1 text-xs text-primary-foreground">
            {activeCount}
          </span>
        )}
      </button>

      {/* Mobile drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/50" onClick={() => setMobileOpen(false)} />
          <div
            className={cn(
              "absolute inset-y-0 left-0 flex w-[85vw] max-w-sm flex-col overflow-y-auto bg-background p-4 shadow-lg",
            )}
          >
            <div className="mb-4 flex items-center justify-between">
              <span className="text-lg font-semibold">Filters</span>
              <button type="button" onClick={() => setMobileOpen(false)} className="text-sm text-muted-foreground" aria-label="Close filters">
                Close
              </button>
            </div>
            <FilterContent data={data} basePath={basePath} onNavigate={() => setMobileOpen(false)} />
          </div>
        </div>
      )}
    </>
  );
}
