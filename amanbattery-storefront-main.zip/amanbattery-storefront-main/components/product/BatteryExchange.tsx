"use client";

import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { formatINR } from "@/lib/utils";
import { whatsappLink } from "@/lib/whatsapp";
import type { PublicExchangeOffer } from "@/lib/api/types";

const CONDITIONS = ["Working", "Not Working", "Physically Damaged"] as const;

const selectClass =
  "flex h-10 w-full rounded-md border border-input bg-background px-3 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring";

function valueTypeLabel(offer: PublicExchangeOffer): string {
  if (offer.valueType === "FIXED") return "Fixed exchange value";
  if (offer.valueType === "ESTIMATED") return "Estimated — confirmed at pickup";
  return "Subject to physical inspection";
}

// Customer-facing trade-in flow (storefront brief Part 9). There's no
// order-integrated trade-in system in the OMS yet — no way to store an
// exchange request or apply it to a cart total — so this collects the
// customer's old-battery details, shows an honest indicative value per the
// product's configured rule, and hands off to WhatsApp to confirm, the same
// pattern the rest of the storefront uses for anything that needs a human
// (see "Ask a Question on WhatsApp" on the PDP).
export default function BatteryExchange({
  offer,
  productTitle,
  whatsappNumber,
}: {
  offer: PublicExchangeOffer;
  productTitle: string;
  whatsappNumber?: string;
}) {
  const [hasOldBattery, setHasOldBattery] = useState<boolean | null>(null);
  const [batteryType, setBatteryType] = useState(offer.eligibleBatteryTypes[0] ?? "");
  const [capacity, setCapacity] = useState("");
  const [brand, setBrand] = useState("");
  const [condition, setCondition] = useState<(typeof CONDITIONS)[number]>("Working");

  const capacityNum = Number(capacity) || null;
  const withinCapacityRange =
    capacityNum == null ||
    ((offer.eligibleCapacityMinAh == null || capacityNum >= offer.eligibleCapacityMinAh) &&
      (offer.eligibleCapacityMaxAh == null || capacityNum <= offer.eligibleCapacityMaxAh));

  const message = [
    `Hi, I'd like to exchange an old battery when buying: ${productTitle}`,
    batteryType && `Old battery type: ${batteryType}`,
    capacity && `Approximate capacity: ${capacity} Ah`,
    brand && `Old battery brand: ${brand}`,
    `Condition: ${condition}`,
  ].filter(Boolean).join("\n");

  return (
    <div className="rounded-lg border border-border p-4">
      <div className="flex items-center justify-between gap-2">
        <p className="text-sm font-medium">Have an old battery to exchange?</p>
        <Badge variant="outline" className="text-xs">{valueTypeLabel(offer)}</Badge>
      </div>

      {(offer.eligibleBatteryTypes.length > 0 || offer.eligibleCapacityMinAh || offer.eligibleCapacityMaxAh) && (
        <p className="mt-1 text-xs text-muted-foreground">
          Accepted:{" "}
          {offer.eligibleBatteryTypes.length > 0 ? offer.eligibleBatteryTypes.join(", ") : "any type"}
          {(offer.eligibleCapacityMinAh || offer.eligibleCapacityMaxAh) &&
            ` · ${offer.eligibleCapacityMinAh ?? 0}${offer.eligibleCapacityMaxAh ? `–${offer.eligibleCapacityMaxAh}` : "+"} Ah`}
        </p>
      )}

      {hasOldBattery === null && (
        <div className="mt-3 flex gap-2">
          <Button type="button" size="sm" onClick={() => setHasOldBattery(true)}>Yes</Button>
          <Button type="button" size="sm" variant="outline" onClick={() => setHasOldBattery(false)}>No</Button>
        </div>
      )}

      {hasOldBattery === false && (
        <p className="mt-3 text-sm text-muted-foreground">No problem — you can still buy this without an exchange.</p>
      )}

      {hasOldBattery === true && (
        <div className="mt-3 space-y-3">
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div>
              <label className="text-xs text-muted-foreground">Old battery type</label>
              {offer.eligibleBatteryTypes.length > 0 ? (
                <select className={selectClass} value={batteryType} onChange={(e) => setBatteryType(e.target.value)}>
                  {offer.eligibleBatteryTypes.map((t) => <option key={t} value={t}>{t}</option>)}
                  <option value="Other">Other</option>
                </select>
              ) : (
                <Input value={batteryType} onChange={(e) => setBatteryType(e.target.value)} placeholder="e.g. Lead Acid" />
              )}
            </div>
            <div>
              <label className="text-xs text-muted-foreground">Approximate capacity (Ah)</label>
              <Input type="number" min={0} value={capacity} onChange={(e) => setCapacity(e.target.value)} placeholder="e.g. 100" />
            </div>
            <div>
              <label className="text-xs text-muted-foreground">Old battery brand</label>
              <Input value={brand} onChange={(e) => setBrand(e.target.value)} placeholder="e.g. Exide" />
            </div>
            <div>
              <label className="text-xs text-muted-foreground">Condition</label>
              <select className={selectClass} value={condition} onChange={(e) => setCondition(e.target.value as typeof condition)}>
                {CONDITIONS.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
          </div>

          <div className="rounded-md bg-secondary/60 p-3 text-sm">
            {offer.valueType === "INSPECTION" ? (
              <p>Exchange value determined on physical inspection at pickup/delivery — no online quote.</p>
            ) : offer.exchangeValue != null ? (
              <p>
                {offer.valueType === "FIXED" ? "Guaranteed exchange value: " : "Estimated exchange value: "}
                <span className="font-semibold">{formatINR(offer.exchangeValue)}</span>
                {offer.valueType === "ESTIMATED" && " (confirmed at pickup)"}
                {!withinCapacityRange && (
                  <span className="mt-1 block text-xs text-muted-foreground">
                    Your battery&apos;s capacity is outside our usual accepted range — value will be confirmed by our team.
                  </span>
                )}
              </p>
            ) : (
              <p>Exchange value will be confirmed by our team.</p>
            )}
          </div>

          <a
            href={whatsappLink(message, whatsappNumber)}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex h-10 items-center justify-center rounded-md bg-accent px-4 text-sm font-medium text-accent-foreground hover:bg-accent/90"
          >
            Confirm Exchange on WhatsApp
          </a>
        </div>
      )}
    </div>
  );
}
