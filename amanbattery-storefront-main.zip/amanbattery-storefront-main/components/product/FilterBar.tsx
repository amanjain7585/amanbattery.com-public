"use client";

import { useRouter, useSearchParams } from "next/navigation";
import type { PublicBrand, PublicCategory } from "@/lib/api/types";

const SORT_OPTIONS = [
  { value: "", label: "Sort: Relevance" },
  { value: "newest", label: "Newest" },
  { value: "price_asc", label: "Price: Low to High" },
  { value: "price_desc", label: "Price: High to Low" },
] as const;

const selectClassName =
  "h-10 rounded-md border border-input bg-background px-3 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring";

// Drives the shop/category grid via URL search params (not local state) so
// filters are shareable/bookmarkable links and survive a page refresh.
// categoryId is only shown when the page isn't already scoped to one
// category (i.e. not rendered from /category/[id]).
export default function FilterBar({
  categories,
  brands,
  showCategoryFilter = true,
  basePath,
}: {
  categories: PublicCategory[];
  brands: PublicBrand[];
  showCategoryFilter?: boolean;
  basePath: string;
}) {
  const router = useRouter();
  const searchParams = useSearchParams();

  function updateParam(key: string, value: string) {
    const params = new URLSearchParams(searchParams.toString());
    if (value) {
      params.set(key, value);
    } else {
      params.delete(key);
    }
    params.delete("page");
    const qs = params.toString();
    router.push(qs ? `${basePath}?${qs}` : basePath);
  }

  return (
    <div className="flex flex-wrap gap-3">
      {showCategoryFilter && (
        <select
          className={selectClassName}
          value={searchParams.get("categoryId") ?? ""}
          onChange={(e) => updateParam("categoryId", e.target.value)}
          aria-label="Filter by category"
        >
          <option value="">All Categories</option>
          {categories.map((c) => (
            <option key={c.id} value={c.id}>
              {c.categoryName}
            </option>
          ))}
        </select>
      )}

      <select
        className={selectClassName}
        value={searchParams.get("brandId") ?? ""}
        onChange={(e) => updateParam("brandId", e.target.value)}
        aria-label="Filter by brand"
      >
        <option value="">All Brands</option>
        {brands.map((b) => (
          <option key={b.id} value={b.id}>
            {b.brandName}
          </option>
        ))}
      </select>

      <select
        className={selectClassName}
        value={searchParams.get("sort") ?? ""}
        onChange={(e) => updateParam("sort", e.target.value)}
        aria-label="Sort products"
      >
        {SORT_OPTIONS.map((opt) => (
          <option key={opt.value} value={opt.value}>
            {opt.label}
          </option>
        ))}
      </select>
    </div>
  );
}
