// components/product/page-modules.tsx
//
// One render function per PDP Page Builder module type (see the OMS
// backend's module-registry.ts — this file's keys must stay a subset of
// that registry; an admin can never place a type this map doesn't know how
// to render, but a type CAN exist in the registry with no visual slot yet
// if it's not relevant to this specific storefront build). Every function
// either returns real JSX from real, already-fetched data, or `null` —
// `null` is what makes a module's `hideWhenEmpty` behavior work, since the
// page renderer (below) treats a null return exactly like a disabled
// module: it doesn't print an empty heading/card for it.
//
// Nothing here re-implements cart/checkout/pricing/availability logic —
// every module reads values the page already computed once (server-side,
// from the authoritative resolvers) and passed down via ModuleRenderContext.

import Image from "next/image";
import Link from "next/link";
import { MessageCircle, ShieldCheck, CheckCircle2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { buttonVariants } from "@/components/ui/button";
import PincodeChecker from "@/components/product/PincodeChecker";
import BatteryExchange from "@/components/product/BatteryExchange";
import ProductGallery from "@/components/product/ProductGallery";
import ProductCtaButtons from "@/components/cart/ProductCtaButtons";
import ProductCard from "@/components/product/ProductCard";
import { formatINR, cn } from "@/lib/utils";
import { whatsappLink } from "@/lib/whatsapp";
import { SITE_URL } from "@/lib/seo";
import type { PublicProductDetail } from "@/lib/api/types";
import type { WebsiteConfig } from "@/lib/api/website-config";
import type { LayoutModule } from "@/lib/page-layout-types";

export interface ModuleRenderContext {
  product: PublicProductDetail;
  config: WebsiteConfig | null;
  module: LayoutModule;
  // Precomputed once per page render (not per module) so every module
  // that needs e.g. `attrs` or `inStock` reads the exact same value the
  // rest of the page does — no module recomputes its own copy.
  attrs: { code: string; label: string; value: string }[];
  keySpecs: { label: string; value: string }[];
  modelCode: string | null;
  inStock: boolean;
  hasWarranty: boolean;
  waNumber: string | undefined;
}

function findAttrByPattern(attrs: ModuleRenderContext["attrs"], pattern: RegExp) {
  return attrs.find((a) => pattern.test(a.code) || pattern.test(a.label));
}

function Heading({ ctx, fallback }: { ctx: ModuleRenderContext; fallback: string }) {
  if (!ctx.module.showHeading) return null;
  return <h2 className="mb-3 text-lg font-semibold">{ctx.module.heading || fallback}</h2>;
}

export const MODULE_RENDERERS: Record<string, (ctx: ModuleRenderContext) => React.ReactNode | null> = {
  BREADCRUMBS: ({ product }) => (
    <nav aria-label="Breadcrumb" className="text-sm text-muted-foreground">
      <Link href="/" className="hover:text-primary">Home</Link>
      <span className="mx-1">/</span>
      <Link href="/shop" className="hover:text-primary">Shop</Link>
      {product.category && product.categorySlug && (
        <>
          <span className="mx-1">/</span>
          <Link href={`/category/${product.categorySlug}`} className="hover:text-primary">{product.category}</Link>
        </>
      )}
      <span className="mx-1">/</span>
      <span aria-current="page" className="text-foreground">{product.title}</span>
    </nav>
  ),

  PRODUCT_BRAND: ({ product }) => (product.brand ? <Badge variant="outline">{product.brand}</Badge> : null),

  PRODUCT_TITLE: ({ product }) => <h1 className="text-2xl font-semibold leading-snug">{product.title}</h1>,

  MODEL_SKU: ({ modelCode }) => (modelCode ? <p className="text-sm text-muted-foreground">Model: {modelCode}</p> : null),

  PRODUCT_GALLERY: ({ product }) => <ProductGallery images={product.images} title={product.title} />,

  PRICE: ({ product, module }) => {
    const cfg = module.config as { showMrp?: boolean; showDiscountPercent?: boolean; showSavingsAmount?: boolean; showTaxInclusiveText?: boolean };
    const showMrp = cfg.showMrp !== false;
    const showSavings = cfg.showSavingsAmount !== false;
    const showTax = cfg.showTaxInclusiveText !== false;
    return (
      <>
        <div className="flex items-baseline gap-3 border-y border-border py-3">
          {product.price != null ? (
            <>
              <span className="text-3xl font-bold">{formatINR(product.price)}</span>
              {showMrp && product.mrp != null && product.mrp > product.price && (
                <span className="text-base text-muted-foreground line-through">MRP {formatINR(product.mrp)}</span>
              )}
            </>
          ) : (
            <span className="text-xl text-muted-foreground">Check price</span>
          )}
        </div>
        {showSavings && product.mrp != null && product.price != null && product.mrp > product.price && product.discountPercent != null && (
          <p className="text-sm font-medium text-accent">
            You save {formatINR(product.mrp - product.price)} ({product.discountPercent}% off)
          </p>
        )}
        {showTax && product.price != null && <p className="text-xs text-muted-foreground">Inclusive of all taxes</p>}
      </>
    );
  },

  AVAILABILITY: ({ product, inStock }) => (
    <div className="flex items-center gap-2">
      <p className={cn("text-sm font-medium", inStock ? "text-foreground" : "text-destructive")}>
        {inStock ? "In stock" : "Out of stock"}
      </p>
      {product.availabilityText && <span className="text-xs text-muted-foreground">{product.availabilityText}</span>}
    </div>
  ),

  KEY_SPECS: ({ keySpecs, module }) => {
    if (keySpecs.length === 0) return null;
    const cfg = module.config as { columns?: number };
    const columns = cfg.columns ?? 4;
    return (
      <div className={cn("grid grid-cols-2 gap-3 rounded-lg border border-border bg-secondary/30 p-3", columns >= 4 && "sm:grid-cols-4", columns === 3 && "sm:grid-cols-3")}>
        {keySpecs.map(({ label, value }) => (
          <div key={label}>
            <div className="text-[11px] uppercase tracking-wide text-muted-foreground">{label}</div>
            <div className="text-sm font-semibold">{value}</div>
          </div>
        ))}
      </div>
    );
  },

  PINCODE_CHECKER: () => <PincodeChecker />,

  QUANTITY: () => null, // Quantity selection lives inside PURCHASE_ACTIONS' own client component — no separate standalone slot in this storefront build today.

  PURCHASE_ACTIONS: ({ product, inStock }) =>
    product.price != null && inStock ? (
      <ProductCtaButtons productId={product.id} slug={product.slug} title={product.title} image={product.images[0] ?? null} price={product.price} />
    ) : (
      <p className="text-sm text-muted-foreground">
        {inStock
          ? "Online ordering isn't available for this product yet — ask us on WhatsApp below."
          : "This product is currently out of stock — ask us on WhatsApp for availability."}
      </p>
    ),

  TRUST_SIGNALS: ({ config, hasWarranty }) => {
    const trust = config?.commerce;
    if (!trust?.gstInvoiceAvailable && !trust?.securePayments && !hasWarranty) return null;
    return (
      <ul className="grid grid-cols-1 gap-1.5 text-sm sm:grid-cols-2">
        {trust?.gstInvoiceAvailable && (
          <li className="flex items-center gap-1.5 text-muted-foreground">
            <ShieldCheck className="h-4 w-4 text-accent" /> GST Invoice
          </li>
        )}
        {trust?.securePayments && (
          <li className="flex items-center gap-1.5 text-muted-foreground">
            <CheckCircle2 className="h-4 w-4 text-accent" /> Secure Payments
          </li>
        )}
        {hasWarranty && (
          <li className="flex items-center gap-1.5 text-muted-foreground">
            <CheckCircle2 className="h-4 w-4 text-accent" /> Manufacturer Warranty
          </li>
        )}
      </ul>
    );
  },

  WHATSAPP_SUPPORT: ({ product, waNumber }) => (
    <a
      href={whatsappLink(
        `Hi, I have a question about: ${product.title}${product.price != null ? ` (${formatINR(product.price)})` : ""} — ${SITE_URL}/product/${product.slug}`,
        waNumber,
      )}
      target="_blank"
      rel="noopener noreferrer"
      className={cn(buttonVariants({ variant: "outline" }), "w-full gap-2")}
    >
      <MessageCircle className="h-5 w-5" fill="currentColor" strokeWidth={0} />
      Ask a Question on WhatsApp
    </a>
  ),

  SHORT_DESCRIPTION: ({ product }) =>
    product.shortDescription ? <p className="whitespace-pre-line text-sm text-muted-foreground">{product.shortDescription}</p> : null,

  DESCRIPTION: ({ product }) =>
    product.fullDescription ? <p className="whitespace-pre-line text-sm text-muted-foreground">{product.fullDescription}</p> : null,

  HIGHLIGHTS: ({ product, module }) => {
    if (product.highlights.length === 0) return null;
    const cfg = module.config as { maxItems?: number };
    const items = product.highlights.slice(0, cfg.maxItems ?? 8);
    return (
      <ul className="list-inside list-disc space-y-1 text-sm text-muted-foreground">
        {items.map((h, i) => (
          <li key={i}>{h}</li>
        ))}
      </ul>
    );
  },

  SPECIFICATIONS: ({ attrs, module }) => {
    if (attrs.length === 0) return null;
    const cfg = module.config as { columns?: number };
    return (
      <dl className={cn("grid grid-cols-1 gap-x-8 gap-y-2", (cfg.columns ?? 2) >= 2 && "sm:grid-cols-2")}>
        {attrs.map(({ label, value }) => (
          <div key={label} className="flex justify-between border-b border-border py-2 text-sm sm:justify-start sm:gap-4">
            <dt className="text-muted-foreground">{label}</dt>
            <dd className="font-medium">{value}</dd>
          </div>
        ))}
      </dl>
    );
  },

  WARRANTY: ({ attrs }) => {
    const attr = findAttrByPattern(attrs, /warrant/i);
    return attr ? <p className="text-sm text-muted-foreground">{attr.value}</p> : null;
  },

  INCLUDED_COMPONENTS: ({ attrs }) => {
    const attr = findAttrByPattern(attrs, /includ/i);
    return attr ? <p className="text-sm text-muted-foreground">{attr.value}</p> : null;
  },

  MANUFACTURER_INFO: ({ attrs }) => {
    const attr = findAttrByPattern(attrs, /manufactur/i);
    return attr ? <p className="text-sm text-muted-foreground">{attr.value}</p> : null;
  },

  FAQ: ({ product }) =>
    product.faqs.length > 0 ? (
      <div className="space-y-4">
        {product.faqs.map((f, i) => (
          <div key={i}>
            <p className="text-sm font-medium">{f.question}</p>
            <p className="mt-1 text-sm text-muted-foreground">{f.answer}</p>
          </div>
        ))}
      </div>
    ) : null,

  RICH_TEXT: ({ module }) => {
    const cfg = module.config as { text?: string };
    return cfg.text ? <p className="whitespace-pre-line text-sm text-muted-foreground">{cfg.text}</p> : null;
  },

  BANNER: ({ module }) => {
    const cfg = module.config as { imageUrl?: string; linkUrl?: string; alt?: string };
    if (!cfg.imageUrl) return null;
    const img = <Image src={cfg.imageUrl} alt={cfg.alt ?? ""} width={1200} height={300} className="w-full rounded-lg object-cover" />;
    return cfg.linkUrl ? <Link href={cfg.linkUrl}>{img}</Link> : img;
  },

  // Policy links point at this storefront's own existing static routes —
  // real, already-deployed pages, never invented ones.
  SHIPPING_POLICY: () => (
    <Link href="/shipping-policy" className="text-sm text-primary underline">Shipping Policy</Link>
  ),
  RETURN_POLICY: () => (
    <Link href="/returns-refunds" className="text-sm text-primary underline">Return &amp; Refund Policy</Link>
  ),
  WARRANTY_POLICY: () => null, // No dedicated warranty-policy route exists in this storefront yet — hides rather than link to a page that doesn't exist.
  POLICY_LINKS: () => (
    <div className="flex flex-wrap gap-x-4 gap-y-1 text-sm">
      <Link href="/shipping-policy" className="text-primary underline">Shipping Policy</Link>
      <Link href="/returns-refunds" className="text-primary underline">Return &amp; Refund Policy</Link>
      <Link href="/terms" className="text-primary underline">Terms &amp; Conditions</Link>
      <Link href="/privacy-policy" className="text-primary underline">Privacy Policy</Link>
    </div>
  ),

  RELATED_PRODUCTS: ({ product, module }) => {
    if (product.relatedProducts.length === 0) return null;
    const cfg = module.config as { count?: number };
    return (
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
        {product.relatedProducts.slice(0, cfg.count ?? 8).map((p) => (
          <ProductCard key={p.id} product={p} />
        ))}
      </div>
    );
  },

  SAME_BRAND_PRODUCTS: ({ product }) =>
    product.brand ? (
      <Link href={`/shop?search=${encodeURIComponent(product.brand)}`} className="text-sm text-primary underline">
        Shop more {product.brand} products
      </Link>
    ) : null,

  SAME_CATEGORY_PRODUCTS: ({ product }) =>
    product.category && product.categorySlug ? (
      <Link href={`/category/${product.categorySlug}`} className="text-sm text-primary underline">
        Browse more {product.category}
      </Link>
    ) : null,

  CAR_BATTERY_FINDER: () => (
    <Link href="/car-battery-finder" className={cn(buttonVariants({ variant: "outline" }), "w-full")}>
      Find the right battery for your vehicle
    </Link>
  ),

  VEHICLE_COMPATIBILITY: ({ product }) => {
    if (product.vehicleCompatibility.length === 0) return null;
    return (
      <ul className="grid grid-cols-1 gap-2 sm:grid-cols-2">
        {product.vehicleCompatibility.map((v, i) => (
          <li key={i} className="rounded-md border border-border px-3 py-2 text-sm">
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-medium">{v.make} {v.model}</span>
              <span className="text-muted-foreground">
                {v.variant}
                {v.yearFrom && v.yearTo ? ` (${v.yearFrom}–${v.yearTo})` : v.yearFrom ? ` (${v.yearFrom}+)` : ""}
              </span>
              {v.confidence === "ESTIMATED" && <Badge variant="outline" className="text-xs">Estimated fit</Badge>}
            </div>
            {v.notes && <p className="mt-1 text-xs text-muted-foreground">{v.notes}</p>}
          </li>
        ))}
      </ul>
    );
  },

  INVERTER_CALCULATOR: () => (
    <Link href="/inverter-calculator" className={cn(buttonVariants({ variant: "outline" }), "w-full")}>
      Calculate your inverter load
    </Link>
  ),

  BATTERY_BACKUP_CALCULATOR: () => (
    <Link href="/inverter-calculator" className={cn(buttonVariants({ variant: "outline" }), "w-full")}>
      Calculate expected backup time
    </Link>
  ),

  BATTERY_EXCHANGE: ({ product, waNumber }) =>
    product.exchangeOffer ? <BatteryExchange offer={product.exchangeOffer} productTitle={product.title} whatsappNumber={waNumber} /> : null,

  COMBO_COMPONENTS: ({ product }) => {
    if (product.comboComponents.length === 0) return null;
    return (
      <ul className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        {product.comboComponents.map((c, i) => {
          const content = (
            <>
              {c.image ? (
                <div className="relative h-14 w-14 shrink-0 rounded-md border border-border bg-secondary/40">
                  <Image src={c.image} alt={c.name} fill sizes="56px" className="object-contain p-1" />
                </div>
              ) : (
                <div className="h-14 w-14 shrink-0 rounded-md border border-border bg-secondary/40" />
              )}
              <div className="min-w-0">
                <p className="truncate text-sm font-medium">{c.name}</p>
                <p className="text-xs text-muted-foreground">Qty: {c.quantity} · SKU: {c.sku}</p>
              </div>
            </>
          );
          return (
            <li key={i} className="flex items-center gap-3 rounded-md border border-border p-3">
              {c.slug ? (
                <Link href={`/product/${encodeURIComponent(c.slug)}`} className="flex items-center gap-3 hover:opacity-80">{content}</Link>
              ) : (
                <div className="flex items-center gap-3 opacity-70">{content}</div>
              )}
            </li>
          );
        })}
      </ul>
    );
  },
};

export { Heading as ModuleHeading };
