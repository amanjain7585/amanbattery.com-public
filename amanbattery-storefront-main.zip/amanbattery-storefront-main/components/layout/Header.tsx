import Link from "next/link";
import { User } from "lucide-react";
import Logo from "./Logo";
import SearchBar from "@/components/navigation/SearchBar";
import CartIcon from "@/components/cart/CartIcon";
import { getMenu } from "@/lib/api/menus";
import { getWebsiteConfig } from "@/lib/api/website-config";
import { cn } from "@/lib/utils";

// Wishlist intentionally isn't in this header yet — no backend for it. The
// account link now points at /account (login-aware — AuthHeaderLink).
export default async function Header() {
  const [menuItems, config] = await Promise.all([
    getMenu("HEADER").catch(() => []),
    getWebsiteConfig().catch(() => null),
  ]);
  const branding = config?.branding;
  const header = config?.header;
  const bar = header?.announcementBar;
  // Undefined (config unreachable, or field never saved) defaults to the
  // previous always-on behavior rather than hiding search/account/cart —
  // an API hiccup shouldn't silently remove header functionality.
  const stickyHeader = header?.stickyHeader ?? true;
  const searchEnabled = header?.searchEnabled ?? true;
  const accountEnabled = header?.accountEnabled ?? true;
  const cartEnabled = header?.cartEnabled ?? true;

  return (
    <header
      className={cn(
        "top-0 z-40 border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80",
        stickyHeader && "sticky"
      )}
    >
      {bar?.enabled && bar.message && (
        <div className="bg-primary text-primary-foreground text-center text-sm py-1.5 px-4">
          {bar.link ? (
            <Link href={bar.link} className="hover:underline">
              {bar.message}
            </Link>
          ) : (
            bar.message
          )}
        </div>
      )}
      <div className="container flex h-16 items-center gap-4">
        <Link href="/" className="shrink-0">
          <Logo logoUrl={branding?.logoUrl} siteName={branding?.siteName} />
        </Link>
        {searchEnabled && <SearchBar className="hidden flex-1 max-w-xl sm:block" />}
        {accountEnabled && (
          <Link
            href="/account"
            className="hidden shrink-0 items-center gap-1 text-sm text-muted-foreground hover:text-primary sm:flex"
          >
            <User className="h-5 w-5" />
          </Link>
        )}
        {cartEnabled && <CartIcon />}
      </div>
      {menuItems.length > 0 && (
        <nav className="border-t border-border">
          <div className="container flex h-11 items-center gap-5 overflow-x-auto text-sm">
            {menuItems.map((item) => (
              <Link
                key={item.id}
                href={item.url}
                target={item.openInNewTab ? "_blank" : undefined}
                rel={item.openInNewTab ? "noopener noreferrer" : undefined}
                className="whitespace-nowrap text-muted-foreground hover:text-primary"
              >
                {item.label}
              </Link>
            ))}
          </div>
        </nav>
      )}
      {/* Mobile search — full-width row below the logo/search row above */}
      {searchEnabled && (
        <div className="container pb-3 sm:hidden">
          <SearchBar />
        </div>
      )}
    </header>
  );
}
