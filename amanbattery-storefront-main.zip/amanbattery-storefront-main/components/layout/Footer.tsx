import Link from "next/link";
import { MessageCircle, Phone, Mail, MapPin } from "lucide-react";
import Logo from "./Logo";
import { whatsappDisplayNumber, whatsappLink } from "@/lib/whatsapp";
import { getMenu } from "@/lib/api/menus";
import { getWebsiteConfig } from "@/lib/api/website-config";

// No brand-logo icon set is bundled here (lucide-react dropped most brand
// icons) — a short text label per platform is simpler than pulling in a
// dedicated icon library for six links.
const SOCIAL_LABELS: Record<string, string> = {
  instagram: "Instagram",
  facebook: "Facebook",
  youtube: "YouTube",
  whatsapp: "WhatsApp",
  twitter: "Twitter / X",
  linkedin: "LinkedIn",
};

const DEFAULT_DESCRIPTION =
  "Reliable battery and power products from a trusted seller — car and bike batteries, inverters, chargers, and accessories from Exide, Amaron, Luminous, Okaya and more.";

const PAYMENT_ICON_LABELS: Record<string, string> = {
  visa: "Visa",
  mastercard: "Mastercard",
  rupay: "RuPay",
  upi: "UPI",
  netbanking: "Net Banking",
  cod: "COD",
};

// Footer content (about text, copyright, columns, social links, payment
// icons) now comes from OMS Admin > Website > Footer/Social instead of
// being hardcoded here.
export default async function Footer() {
  const [menuItems, config] = await Promise.all([
    getMenu("FOOTER").catch(() => []),
    getWebsiteConfig().catch(() => null),
  ]);
  const branding = config?.branding;
  const footer = config?.footer;
  const contact = config?.contact;
  const socialLinks = (config?.social?.links ?? []).filter((l) => l.enabled && l.url);
  const columns = footer?.columns ?? [];
  const hasContactInfo = !!(contact?.phone || contact?.email || contact?.address);
  const hasContactColumn = columns.some((c) => c.isContactBlock);
  // CMS-configured WhatsApp number takes priority; falls back to the
  // env-configured default so this never regresses to a dead link.
  const waNumber = contact?.whatsapp || whatsappDisplayNumber();
  const waLink = contact?.whatsapp
    ? `https://wa.me/${contact.whatsapp.replace(/[^\d]/g, "")}?text=${encodeURIComponent("Hi, I have a question about a product on Amanbattery.com")}`
    : whatsappLink("Hi, I have a question about a product on Amanbattery.com");
  const paymentIcons = footer?.paymentIcons ?? [];

  return (
    <footer className="border-t border-border bg-secondary/40 mt-16">
      <div className="container py-10">
        <div className="flex flex-wrap justify-between gap-8">
          <div>
            <Logo logoUrl={footer?.footerLogoUrl ?? branding?.logoUrl} siteName={branding?.siteName} />
            <p className="mt-3 max-w-md text-sm text-muted-foreground">
              {footer?.aboutText || DEFAULT_DESCRIPTION}
            </p>
            <a
              href={waLink}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-4 inline-flex items-center gap-2 text-sm font-medium text-foreground hover:text-primary"
            >
              <MessageCircle className="h-4 w-4 text-[#25D366]" fill="currentColor" strokeWidth={0} />
              Chat with us on WhatsApp: {waNumber}
            </a>
            {socialLinks.length > 0 && (
              <div className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-1 text-sm">
                {socialLinks.map((link) => (
                  <a
                    key={link.platform}
                    href={link.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-muted-foreground hover:text-primary"
                  >
                    {SOCIAL_LABELS[link.platform] ?? link.platform}
                  </a>
                ))}
              </div>
            )}
          </div>

          {hasContactInfo && !hasContactColumn && (
            <div className="flex flex-col gap-2 text-sm">
              <h3 className="font-semibold text-foreground">{footer?.contactHeading || "Contact Us"}</h3>
              {contact?.phone && (
                <a href={`tel:${contact.phone}`} className="flex items-center gap-2 text-muted-foreground hover:text-primary">
                  <Phone className="h-3.5 w-3.5 shrink-0" />
                  {contact.phone}
                </a>
              )}
              {contact?.email && (
                <a href={`mailto:${contact.email}`} className="flex items-center gap-2 text-muted-foreground hover:text-primary">
                  <Mail className="h-3.5 w-3.5 shrink-0" />
                  {contact.email}
                </a>
              )}
              {contact?.address && (
                <p className="flex items-start gap-2 text-muted-foreground">
                  <MapPin className="h-3.5 w-3.5 shrink-0 mt-0.5" />
                  <span>
                    {contact.address}
                    {contact.city ? `, ${contact.city}` : ""}
                    {contact.pincode ? ` - ${contact.pincode}` : ""}
                  </span>
                </p>
              )}
            </div>
          )}

          {columns.length > 0 ? (
            columns.map((column) =>
              column.isContactBlock ? (
                hasContactInfo && (
                  <div key={column.id} className="flex flex-col gap-2 text-sm">
                    <h3 className="font-semibold text-foreground">{column.title}</h3>
                    {contact?.phone && (
                      <a href={`tel:${contact.phone}`} className="flex items-center gap-2 text-muted-foreground hover:text-primary">
                        <Phone className="h-3.5 w-3.5 shrink-0" />
                        {contact.phone}
                      </a>
                    )}
                    {contact?.email && (
                      <a href={`mailto:${contact.email}`} className="flex items-center gap-2 text-muted-foreground hover:text-primary">
                        <Mail className="h-3.5 w-3.5 shrink-0" />
                        {contact.email}
                      </a>
                    )}
                    {contact?.address && (
                      <p className="flex items-start gap-2 text-muted-foreground">
                        <MapPin className="h-3.5 w-3.5 shrink-0 mt-0.5" />
                        <span>
                          {contact.address}
                          {contact.city ? `, ${contact.city}` : ""}
                          {contact.pincode ? ` - ${contact.pincode}` : ""}
                        </span>
                      </p>
                    )}
                  </div>
                )
              ) : (
                <nav key={column.id} className="flex flex-col gap-2 text-sm">
                  <h3 className="font-semibold text-foreground">{column.title}</h3>
                  {column.links.map((link) => (
                    <Link
                      key={link.id}
                      href={link.url}
                      target={link.openInNewTab ? "_blank" : undefined}
                      rel={link.openInNewTab ? "noopener noreferrer" : undefined}
                      className="text-muted-foreground hover:text-primary"
                    >
                      {link.label}
                    </Link>
                  ))}
                </nav>
              )
            )
          ) : (
            <nav className="flex flex-col gap-2 text-sm">
              {menuItems.map((item) => (
                <Link
                  key={item.id}
                  href={item.url}
                  target={item.openInNewTab ? "_blank" : undefined}
                  rel={item.openInNewTab ? "noopener noreferrer" : undefined}
                  className="text-muted-foreground hover:text-primary"
                >
                  {item.label}
                </Link>
              ))}
            </nav>
          )}
        </div>
        <div className="mt-8 flex flex-wrap items-center justify-between gap-3">
          <p className="text-xs text-muted-foreground">
            {footer?.copyrightText || `© ${new Date().getFullYear()} Amanbattery.com. All rights reserved.`}
          </p>
          {paymentIcons.length > 0 && (
            <div className="flex flex-wrap items-center gap-2">
              {paymentIcons.map((icon) => (
                <span
                  key={icon}
                  className="rounded border border-border px-2 py-0.5 text-[11px] font-medium text-muted-foreground"
                >
                  {PAYMENT_ICON_LABELS[icon] ?? icon}
                </span>
              ))}
            </div>
          )}
        </div>
      </div>
    </footer>
  );
}
