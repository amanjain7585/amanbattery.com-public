// Renders the real logo image uploaded via OMS Admin > Website > Branding
// next to the site name when both are set; falls back to the badge+
// wordmark placeholder when no logo has been uploaded yet. Site name text
// always renders (image alone isn't a substitute for it — screen readers/
// SEO/brand recognition all want the actual text, not just alt text).
export default function Logo({
  className,
  logoUrl,
  siteName,
}: {
  className?: string;
  logoUrl?: string;
  siteName?: string;
}) {
  const name = siteName ?? "Amanbattery.com";

  return (
    <span className={`inline-flex items-center gap-2 font-bold text-lg ${className ?? ""}`}>
      {logoUrl ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={logoUrl} alt={name} className="h-8 w-auto" />
      ) : (
        <span className="flex h-8 w-8 items-center justify-center rounded-md bg-primary text-primary-foreground">
          {name.charAt(0)}
        </span>
      )}
      <span>{logoUrl ? name : name.slice(1)}</span>
    </span>
  );
}
