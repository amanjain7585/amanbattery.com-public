import { MessageCircle } from "lucide-react";
import { whatsappLink } from "@/lib/whatsapp";

// Fixed, site-wide — the fastest path to an actual order right now, so it
// needs to be reachable from every page, not just product pages.
export default function WhatsAppButton({ number }: { number?: string }) {
  return (
    <a
      href={whatsappLink("Hi, I'd like to ask about a product on Amanbattery.com", number)}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Chat with us on WhatsApp"
      className="fixed bottom-5 right-5 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-[#25D366] text-white shadow-lg transition-transform hover:scale-105"
    >
      <MessageCircle className="h-7 w-7" fill="currentColor" strokeWidth={0} />
    </a>
  );
}
