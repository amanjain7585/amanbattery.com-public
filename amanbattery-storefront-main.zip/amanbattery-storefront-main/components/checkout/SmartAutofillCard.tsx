"use client";

// Optional, non-blocking Smart Address Autofill offer for checkout. Never
// auto-launches the Cashfree SDK — every step is an explicit customer
// click. Every failure mode (not configured, no data, SDK error, session
// expiry, closing the widget) falls back to "continue manually" — this
// card only ever stops offering itself, it never blocks the rest of
// checkout.

import { useEffect, useState } from "react";
import { Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  checkCashfreeAvailability,
  initiateCashfreeOnboarding,
  completeCashfreeOnboarding,
  trackCashfreeEvent,
} from "@/lib/api/cashfree";
import { launchCashfreeOnboarding, CASHFREE_SDK_CONTAINER_ID, CASHFREE_SDK_OUTCOMES } from "@/lib/cashfree-sdk";
import type { ApiError } from "@/lib/api/client";
import type { CashfreeNormalizedProfile } from "@/lib/api/types";

type Phase = "checking" | "hidden" | "offer" | "launching" | "closed" | "error";

export default function SmartAutofillCard({
  phone,
  token,
  onProfileFetched,
}: {
  phone: string;
  token: string;
  onProfileFetched: (profile: CashfreeNormalizedProfile) => void;
}) {
  const [phase, setPhase] = useState<Phase>("checking");
  const [message, setMessage] = useState("");

  useEffect(() => {
    let cancelled = false;
    if (!/^\d{10}$/.test(phone.replace(/^\+?91/, ""))) {
      setPhase("hidden");
      return;
    }
    setPhase("checking");
    checkCashfreeAvailability(phone, token)
      .then((res) => {
        if (!cancelled) setPhase(res.available ? "offer" : "hidden");
      })
      .catch(() => {
        if (!cancelled) setPhase("hidden");
      });
    return () => {
      cancelled = true;
    };
  }, [phone, token]);

  async function startSmartAutofill() {
    setPhase("launching");
    setMessage("");
    try {
      const initiated = await initiateCashfreeOnboarding(phone, token);
      const result = await launchCashfreeOnboarding(initiated.sessionId, initiated.environment);

      if (result.outcome === CASHFREE_SDK_OUTCOMES.SUCCESS) {
        const completed = await completeCashfreeOnboarding(
          { authCode: result.authCode, sessionId: initiated.sessionId, verificationId: result.verificationId },
          token,
        );
        onProfileFetched(completed.profile);
        trackCashfreeEvent("CASHFREE_PROFILE_APPLIED", initiated.sessionId, token).catch(() => {});
        setPhase("hidden");
        return;
      }

      trackCashfreeEvent("CASHFREE_ONBOARDING_CLOSED", initiated.sessionId, token).catch(() => {});

      if (result.outcome === CASHFREE_SDK_OUTCOMES.CLOSED) {
        setPhase("closed");
      } else if (result.outcome === CASHFREE_SDK_OUTCOMES.SESSION_EXPIRED) {
        setMessage("Your session expired — you can try again.");
        setPhase("error");
      } else {
        setMessage("Smart Autofill is temporarily unavailable. You can continue by entering your details manually.");
        setPhase("error");
      }
    } catch (err) {
      setMessage(
        (err as ApiError)?.message
          ? "Smart Autofill is temporarily unavailable. You can continue by entering your details manually."
          : "Something went wrong. You can continue by entering your details manually.",
      );
      setPhase("error");
    }
  }

  return (
    <>
      {/* Cashfree's SDK renders its consent UI into this container — must
          stay mounted whenever Smart Autofill might be launched, or the SDK
          reports DIV_MISSING. */}
      <div id={CASHFREE_SDK_CONTAINER_ID} />

      {phase === "offer" && (
        <div className="rounded-lg border border-primary/30 bg-primary/5 p-3">
          <p className="flex items-center gap-1.5 text-sm font-medium">
            <Sparkles className="h-4 w-4 text-primary" /> Fill your details faster
          </p>
          <p className="mt-1 text-xs text-muted-foreground">
            Use Smart Autofill to securely fetch available details from your mobile number. You&apos;ll review everything before continuing.
          </p>
          <div className="mt-2 flex flex-wrap items-center gap-2">
            <Button type="button" size="sm" onClick={startSmartAutofill}>
              Continue with Smart Autofill
            </Button>
            <Button type="button" size="sm" variant="ghost" onClick={() => setPhase("hidden")}>
              Enter details manually
            </Button>
          </div>
        </div>
      )}

      {phase === "launching" && (
        <div className="rounded-lg border p-3 text-sm text-muted-foreground">Opening Smart Autofill...</div>
      )}

      {phase === "closed" && (
        <div className="rounded-lg border p-3 text-sm text-muted-foreground">
          No problem — you can enter your details manually below.
        </div>
      )}

      {phase === "error" && (
        <div className="rounded-lg border border-destructive/30 bg-destructive/5 p-3 text-sm text-destructive">
          {message}{" "}
          <button type="button" className="underline" onClick={startSmartAutofill}>
            Try again
          </button>
        </div>
      )}
    </>
  );
}
