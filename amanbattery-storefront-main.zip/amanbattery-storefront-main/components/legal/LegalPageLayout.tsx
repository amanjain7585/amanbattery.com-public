// Shared shell for the legal/info pages (Privacy, Terms, Shipping, Returns,
// Contact) — same typographic treatment so they read as one consistent set
// rather than five one-off pages.
export default function LegalPageLayout({
  title,
  updated,
  children,
}: {
  title: string;
  updated?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="container max-w-3xl space-y-6 py-10">
      <div>
        <h1 className="text-2xl font-semibold">{title}</h1>
        {updated && <p className="mt-1 text-xs text-muted-foreground">Last updated: {updated}</p>}
      </div>
      <div className="prose-legal space-y-4 text-sm leading-relaxed text-foreground [&_h2]:mt-6 [&_h2]:text-base [&_h2]:font-semibold [&_p]:text-muted-foreground [&_ul]:list-disc [&_ul]:space-y-1 [&_ul]:pl-5 [&_ul]:text-muted-foreground [&_a]:text-primary [&_a]:underline">
        {children}
      </div>
    </div>
  );
}
