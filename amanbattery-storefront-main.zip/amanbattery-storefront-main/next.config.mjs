/** @type {import('next').NextConfig} */
const nextConfig = {
  // Traces and bundles only the deps actually used at runtime into
  // .next/standalone, instead of Next's default of running `next start`
  // against the full node_modules tree — cuts the server's baseline
  // memory footprint.
  output: "standalone",

  // 25MB in-memory cache — small enough to never impact container RAM
  // while allowing Next.js to cache public catalog queries and avoid redundant fetches.
  cacheMaxMemorySize: 25 * 1024 * 1024,

  images: {
    // Product photos are hosted on fast CDNs (Amazon CDN, Amaron S3 CDN).
    // Serving them directly (unoptimized) prevents the Node.js server from
    // buffering and processing large raw images in RAM via Sharp, saving
    // 300MB-500MB of server memory on Railway.
    unoptimized: true,
    remotePatterns: [
      { protocol: "https", hostname: "m.media-amazon.com" },
      { protocol: "https", hostname: "images-na.ssl-images-amazon.com" },
      { protocol: "https", hostname: "amaron-prod-images.s3.ap-south-1.amazonaws.com" },
    ],
  },
};

export default nextConfig;
